<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="111" height="111" viewBox="0 0 111 111">
  <defs>
    <filter id="Ellipse_317" x="0" y="0" width="111" height="111" filterUnits="userSpaceOnUse">
      <feOffset dy="3" input="SourceAlpha"/>
      <feGaussianBlur stdDeviation="5" result="blur"/>
      <feFlood flood-color="#073f83" flood-opacity="0.2"/>
      <feComposite operator="in" in2="blur"/>
      <feComposite in="SourceGraphic"/>
    </filter>
  </defs>
  <g id="Group_3204" data-name="Group 3204" transform="translate(15.401 12.273)">
    <g transform="matrix(1, 0, 0, 1, -15.4, -12.27)" filter="url(#Ellipse_317)">
      <circle id="Ellipse_317-2" data-name="Ellipse 317" cx="40.5" cy="40.5" r="40.5" transform="translate(15 12)" fill="#fff"/>
    </g>
    <path id="Polygon_1" data-name="Polygon 1" d="M12.378,4.72a3,3,0,0,1,5.245,0l9.9,17.823A3,3,0,0,1,24.9,27H5.1a3,3,0,0,1-2.622-4.457Z" transform="translate(57.599 25.727) rotate(90)" fill="#6bc5b1"/>
  </g>
</svg>
