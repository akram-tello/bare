<div class="uap-account-alert-warning">
	<div class="uap-register-error">
		<strong><?php esc_html_e('Admin Info: ', 'uap');?></strong><?php echo esc_uap_content($data['content']);?>
	</div>
</div>
