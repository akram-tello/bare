<div class="uap-public-trial-version">
	<?php esc_html_e('This is a Trial Version of ', 'uap');?> <strong><?php esc_html_e(' Ultimate Affiliate Pro ', 'uap');?></strong><?php esc_html_e('plugin. Please add your purchase code into Licence section to enable the Full Ultimate Affiliate Pro Version.', 'uap');?>
</div>
