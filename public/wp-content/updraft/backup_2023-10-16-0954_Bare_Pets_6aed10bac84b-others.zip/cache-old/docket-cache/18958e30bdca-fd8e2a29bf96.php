<?php 
return array (
  'timestamp' => 1689932774,
  'site_id' => 1,
  'group' => 'posts',
  'key' => 'last_changed',
  'type' => 'string',
  'timeout' => 1691142374,
  'data' => '0.46473400 1689932774',
);
/*@DOCKET_CACHE_EOF*/