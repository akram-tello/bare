<?php 
return array (
  'timestamp' => 1689932774,
  'site_id' => 1,
  'group' => 'options',
  'key' => 'notoptions',
  'type' => 'array',
  'timeout' => 1691142374,
  'data' => 
  array (
    'ewww_image_optimizer_debug' => true,
  ),
);
/*@DOCKET_CACHE_EOF*/