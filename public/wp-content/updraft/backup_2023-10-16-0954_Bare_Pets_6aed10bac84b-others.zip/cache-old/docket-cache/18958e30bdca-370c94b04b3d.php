<?php 
return array (
  'timestamp' => 1689932774,
  'site_id' => 1,
  'group' => 'posts',
  'key' => 'get_pages:503073306742ebb2a98d242f0d0649c8:0.46473400 1689932774',
  'type' => 'array',
  'timeout' => 1691142374,
  'data' => 
  array (
    0 => 198,
    1 => 228,
  ),
);
/*@DOCKET_CACHE_EOF*/