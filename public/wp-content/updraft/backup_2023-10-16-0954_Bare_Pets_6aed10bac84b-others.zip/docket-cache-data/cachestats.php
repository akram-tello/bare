<?php 
return [
    'timestamp' => 1689932472,
    'size' => 61186,
    'filesize' => 8106344,
    'files' => 321,
];
/*@DOCKET_CACHE_EOF*/