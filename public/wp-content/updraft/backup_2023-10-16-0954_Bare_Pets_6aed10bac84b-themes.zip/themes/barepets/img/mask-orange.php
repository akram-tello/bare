<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1280" height="90" viewBox="0 0 1280 90">
  <defs>
    <clipPath id="clip-path">
      <rect id="Rectangle_1238" data-name="Rectangle 1238" width="1280" height="90" transform="translate(0 7532)" fill="#fff" stroke="#707070" stroke-width="1"/>
    </clipPath>
    <clipPath id="clip-path-2">
      <rect id="Rectangle_1237" data-name="Rectangle 1237" width="1280" height="838" transform="translate(0 7577)" fill="#fff"/>
    </clipPath>
    <linearGradient id="linear-gradient" x1="0.5" x2="0.5" y2="1" gradientUnits="objectBoundingBox">
      <stop offset="0" stop-color="#eb5b56"/>
      <stop offset="1" stop-color="#ea7b49"/>
    </linearGradient>
  </defs>
  <g id="Mask_Group_68" data-name="Mask Group 68" transform="translate(0 -7532)" clip-path="url(#clip-path)">
    <g id="BG_FAQs" transform="translate(0 -78)" clip-path="url(#clip-path-2)">
      <path id="Base9" d="M0,877.307S132.775,990.115,338.1,990.115,664.5,901.48,859.7,901.48s460.8,88.635,460.8,88.635L1337.4-8.643s-55.2-67.22-297.6-81.39S630-39.188,368.6-39.188,0-104.218,0-104.218Z" transform="translate(-28.7 7711.219)" fill="url(#linear-gradient)"/>
    </g>
  </g>
</svg>
