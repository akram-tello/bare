<svg xmlns="http://www.w3.org/2000/svg" width="69" height="59.992" viewBox="0 0 69 59.992">
  <g id="Badge_-_Checkout" data-name="Badge - Checkout" transform="translate(128.374 165.296)">
    <path id="Path_26068" data-name="Path 26068" d="M-64.308-32.192a29.886,29.886,0,0,1-11.116-2.124.469.469,0,0,1-.262-.609.469.469,0,0,1,.609-.262,28.951,28.951,0,0,0,10.769,2.057,28.956,28.956,0,0,0,10.77-2.057.468.468,0,0,1,.609.262.469.469,0,0,1-.262.609A29.889,29.889,0,0,1-64.308-32.192Z" transform="translate(-29.567 -73.113)" fill="#eb5b56"/>
    <text id="Safe_secured_checkout" data-name="Safe &amp; secured checkout" transform="translate(-128.374 -140.844)" fill="#eb5b56" font-size="9" font-family="FuturaPT-Bold, Futura PT" font-weight="700" letter-spacing="0.01em"><tspan x="-14.823" y="9">SAFE &amp; </tspan><tspan x="-19.084" y="18">SECURED </tspan><tspan x="-23.153" y="27">CHECKOUT</tspan></text>
    <path id="unlock_secure_password_protection" data-name="unlock, secure, password, protection" d="M2,10v9a3,3,0,0,0,3,3H19a3,3,0,0,0,3-3V10a3,3,0,0,0-3-3H17V6A5,5,0,0,0,7.669,3.5,1,1,0,0,0,9.4,4.5,3,3,0,0,1,15,6V7H5a3,3,0,0,0-3,3Zm2,0A1,1,0,0,1,5,9H19a1,1,0,0,1,1,1v9a1,1,0,0,1-1,1H5a1,1,0,0,1-1-1Zm6,4.5a2,2,0,1,1,2,2A2,2,0,0,1,10,14.5Z" transform="translate(-105.874 -165.832)" fill="#eb5b56" stroke="rgba(255,150,146,0.2)" stroke-width="0.8"/>
  </g>
</svg>
