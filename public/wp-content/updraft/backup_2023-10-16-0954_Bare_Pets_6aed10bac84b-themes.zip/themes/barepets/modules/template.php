<?php 
  $heading = $fields['heading'];
?>

<div class="module module-template <?= !empty( $attributes['className'] ) ? $attributes['className'] : '' ?>">
  <div class="wrapper">

  </div>
</div>