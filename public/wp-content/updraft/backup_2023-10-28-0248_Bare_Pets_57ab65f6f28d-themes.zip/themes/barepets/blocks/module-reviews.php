<section class="module module--reviews">
    <div class="wrapper">
        <h2 class="module-title">people are barking</h2>
        <?php comments_template() ?>
    </div>
</section>