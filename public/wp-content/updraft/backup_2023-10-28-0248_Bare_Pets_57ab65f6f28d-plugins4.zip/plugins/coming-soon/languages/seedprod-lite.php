<?php
/* THIS IS A GENERATED FILE. DO NOT EDIT DIRECTLY. */
$generated_i18n_strings = array(
	// Reference: src/components/PostsOptions.vue:2237
	// Reference: src/components/TestimonialOptions.vue:606
	__( '1', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2238
	// Reference: src/components/TestimonialOptions.vue:607
	__( '2', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2239
	// Reference: src/components/TestimonialOptions.vue:608
	__( '3', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2240
	// Reference: src/components/TestimonialOptions.vue:609
	__( '4', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2241
	// Reference: src/components/TestimonialOptions.vue:610
	__( '5', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2242
	// Reference: src/components/TestimonialOptions.vue:611
	__( '6', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2243
	// Reference: src/components/TestimonialOptions.vue:612
	__( '7', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2244
	// Reference: src/components/TestimonialOptions.vue:613
	__( '8', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2245
	// Reference: src/components/TestimonialOptions.vue:614
	__( '9', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2246
	// Reference: src/components/TestimonialOptions.vue:615
	__( '10', 'coming-soon' ),

	// Reference: src/App.vue:238
	// Reference: src/views/Setup.vue:1671
	__( 'Changes not saved, are you sure you want to leave?', 'coming-soon' ),

	// Reference: src/admin/Aboutus.vue:36
	// Reference: src/admin/App.vue:318
	__( 'About Us', 'coming-soon' ),

	// Reference: src/admin/Aboutus.vue:37
	__( 'Getting Started', 'coming-soon' ),

	// Reference: src/admin/Aboutus.vue:38
	__( 'Lite vs Pro', 'coming-soon' ),

	// Reference: src/admin/AboutusAbout.vue:103
	__( 'Yup, we know a thing or two about building awesome products that customers love.', 'coming-soon' ),

	// Reference: src/admin/AboutusAbout.vue:107
	__( 'the most popular lead-generation software', 'coming-soon' ),

	// Reference: src/admin/AboutusAbout.vue:111
	__( 'the best WordPress analytics plugin', 'coming-soon' ),

	// Reference: src/admin/AboutusAbout.vue:115
	__( 'the best WordPress forms plugin', 'coming-soon' ),

	// Reference: src/admin/AboutusAbout.vue:119
	__( 'the best WordPress giveaway plugin', 'coming-soon' ),

	// Reference: src/admin/AboutusAbout.vue:123
	__( 'and finally the best WordPress FOMO plugin', 'coming-soon' ),

	// Reference: src/admin/AboutusAbout.vue:127
	__( 'SeedProd Team photo', 'coming-soon' ),

	// Reference: src/admin/AboutusAbout.vue:128
	__( 'The SeedProd Team', 'coming-soon' ),

	// Reference: src/admin/AboutusAbout.vue:87
	__( 'Hello and welcome to SeedProd, the most beginner friendly drag & drop WordPress landing page plugin. At SeedProd, we build software that helps you create beautiful responsive landing pages for your website in minutes.', 'coming-soon' ),

	// Reference: src/admin/AboutusAbout.vue:91
	__( 'Over the years, we found that most WordPress landing page plugins were bloated, buggy, slow, and very hard to use. So we started with a simple goal: build a WordPress landing page plugin that’s both easy and powerful.', 'coming-soon' ),

	// Reference: src/admin/AboutusAbout.vue:95
	__( 'Our goal is to take the pain out of creating landing pages and make it easy.', 'coming-soon' ),

	// Reference: src/admin/AboutusAbout.vue:99
	__( 'SeedProd is brought to you by the same team that’s behind the largest WordPress resource site,', 'coming-soon' ),

	// Reference: src/admin/App.vue:316
	__( 'Pages', 'coming-soon' ),

	// Reference: src/admin/App.vue:317
	__( 'Growth Tools', 'coming-soon' ),

	// Reference: src/admin/App.vue:319
	// Reference: src/admin/Dashboard-Lite.vue:644
	__( 'Subscribers', 'coming-soon' ),

	// Reference: src/admin/App.vue:320
	// Reference: src/components/CountdownOptions.vue:850
	// Reference: src/components/CounterOptions.vue:325
	// Reference: src/components/CustomHTMLOptions.vue:201
	// Reference: src/components/EDDAddToCartOptions.vue:837
	// Reference: src/components/EDDBuyNowButtonOptions.vue:867
	// Reference: src/components/EDDDownloadsGridOptions.vue:972
	// Reference: src/components/FormOptions.vue:178
	// Reference: src/components/NavOptions.vue:572
	// Reference: src/components/PostsOptions.vue:2208
	// Reference: src/components/ProductRelatedOptions.vue:606
	// Reference: src/components/ShortcodeOptions.vue:145
	// Reference: src/components/TemplatetagOptions.vue:123
	// Reference: src/components/WCAddToCartOptions.vue:735
	// Reference: src/components/WCCustomProductsGridOptions.vue:1077
	// Reference: src/views/Layoutnav.vue:1495
	__( 'Settings', 'coming-soon' ),

	// Reference: src/admin/App.vue:321
	// Reference: src/views/InlineHelpView.vue:263
	__( 'SeedProd Logo', 'coming-soon' ),

	// Reference: src/admin/App.vue:322
	__( 'Previous message ', 'coming-soon' ),

	// Reference: src/admin/App.vue:323
	__( 'Next message', 'coming-soon' ),

	// Reference: src/admin/App.vue:324
	__( 'Theme Builder', 'coming-soon' ),

	// Reference: src/admin/App.vue:325
	__( 'Import / Export', 'coming-soon' ),

	// Reference: src/admin/App.vue:326
	__( 'Setup', 'coming-soon' ),

	// Reference: src/admin/App.vue:327
	__( 'Theme Template Kit Chooser', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:1009
	// Reference: src/admin/Subscribers-Lite.vue:403
	__( 'Are you sure?', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:1015
	__( 'Yes, empty trash!', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:1039
	__( 'Pages Deleted!', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:1069
	__( 'Page Duplicated', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:615
	__( 'Coming Soon Mode', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:616
	__( 'Search Landing Pages', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:617
	__( 'The Coming Soon Page will be available to search engines if your site is not private.', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:621
	__( 'Set up a Coming Soon Page', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:622
	// Reference: src/admin/Setup-Lite.vue:874
	__( 'Edit Page', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:623
	// Reference: src/views/Setup.vue:1048
	__( 'Preview', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:624
	// Reference: src/components/ProductDataTabsOptions.vue:327
	// Reference: src/components/ProductGalleryImagesOptions.vue:199
	__( 'Active', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:625
	__( 'Inactive', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:626
	__( 'Maintenance Mode', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:627
	__( 'The Maintenance Mode Page will notify search engines that the site is unavailable.', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:631
	__( 'Set up a Maintenance Mode Page', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:635
	// Reference: src/admin/Subscribers-Lite.vue:256
	__( '404 Page', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:636
	__( 'Replace your default theme 404 page with a custom high converting 404 page.', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:640
	__( 'Set up a 404 Page', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:641
	// Reference: src/admin/Subscribers-Lite.vue:257
	__( 'Landing Pages', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:642
	__( 'Add New Landing Page', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:643
	// Reference: src/components/TypographyControl.vue:275
	__( 'Edit', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:645
	// Reference: src/components/PostinfoOptions.vue:613
	// Reference: src/components/ProductMetaOptions.vue:339
	__( 'Duplicate', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:648
	__( 'Last Modified', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:649
	__( 'You do not have any landing pages yet.', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:653
	__( 'Create New Landing Page', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:656
	__( 'SeedProd Coming Soon Page', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:657
	__( 'SeedProd Maintenance Page', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:658
	__( 'SeedProd 404 Page', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:659
	__( 'Create Optin, Sales, Webinar, Thank You or any type of Landing Page you need.', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:663
	// Reference: src/admin/Subscribers-Lite.vue:266
	__( 'Login Page', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:664
	__( 'Create a Custom Login Page for your website. Optionally replace the default login page.', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:665
	__( 'Set up a Login Page', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:666
	__( 'SeedProd Login Page', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:685
	// Reference: src/admin/ThemeChooser.vue:801
	// Reference: src/admin/ThemeTemplates-Lite.vue:802
	// Reference: src/views/TemplateChooser-Lite.vue:1228
	__( 'All', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:689
	__( 'Published', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:693
	__( 'Drafts', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:702
	__( 'Trash', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:709
	__( 'Move To Trash', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:713
	__( 'Restore', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:717
	__( 'Delete Permanently', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:722
	// Reference: src/admin/Subscribers-Lite.vue:308
	// Reference: src/components/AnchorOptions.vue:77
	// Reference: src/components/PostauthorboxOptions.vue:338
	// Reference: src/components/TeamMemberOptions.vue:1032
	// Reference: src/components/TestimonialOptions.vue:595
	__( 'Name', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:727
	__( 'URL', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:732
	// Reference: src/components/EDDDownloadsGridOptions.vue:1041
	// Reference: src/components/PostinfoOptions.vue:582
	// Reference: src/components/PostsOptions.vue:2229
	// Reference: src/components/ProductRelatedOptions.vue:654
	// Reference: src/components/WCCustomProductsGridOptions.vue:1192
	__( 'Date', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:744
	// Reference: src/admin/Subscribers-Lite.vue:331
	// Reference: src/components/ListTable.vue:468
	__( 'Loading', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:957
	__( 'Pages Moved to Trash.', 'coming-soon' ),

	// Reference: src/admin/Dashboard-Lite.vue:990
	__( 'Pages Restored.', 'coming-soon' ),

	// Reference: src/admin/GrowthTools.vue:539
	// Reference: src/components/ContactForm.vue:170
	// Reference: src/components/Giveaway.vue:171
	// Reference: src/views/SettingsAnalytics.vue:131
	// Reference: src/views/SettingsSEO.vue:242
	__( 'Install', 'coming-soon' ),

	// Reference: src/admin/GrowthTools.vue:542
	__( 'Deactivate', 'coming-soon' ),

	// Reference: src/admin/GrowthTools.vue:545
	// Reference: src/components/ContactForm.vue:171
	// Reference: src/components/Giveaway.vue:172
	// Reference: src/views/SettingsAnalytics.vue:132
	// Reference: src/views/SettingsSEO.vue:243
	__( 'Activate', 'coming-soon' ),

	// Reference: src/admin/GrowthTools.vue:81
	// Reference: src/admin/Popups.vue:125
	__( 'Status', 'coming-soon' ),

	// Reference: src/admin/GrowthTools.vue:82
	__( 'PRO Version installed', 'coming-soon' ),

	// Reference: src/admin/Popups.vue:382
	__( 'Get OptinMonster Now', 'coming-soon' ),

	// Reference: src/admin/Popups.vue:385
	__( 'OptinMonster is Active - Go to Settings', 'coming-soon' ),

	// Reference: src/admin/Popups.vue:389
	__( 'Activate OptinMonster', 'coming-soon' ),

	// Reference: src/admin/Popups.vue:391
	__( 'Activating OptinMonster', 'coming-soon' ),

	// Reference: src/admin/Settings.vue:19
	// Reference: src/components/EDDDownloadsGridOptions.vue:1050
	// Reference: src/components/TeamMemberOptions.vue:1028
	// Reference: src/components/WCCustomProductsGridOptions.vue:1155
	// Reference: src/views/SettingsGeneral.vue:231
	// Reference: src/views/SetupSettings.vue:253
	__( 'General', 'coming-soon' ),

	// Reference: src/admin/Settings.vue:20
	__( 'Emails', 'coming-soon' ),

	// Reference: src/admin/Settings.vue:21
	__( 'Integrations', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:343
	__( 'License', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:344
	__( 'Your license key provides access to updates and addons.', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:345
	__( 'You\'re using <strong>SeedProd Lite</strong> - No License needed. Enjoy!', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:346
	__( 'To unlock more features consider <a href=\'%s\' target=\'_blank\'>upgrading to PRO</a> . As a valued SeedProd Lite user you\'ll receive <strong>a discount off the regular price</strong>, automatically applied at checkout! ', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:347
	__( 'If you already have a license key for <a href=\'%s\' target=\'_blank\'>SeedProd Lite</a>, please enter it to Upgrade to the Pro Features. SeedProd.com will be used to verify and connect you to SeedProd.', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:348
	__( 'License Key', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:349
	__( 'Enter Your License Key Here', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:350
	__( 'Recheck Key', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:351
	__( 'Verify Key', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:352
	__( 'Deactivate Key', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:353
	__( 'Connect to SeedProd to Install the Pro Version', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:354
	__( 'You currently have the <strong>%s</strong> license.', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:356
	__( 'Debug Information', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:357
	__( 'Facebook APP ID', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:358
	// Reference: src/views/SetupDesign-Lite.vue:731
	__( 'Global Settings', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:360
	__( 'Save Settings', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:361
	__( 'Disable Edit SeedProd Button', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:362
	__( 'Enable Usage Tracking', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:363
	__( 'Google Places API Key', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:364
	__( 'Yelp API Key', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:365
	__( 'Disable SeedProd Notifications', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:366
	// Reference: src/components/AlertBoxOptions.vue:798
	// Reference: src/components/BeforeAfterToggleOptions.vue:519
	// Reference: src/components/BusinessHoursOptions.vue:744
	// Reference: src/components/ContentToggleOptions.vue:609
	// Reference: src/components/PostsOptions.vue:2248
	// Reference: src/components/PriceListOptions.vue:914
	// Reference: src/components/TeamMemberOptions.vue:1083
	// Reference: src/components/TestimonialOptions.vue:600
	// Reference: src/views/SettingsAccess-Lite.vue:322
	__( 'Yes', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:367
	// Reference: src/components/AlertBoxOptions.vue:799
	// Reference: src/components/BeforeAfterToggleOptions.vue:520
	// Reference: src/components/BusinessHoursOptions.vue:745
	// Reference: src/components/ContentToggleOptions.vue:610
	// Reference: src/components/PostsOptions.vue:2249
	// Reference: src/components/PriceListOptions.vue:915
	// Reference: src/components/TeamMemberOptions.vue:1084
	// Reference: src/components/TestimonialOptions.vue:601
	// Reference: src/views/SettingsAccess-Lite.vue:323
	__( 'No', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:490
	// Reference: src/views/TemplateChooser-Lite.vue:1927
	__( 'Could not be saved. Please contact Support if you continue to experience this issue.', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:555
	// Reference: src/views/Setup.vue:1565
	__( 'Saved!', 'coming-soon' ),

	// Reference: src/admin/SettingsGeneral.vue:576
	__( 'Looks like you don\'t have permission to save.', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:853
	__( '<h1 class=\'sp-text-2xl sp-text-neutral sp-m-0 sp-mb-4 sp-font-bold\'>Template Setup Complete</h1>', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:854
	__( 'You can close this window and get started editing you page<br> or setup a new page.', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:855
	// Reference: src/components/ColorPicker.vue:266
	// Reference: src/components/CustomHTMLOptions.vue:205
	// Reference: src/components/TypographyControl.vue:276
	// Reference: src/views/GlobalCSS.vue:1907
	// Reference: src/views/InlineHelpView.vue:264
	// Reference: src/views/Setup.vue:1036
	// Reference: src/views/SetupDesign-Lite.vue:741
	__( 'Close', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:856
	__( 'Click the button below to install and activate the following free plugins:', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:857
	__( 'Install and Activate Plugins', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:858
	__( 'I\'ll do it later', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:864
	__( '<h1 class="sp-text-2xl sp-text-neutral sp-m-0 sp-mb-4 sp-font-bold">Finishing Up!</h1><p class="sp-text-sm sp-text-neutral sp-font-normal">Please do not refresh or exit this page<br>until this process is complete.<p>', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:869
	__( 'Setup a Coming Soon Page', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:870
	__( 'A Coming Soon Page will hide your site from public but you\'ll still be able to see it and work on it if logged in.', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:876
	__( 'Setup a Maintenance Page', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:877
	__( 'A Maintenance Page will notify search engines that the site is unavailable.', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:881
	__( 'Setup a Landing Page', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:882
	__( 'Landing Pages are meant to be standalone pages seperate from the design of your site and theme.', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:886
	__( 'Edit Landing Pages', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:887
	__( 'Build a Website', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:888
	__( 'Build your entire Website. Create Headers, Footers, Pages, Posts, Archives, Sidebars, and more.', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:892
	__( 'Select a Theme for my Website', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:896
	__( 'Edit Theme', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:897
	__( 'Build a WooCommerce Store', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:898
	__( 'Create an entire WooCommerce store. Customize product pages, checkout, cart, product grids, and more.', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:902
	__( 'Select a Theme for my Store', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:903
	__( 'Setup a Login Page', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:904
	__( 'Create a custom Login page for your website.', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:908
	__( 'Setup a 404 Page', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:909
	__( 'Create a custom 404 page for your website.', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:913
	__( 'Dismiss This Setup Page', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:914
	__( 'Finish Setup', 'coming-soon' ),

	// Reference: src/admin/Setup-Lite.vue:948
	__( 'There was an issue completing the setup. Please refresh the page and try again.', 'coming-soon' ),

	// Reference: src/admin/Subscribers-Lite.vue:250
	__( 'Subscribers Overview', 'coming-soon' ),

	// Reference: src/admin/Subscribers-Lite.vue:251
	__( 'Export to CSV', 'coming-soon' ),

	// Reference: src/admin/Subscribers-Lite.vue:253
	__( 'All Pages', 'coming-soon' ),

	// Reference: src/admin/Subscribers-Lite.vue:254
	__( 'Coming Soon Page', 'coming-soon' ),

	// Reference: src/admin/Subscribers-Lite.vue:255
	__( 'Maintenance Mode Page', 'coming-soon' ),

	// Reference: src/admin/Subscribers-Lite.vue:258
	__( 'Days', 'coming-soon' ),

	// Reference: src/admin/Subscribers-Lite.vue:260
	__( 'You do not have any subscribers yet.', 'coming-soon' ),

	// Reference: src/admin/Subscribers-Lite.vue:264
	__( 'Go to Pages', 'coming-soon' ),

	// Reference: src/admin/Subscribers-Lite.vue:265
	__( 'Search Emails', 'coming-soon' ),

	// Reference: src/admin/Subscribers-Lite.vue:304
	// Reference: src/components/SocialProfilesOptions.vue:685
	__( 'Email', 'coming-soon' ),

	// Reference: src/admin/Subscribers-Lite.vue:318
	__( 'Created', 'coming-soon' ),

	// Reference: src/admin/Subscribers-Lite.vue:325
	// Reference: src/components/PostinfoOptions.vue:614
	// Reference: src/components/ProductMetaOptions.vue:340
	__( 'Delete', 'coming-soon' ),

	// Reference: src/admin/Subscribers-Lite.vue:441
	__( 'Subscribers Deleted', 'coming-soon' ),

	// Reference: src/admin/Subscribers-Lite.vue:491
	__( 'Exported Started', 'coming-soon' ),

	// Reference: src/admin/ThemeChooser.vue:798
	// Reference: src/admin/ThemeTemplates-Lite.vue:799
	// Reference: src/views/TemplateChooser-Lite.vue:1222
	__( 'All Templates', 'coming-soon' ),

	// Reference: src/admin/ThemeChooser.vue:799
	// Reference: src/admin/ThemeTemplates-Lite.vue:800
	// Reference: src/views/TemplateChooser-Lite.vue:1223
	__( 'Favorite Templates', 'coming-soon' ),

	// Reference: src/admin/ThemeChooser.vue:800
	// Reference: src/admin/ThemeTemplates-Lite.vue:801
	// Reference: src/views/TemplateChooser-Lite.vue:1227
	__( 'Filter:', 'coming-soon' ),

	// Reference: src/admin/ThemeChooser.vue:802
	// Reference: src/admin/ThemeTemplates-Lite.vue:803
	// Reference: src/views/SectionTemplateOptions-Lite.vue:431
	// Reference: src/views/TemplateChooser-Lite.vue:1229
	__( 'No Templates Found', 'coming-soon' ),

	// Reference: src/admin/ThemeChooser.vue:803
	// Reference: src/admin/ThemeTemplates-Lite.vue:804
	// Reference: src/components/ImageControl.vue:254
	// Reference: src/views/TemplateChooser-Lite.vue:1243
	__( 'First Page', 'coming-soon' ),

	// Reference: src/admin/ThemeChooser.vue:804
	// Reference: src/admin/ThemeTemplates-Lite.vue:805
	// Reference: src/components/ImageControl.vue:255
	// Reference: src/views/TemplateChooser-Lite.vue:1244
	__( 'Prev', 'coming-soon' ),

	// Reference: src/admin/ThemeChooser.vue:805
	// Reference: src/admin/ThemeTemplates-Lite.vue:806
	// Reference: src/components/ImageControl.vue:256
	// Reference: src/views/TemplateChooser-Lite.vue:1245
	__( 'Next', 'coming-soon' ),

	// Reference: src/admin/ThemeChooser.vue:806
	// Reference: src/admin/ThemeTemplates-Lite.vue:807
	// Reference: src/components/ImageControl.vue:257
	// Reference: src/views/TemplateChooser-Lite.vue:1246
	__( 'Last Page', 'coming-soon' ),

	// Reference: src/admin/ThemeChooser.vue:807
	// Reference: src/admin/ThemeTemplates-Lite.vue:808
	// Reference: src/views/TemplateChooser-Lite.vue:1247
	__( 'Search templates...', 'coming-soon' ),

	// Reference: src/admin/ThemeChooser.vue:808
	// Reference: src/admin/ThemeTemplates-Lite.vue:809
	// Reference: src/views/SetupBlockOptions-Lite.vue:1413
	__( 'WooCommerce', 'coming-soon' ),

	// Reference: src/admin/ThemeChooser.vue:809
	// Reference: src/admin/ThemeTemplates-Lite.vue:810
	__( 'Sort:', 'coming-soon' ),

	// Reference: src/admin/Welcome-Lite.vue:120
	__( 'Thank you for choosing SeedProd - The Best Website Builder, Landing Page Builder, Coming Soon, Maintenance Mode & more...', 'coming-soon' ),

	// Reference: src/admin/Welcome-Lite.vue:124
	__( 'Get Started →', 'coming-soon' ),

	// Reference: src/admin/Welcome-Lite.vue:125
	__( '← Exit Setup', 'coming-soon' ),

	// Reference: src/admin/Welcome-Lite.vue:126
	__( 'Note: You will be transfered to an SeedProd.com to complete the setup wizard.', 'coming-soon' ),

	// Reference: src/admin/Welcome-Lite.vue:139
	__( 'Use our setup wizard to get started in less than 2 minutes and unlock free templates!', 'coming-soon' ),

	// Reference: src/admin/Welcome-Lite.vue:144
	__( 'Use our setup wizard to get started in less than 2 minutes!', 'coming-soon' ),

	// Reference: src/admin/Welcome-Lite.vue:156
	__( 'Are you sure you want to exit the setup wizard?

You will miss out on our free templates. 😬', 'coming-soon' ),

	// Reference: src/admin/Welcome-Lite.vue:161
	__( 'Are you sure you want to exit the setup wizard? 😬', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:601
	// Reference: src/components/AddToCartOptions.vue:1068
	// Reference: src/components/AdditionalInformationOptions.vue:129
	// Reference: src/components/AlertBoxOptions.vue:805
	// Reference: src/components/BeforeAfterToggleOptions.vue:508
	// Reference: src/components/BulletListOptions.vue:498
	// Reference: src/components/BusinessHoursOptions.vue:714
	// Reference: src/components/ButtonOptions.vue:1204
	// Reference: src/components/ColOptions.vue:664
	// Reference: src/components/ContactFormOptions.vue:293
	// Reference: src/components/ContentToggleOptions.vue:598
	// Reference: src/components/CountdownOptions.vue:847
	// Reference: src/components/CounterOptions.vue:322
	// Reference: src/components/CustomHTMLOptions.vue:199
	// Reference: src/components/DividerOptions.vue:360
	// Reference: src/components/EDDAddToCartOptions.vue:784
	// Reference: src/components/EDDBuyNowButtonOptions.vue:813
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:640
	// Reference: src/components/EDDDownloadPriceOptions.vue:103
	// Reference: src/components/EDDDownloadsGridOptions.vue:1020
	// Reference: src/components/FeatureOptions.vue:460
	// Reference: src/components/FormOptions.vue:176
	// Reference: src/components/GiveawayOptions.vue:165
	// Reference: src/components/GoogleMapsOptions.vue:234
	// Reference: src/components/HeaderOptions.vue:443
	// Reference: src/components/IconFeatureOptions.vue:450
	// Reference: src/components/IconOptions.vue:271
	// Reference: src/components/ImageOptions.vue:706
	// Reference: src/components/LoginOptions.vue:877
	// Reference: src/components/MenuCartOptions.vue:184
	// Reference: src/components/NavOptions.vue:570
	// Reference: src/components/OptinFormOptions.vue:844
	// Reference: src/components/PostauthorboxOptions.vue:336
	// Reference: src/components/PostcommentsOptions.vue:201
	// Reference: src/components/PostfeaturedimageOptions.vue:640
	// Reference: src/components/PostinfoOptions.vue:593
	// Reference: src/components/PostnavigationOptions.vue:95
	// Reference: src/components/PriceListOptions.vue:878
	// Reference: src/components/PricingTableOptions.vue:1274
	// Reference: src/components/ProductDataTabsOptions.vue:337
	// Reference: src/components/ProductFeaturedImageOptions.vue:640
	// Reference: src/components/ProductGalleryImagesOptions.vue:209
	// Reference: src/components/ProductMetaOptions.vue:330
	// Reference: src/components/ProductPriceOptions.vue:182
	// Reference: src/components/ProductRelatedOptions.vue:614
	// Reference: src/components/ProgressBarOptions.vue:321
	// Reference: src/components/RowOptions.vue:663
	// Reference: src/components/SectionOptions.vue:393
	// Reference: src/components/ShortcodeOptions.vue:143
	// Reference: src/components/SocialSharingOptions.vue:385
	// Reference: src/components/StarRatingOptions.vue:297
	// Reference: src/components/StripepaymentOptions.vue:1108
	// Reference: src/components/TeamMemberOptions.vue:1022
	// Reference: src/components/TemplatetagOptions.vue:121
	// Reference: src/components/TestimonialOptions.vue:590
	// Reference: src/components/TextOptions.vue:378
	// Reference: src/components/VideoOptions.vue:231
	// Reference: src/components/WCAddToCartOptions.vue:687
	// Reference: src/components/WCCustomProductsGridOptions.vue:1125
	// Reference: src/components/WpWidgetBlockOptions.vue:188
	__( 'Content', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:602
	// Reference: src/components/AddToCartOptions.vue:1069
	// Reference: src/components/AdditionalInformationOptions.vue:130
	// Reference: src/components/AlertBoxOptions.vue:755
	// Reference: src/components/BeforeAfterToggleOptions.vue:509
	// Reference: src/components/BulletListOptions.vue:499
	// Reference: src/components/BusinessHoursOptions.vue:719
	// Reference: src/components/ButtonOptions.vue:1205
	// Reference: src/components/ColOptions.vue:681
	// Reference: src/components/ContactFormOptions.vue:294
	// Reference: src/components/ContentToggleOptions.vue:599
	// Reference: src/components/CountdownOptions.vue:849
	// Reference: src/components/CounterOptions.vue:324
	// Reference: src/components/CustomHTMLOptions.vue:200
	// Reference: src/components/DividerOptions.vue:361
	// Reference: src/components/EDDAddToCartOptions.vue:785
	// Reference: src/components/EDDBuyNowButtonOptions.vue:814
	// Reference: src/components/EDDCartOptions.vue:355
	// Reference: src/components/EDDCheckoutOptions.vue:627
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:642
	// Reference: src/components/EDDDownloadPriceOptions.vue:104
	// Reference: src/components/EDDDownloadsGridOptions.vue:973
	// Reference: src/components/FeatureOptions.vue:461
	// Reference: src/components/FormOptions.vue:177
	// Reference: src/components/GiveawayOptions.vue:166
	// Reference: src/components/GoogleMapsOptions.vue:235
	// Reference: src/components/HeaderOptions.vue:444
	// Reference: src/components/IconFeatureOptions.vue:451
	// Reference: src/components/IconOptions.vue:272
	// Reference: src/components/ImageOptions.vue:708
	// Reference: src/components/LoginOptions.vue:878
	// Reference: src/components/MenuCartOptions.vue:185
	// Reference: src/components/NavOptions.vue:571
	// Reference: src/components/OptinFormOptions.vue:846
	// Reference: src/components/PostauthorboxOptions.vue:337
	// Reference: src/components/PostcommentsOptions.vue:202
	// Reference: src/components/PostfeaturedimageOptions.vue:642
	// Reference: src/components/PostinfoOptions.vue:594
	// Reference: src/components/PostnavigationOptions.vue:96
	// Reference: src/components/PostsOptions.vue:2209
	// Reference: src/components/PriceListOptions.vue:883
	// Reference: src/components/PricingTableOptions.vue:1275
	// Reference: src/components/ProductDataTabsOptions.vue:338
	// Reference: src/components/ProductFeaturedImageOptions.vue:642
	// Reference: src/components/ProductGalleryImagesOptions.vue:210
	// Reference: src/components/ProductMetaOptions.vue:331
	// Reference: src/components/ProductPriceOptions.vue:183
	// Reference: src/components/ProductRelatedOptions.vue:607
	// Reference: src/components/ProgressBarOptions.vue:323
	// Reference: src/components/RowOptions.vue:680
	// Reference: src/components/SectionOptions.vue:394
	// Reference: src/components/ShortcodeOptions.vue:144
	// Reference: src/components/SocialSharingOptions.vue:386
	// Reference: src/components/StarRatingOptions.vue:298
	// Reference: src/components/StripepaymentOptions.vue:1109
	// Reference: src/components/TeamMemberOptions.vue:1027
	// Reference: src/components/TemplatetagOptions.vue:122
	// Reference: src/components/TestimonialOptions.vue:591
	// Reference: src/components/TextOptions.vue:379
	// Reference: src/components/VideoOptions.vue:232
	// Reference: src/components/WCAddToCartOptions.vue:688
	// Reference: src/components/WCCartOptions.vue:497
	// Reference: src/components/WCCheckoutOptions.vue:765
	// Reference: src/components/WCCustomProductsGridOptions.vue:1078
	// Reference: src/components/WpWidgetBlockOptions.vue:189
	// Reference: src/views/SetupBlockOptions-Lite.vue:1409
	__( 'Advanced', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:603
	__( 'Accordion', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:604
	// Reference: src/components/BulletListOptions.vue:501
	// Reference: src/components/BusinessHoursOptions.vue:721
	// Reference: src/components/FormOptions.vue:179
	// Reference: src/components/NavOptions.vue:573
	// Reference: src/components/PriceListOptions.vue:885
	// Reference: src/components/PricingTableOptions.vue:1277
	// Reference: src/components/TeamMemberOptions.vue:1049
	__( 'Add New Item', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:605
	// Reference: src/components/BulletListOptions.vue:502
	// Reference: src/components/FontSizeControl.vue:87
	// Reference: src/components/HeaderOptions.vue:449
	// Reference: src/components/NavOptions.vue:574
	// Reference: src/components/OptinFormOptions.vue:894
	// Reference: src/components/ProductGalleryImagesOptions.vue:217
	// Reference: src/components/TextOptions.vue:383
	// Reference: src/components/TypographyControl.vue:278
	__( 'Font Size', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:606
	// Reference: src/components/AddToCartOptions.vue:1072
	// Reference: src/components/BusinessHoursOptions.vue:724
	// Reference: src/components/ColOptions.vue:693
	// Reference: src/components/CountdownOptions.vue:877
	// Reference: src/components/NavOptions.vue:575
	// Reference: src/components/PostinfoOptions.vue:591
	// Reference: src/components/PriceListOptions.vue:888
	// Reference: src/components/PricingTableOptions.vue:1338
	// Reference: src/components/ProductMetaOptions.vue:328
	// Reference: src/components/ProductPriceOptions.vue:187
	// Reference: src/components/RowOptions.vue:692
	// Reference: src/components/SocialProfilesOptions.vue:697
	// Reference: src/components/SocialSharingOptions.vue:406
	// Reference: src/components/SpaceBetweenControl.vue:84
	// Reference: src/components/StarRatingOptions.vue:305
	// Reference: src/components/TeamMemberOptions.vue:1059
	__( 'Space Between', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:607
	// Reference: src/components/AddToCartOptions.vue:1073
	// Reference: src/components/AlertBoxOptions.vue:757
	// Reference: src/components/BulletListOptions.vue:503
	// Reference: src/components/BusinessHoursOptions.vue:727
	// Reference: src/components/ButtonOptions.vue:1209
	// Reference: src/components/CountdownOptions.vue:887
	// Reference: src/components/CounterOptions.vue:341
	// Reference: src/components/DividerOptions.vue:363
	// Reference: src/components/EDDAddToCartOptions.vue:790
	// Reference: src/components/EDDBuyNowButtonOptions.vue:819
	// Reference: src/components/EDDCartOptions.vue:353
	// Reference: src/components/EDDCheckoutOptions.vue:625
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:645
	// Reference: src/components/EDDDownloadsGridOptions.vue:971
	// Reference: src/components/GoogleMapsOptions.vue:236
	// Reference: src/components/HeaderOptions.vue:446
	// Reference: src/components/IconOptions.vue:273
	// Reference: src/components/ImageOptions.vue:711
	// Reference: src/components/MenuCartOptions.vue:187
	// Reference: src/components/PostauthorboxOptions.vue:356
	// Reference: src/components/PostfeaturedimageOptions.vue:645
	// Reference: src/components/PostsOptions.vue:2207
	// Reference: src/components/PriceListOptions.vue:892
	// Reference: src/components/ProductFeaturedImageOptions.vue:645
	// Reference: src/components/ProductGalleryImagesOptions.vue:213
	// Reference: src/components/ProductRelatedOptions.vue:605
	// Reference: src/components/ProgressBarOptions.vue:341
	// Reference: src/components/RowOptions.vue:666
	// Reference: src/components/SocialProfilesOptions.vue:704
	// Reference: src/components/SocialSharingOptions.vue:389
	// Reference: src/components/StarRatingOptions.vue:300
	// Reference: src/components/StripepaymentOptions.vue:1113
	// Reference: src/components/TeamMemberOptions.vue:1062
	// Reference: src/components/TextOptions.vue:381
	// Reference: src/components/VideoOptions.vue:234
	// Reference: src/components/WCAddToCartOptions.vue:692
	// Reference: src/components/WCCartOptions.vue:495
	// Reference: src/components/WCCheckoutOptions.vue:763
	// Reference: src/components/WCCustomProductsGridOptions.vue:1076
	// Reference: src/components/WpWidgetBlockOptions.vue:191
	__( 'Styles', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:608
	// Reference: src/components/BulletListOptions.vue:504
	// Reference: src/components/BusinessHoursOptions.vue:728
	// Reference: src/components/NavOptions.vue:577
	// Reference: src/components/PriceListOptions.vue:893
	// Reference: src/components/TeamMemberOptions.vue:1063
	__( 'List Layout', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:609
	// Reference: src/components/BeforeAfterToggleOptions.vue:512
	// Reference: src/components/BulletListOptions.vue:505
	// Reference: src/components/BusinessHoursOptions.vue:729
	// Reference: src/components/ColOptions.vue:683
	// Reference: src/components/ContentToggleOptions.vue:602
	// Reference: src/components/NavOptions.vue:578
	// Reference: src/components/PriceListOptions.vue:894
	// Reference: src/components/RowOptions.vue:682
	// Reference: src/components/ShadowControl.vue:140
	// Reference: src/components/TeamMemberOptions.vue:1064
	__( 'Vertical', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:610
	// Reference: src/components/BeforeAfterToggleOptions.vue:513
	// Reference: src/components/BulletListOptions.vue:506
	// Reference: src/components/BusinessHoursOptions.vue:730
	// Reference: src/components/ColOptions.vue:682
	// Reference: src/components/ContentToggleOptions.vue:603
	// Reference: src/components/NavOptions.vue:579
	// Reference: src/components/PriceListOptions.vue:895
	// Reference: src/components/RowOptions.vue:681
	// Reference: src/components/ShadowControl.vue:139
	// Reference: src/components/TeamMemberOptions.vue:1065
	__( 'Horizontal', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:611
	// Reference: src/components/AdditionalInformationOptions.vue:128
	// Reference: src/components/BulletListOptions.vue:507
	// Reference: src/components/ContactFormOptions.vue:297
	// Reference: src/components/DividerOptions.vue:392
	// Reference: src/components/EDDDownloadsGridOptions.vue:1015
	// Reference: src/components/GiveawayOptions.vue:169
	// Reference: src/components/NavOptions.vue:580
	// Reference: src/components/PostinfoOptions.vue:617
	// Reference: src/components/ProductDataTabsOptions.vue:328
	// Reference: src/components/ProductGalleryImagesOptions.vue:200
	// Reference: src/components/ProductMetaOptions.vue:343
	// Reference: src/components/StarRatingOptions.vue:307
	// Reference: src/components/WCCartOptions.vue:539
	// Reference: src/components/WCCheckoutOptions.vue:807
	// Reference: src/components/WCCustomProductsGridOptions.vue:1120
	// Reference: src/components/WpWidgetBlockOptions.vue:186
	__( 'Text Color', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:612
	// Reference: src/components/BulletListOptions.vue:508
	// Reference: src/components/BusinessHoursOptions.vue:732
	// Reference: src/components/EDDDownloadsGridOptions.vue:1022
	// Reference: src/components/PriceListOptions.vue:897
	// Reference: src/components/SpacingSectionControl.vue:74
	// Reference: src/components/TeamMemberOptions.vue:1067
	// Reference: src/components/WCCustomProductsGridOptions.vue:1127
	__( 'Spacing', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:613
	// Reference: src/components/BulletListOptions.vue:509
	// Reference: src/components/BusinessHoursOptions.vue:733
	// Reference: src/components/PriceListOptions.vue:898
	// Reference: src/components/SpacingSectionControl.vue:75
	// Reference: src/components/TeamMemberOptions.vue:1068
	__( 'Top Margin', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:614
	// Reference: src/components/BeforeAfterToggleOptions.vue:504
	// Reference: src/components/BulletListOptions.vue:510
	// Reference: src/components/ContentToggleOptions.vue:588
	// Reference: src/components/DividerOptions.vue:383
	// Reference: src/components/FeatureOptions.vue:456
	// Reference: src/components/HeaderOptions.vue:448
	// Reference: src/components/IconFeatureOptions.vue:446
	// Reference: src/components/NavOptions.vue:581
	// Reference: src/components/PostsOptions.vue:2284
	// Reference: src/components/PricingTableOptions.vue:1288
	// Reference: src/components/TestimonialOptions.vue:592
	// Reference: src/components/TextOptions.vue:382
	// Reference: src/views/GlobalCSS.vue:1913
	// Reference: src/views/SetupDesign-Lite.vue:747
	__( 'Text', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:615
	// Reference: src/components/AlertBoxOptions.vue:788
	// Reference: src/components/BeforeAfterToggleOptions.vue:498
	// Reference: src/components/BulletListOptions.vue:511
	// Reference: src/components/ContentToggleOptions.vue:578
	// Reference: src/components/DividerOptions.vue:382
	// Reference: src/components/FeatureOptions.vue:451
	// Reference: src/components/IconFeatureOptions.vue:441
	// Reference: src/components/IconOptions.vue:274
	// Reference: src/components/PostinfoOptions.vue:608
	// Reference: src/components/PricingTableOptions.vue:1289
	// Reference: src/components/SocialProfilesOptions.vue:703
	// Reference: src/components/TeamMemberOptions.vue:1069
	// Reference: src/components/TestimonialOptions.vue:584
	__( 'Icon', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:616
	// Reference: src/components/AddToCartOptions.vue:1083
	// Reference: src/components/AlertBoxOptions.vue:807
	// Reference: src/components/BulletListOptions.vue:512
	// Reference: src/components/BusinessHoursOptions.vue:737
	// Reference: src/components/ButtonOptions.vue:1222
	// Reference: src/components/CountdownOptions.vue:873
	// Reference: src/components/EDDAddToCartOptions.vue:802
	// Reference: src/components/EDDBuyNowButtonOptions.vue:831
	// Reference: src/components/EDDCartOptions.vue:361
	// Reference: src/components/EDDCheckoutOptions.vue:635
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:653
	// Reference: src/components/EDDDownloadsGridOptions.vue:981
	// Reference: src/components/ImageOptions.vue:719
	// Reference: src/components/OptinFormOptions.vue:870
	// Reference: src/components/PostfeaturedimageOptions.vue:653
	// Reference: src/components/PriceListOptions.vue:906
	// Reference: src/components/ProductFeaturedImageOptions.vue:653
	// Reference: src/components/ProgressBarOptions.vue:327
	// Reference: src/components/SocialProfilesOptions.vue:672
	// Reference: src/components/StripepaymentOptions.vue:1126
	// Reference: src/components/TeamMemberOptions.vue:1073
	// Reference: src/components/WCAddToCartOptions.vue:705
	// Reference: src/components/WCCartOptions.vue:505
	// Reference: src/components/WCCheckoutOptions.vue:773
	// Reference: src/components/WCCustomProductsGridOptions.vue:1086
	__( 'Choose Your Style', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:617
	__( 'Closed Icon Color', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:618
	__( 'Closed Icon', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:619
	__( 'Open Icon Color', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:620
	__( 'Open Icon', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:621
	// Reference: src/components/AdditionalInformationOptions.vue:127
	// Reference: src/components/EDDCartOptions.vue:372
	// Reference: src/components/EDDCheckoutOptions.vue:646
	// Reference: src/components/EDDDownloadsGridOptions.vue:1019
	// Reference: src/components/FeatureOptions.vue:459
	// Reference: src/components/IconFeatureOptions.vue:449
	// Reference: src/components/WCCartOptions.vue:543
	// Reference: src/components/WCCheckoutOptions.vue:811
	// Reference: src/components/WCCustomProductsGridOptions.vue:1124
	// Reference: src/views/GlobalCSS.vue:1939
	__( 'Header Color', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:622
	// Reference: src/components/PricingTableOptions.vue:1296
	__( 'Header Open Color', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:623
	// Reference: src/components/BusinessHoursOptions.vue:751
	// Reference: src/components/PricingTableOptions.vue:1297
	// Reference: src/components/ProductMetaOptions.vue:346
	// Reference: src/components/TeamMemberOptions.vue:1090
	__( 'Divider Color', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:624
	// Reference: src/components/AddToCartOptions.vue:1102
	// Reference: src/components/AlertBoxOptions.vue:782
	// Reference: src/components/BackgroundControl.vue:462
	// Reference: src/components/BeforeAfterToggleOptions.vue:505
	// Reference: src/components/BusinessHoursOptions.vue:741
	// Reference: src/components/ButtonOptions.vue:1241
	// Reference: src/components/ColOptions.vue:675
	// Reference: src/components/ContentToggleOptions.vue:589
	// Reference: src/components/EDDAddToCartOptions.vue:821
	// Reference: src/components/EDDBuyNowButtonOptions.vue:850
	// Reference: src/components/EDDCartOptions.vue:387
	// Reference: src/components/EDDCheckoutOptions.vue:667
	// Reference: src/components/EDDDownloadsGridOptions.vue:1014
	// Reference: src/components/FeatureOptions.vue:457
	// Reference: src/components/HeaderOptions.vue:463
	// Reference: src/components/IconFeatureOptions.vue:447
	// Reference: src/components/OptinFormOptions.vue:881
	// Reference: src/components/PostauthorboxOptions.vue:360
	// Reference: src/components/PostsOptions.vue:2349
	// Reference: src/components/PriceListOptions.vue:911
	// Reference: src/components/PricingTableOptions.vue:1334
	// Reference: src/components/ProductDataTabsOptions.vue:329
	// Reference: src/components/ProductGalleryImagesOptions.vue:219
	// Reference: src/components/ProgressBarOptions.vue:340
	// Reference: src/components/RowOptions.vue:677
	// Reference: src/components/SectionOptions.vue:391
	// Reference: src/components/SocialProfilesOptions.vue:717
	// Reference: src/components/StripepaymentOptions.vue:1145
	// Reference: src/components/TeamMemberOptions.vue:1079
	// Reference: src/components/TestimonialOptions.vue:587
	// Reference: src/components/TextOptions.vue:393
	// Reference: src/components/WCAddToCartOptions.vue:724
	// Reference: src/components/WCCartOptions.vue:538
	// Reference: src/components/WCCheckoutOptions.vue:806
	// Reference: src/components/WCCustomProductsGridOptions.vue:1119
	__( 'Background Color', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:625
	// Reference: src/components/AddToCartOptions.vue:1100
	// Reference: src/components/AlertBoxOptions.vue:770
	// Reference: src/components/BulletListOptions.vue:514
	// Reference: src/components/BusinessHoursOptions.vue:758
	// Reference: src/components/ButtonOptions.vue:1239
	// Reference: src/components/ColOptions.vue:667
	// Reference: src/components/EDDAddToCartOptions.vue:819
	// Reference: src/components/EDDBuyNowButtonOptions.vue:848
	// Reference: src/components/HeaderOptions.vue:455
	// Reference: src/components/NavOptions.vue:601
	// Reference: src/components/PriceListOptions.vue:947
	// Reference: src/components/PricingTableOptions.vue:1363
	// Reference: src/components/ProgressBarOptions.vue:330
	// Reference: src/components/StripepaymentOptions.vue:1143
	// Reference: src/components/TeamMemberOptions.vue:1126
	// Reference: src/components/TextOptions.vue:384
	// Reference: src/components/WCAddToCartOptions.vue:722
	__( 'Text Shadow', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:633
	// Reference: src/components/BulletListOptions.vue:522
	// Reference: src/components/BusinessHoursOptions.vue:766
	// Reference: src/components/PaddingControl.vue:312
	// Reference: src/components/PriceListOptions.vue:955
	// Reference: src/components/PricingTableOptions.vue:1371
	// Reference: src/components/TeamMemberOptions.vue:1134
	__( 'Padding', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:634
	// Reference: src/components/AnimationEffectControl.vue:269
	// Reference: src/components/BorderRadiusControl.vue:129
	// Reference: src/components/BorderWidthControl.vue:121
	// Reference: src/components/BulletListOptions.vue:523
	// Reference: src/components/BusinessHoursOptions.vue:767
	// Reference: src/components/DisplaySectionControl.vue:194
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:647
	// Reference: src/components/EDDDownloadsGridOptions.vue:1080
	// Reference: src/components/ImageOptions.vue:713
	// Reference: src/components/MarginControl.vue:333
	// Reference: src/components/PaddingControl.vue:313
	// Reference: src/components/ParticlesBackgroundControl.vue:311
	// Reference: src/components/PostfeaturedimageOptions.vue:647
	// Reference: src/components/PostsOptions.vue:2364
	// Reference: src/components/PriceListOptions.vue:956
	// Reference: src/components/PricingTableOptions.vue:1372
	// Reference: src/components/ProductFeaturedImageOptions.vue:647
	// Reference: src/components/ProductRelatedOptions.vue:647
	// Reference: src/components/ShapeDividerControl.vue:347
	// Reference: src/components/TeamMemberOptions.vue:1135
	// Reference: src/components/WCCustomProductsGridOptions.vue:1185
	__( 'Top', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:635
	// Reference: src/components/AnimationEffectControl.vue:268
	// Reference: src/components/BorderRadiusControl.vue:132
	// Reference: src/components/BorderWidthControl.vue:123
	// Reference: src/components/BulletListOptions.vue:524
	// Reference: src/components/BusinessHoursOptions.vue:768
	// Reference: src/components/DisplaySectionControl.vue:196
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:649
	// Reference: src/components/EDDDownloadsGridOptions.vue:1082
	// Reference: src/components/ImageOptions.vue:715
	// Reference: src/components/MarginControl.vue:335
	// Reference: src/components/PaddingControl.vue:315
	// Reference: src/components/ParticlesBackgroundControl.vue:312
	// Reference: src/components/PostfeaturedimageOptions.vue:649
	// Reference: src/components/PostsOptions.vue:2365
	// Reference: src/components/PriceListOptions.vue:957
	// Reference: src/components/PricingTableOptions.vue:1373
	// Reference: src/components/ProductFeaturedImageOptions.vue:649
	// Reference: src/components/ProductRelatedOptions.vue:649
	// Reference: src/components/ShapeDividerControl.vue:348
	// Reference: src/components/TeamMemberOptions.vue:1136
	// Reference: src/components/WCCustomProductsGridOptions.vue:1187
	__( 'Bottom', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:636
	// Reference: src/components/BorderRadiusControl.vue:131
	// Reference: src/components/BorderWidthControl.vue:122
	// Reference: src/components/BulletListOptions.vue:525
	// Reference: src/components/BusinessHoursOptions.vue:769
	// Reference: src/components/DisplaySectionControl.vue:195
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:648
	// Reference: src/components/EDDDownloadsGridOptions.vue:1081
	// Reference: src/components/ImageOptions.vue:714
	// Reference: src/components/MarginControl.vue:334
	// Reference: src/components/PaddingControl.vue:314
	// Reference: src/components/ParticlesBackgroundControl.vue:314
	// Reference: src/components/PostfeaturedimageOptions.vue:648
	// Reference: src/components/PostsOptions.vue:2366
	// Reference: src/components/PriceListOptions.vue:958
	// Reference: src/components/PricingTableOptions.vue:1374
	// Reference: src/components/ProductFeaturedImageOptions.vue:648
	// Reference: src/components/ProductRelatedOptions.vue:648
	// Reference: src/components/TeamMemberOptions.vue:1137
	// Reference: src/components/WCCustomProductsGridOptions.vue:1186
	__( 'Right', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:637
	// Reference: src/components/BorderRadiusControl.vue:130
	// Reference: src/components/BorderWidthControl.vue:124
	// Reference: src/components/BulletListOptions.vue:526
	// Reference: src/components/BusinessHoursOptions.vue:770
	// Reference: src/components/DisplaySectionControl.vue:197
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:650
	// Reference: src/components/EDDDownloadsGridOptions.vue:1083
	// Reference: src/components/ImageOptions.vue:716
	// Reference: src/components/MarginControl.vue:336
	// Reference: src/components/PaddingControl.vue:316
	// Reference: src/components/ParticlesBackgroundControl.vue:313
	// Reference: src/components/PostfeaturedimageOptions.vue:650
	// Reference: src/components/PostsOptions.vue:2367
	// Reference: src/components/PriceListOptions.vue:959
	// Reference: src/components/PricingTableOptions.vue:1375
	// Reference: src/components/ProductFeaturedImageOptions.vue:650
	// Reference: src/components/ProductRelatedOptions.vue:650
	// Reference: src/components/TeamMemberOptions.vue:1138
	// Reference: src/components/WCCustomProductsGridOptions.vue:1188
	__( 'Left', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:638
	// Reference: src/components/AddToCartOptions.vue:1101
	// Reference: src/components/ButtonOptions.vue:1240
	// Reference: src/components/CountdownOptions.vue:879
	// Reference: src/components/DividerOptions.vue:372
	// Reference: src/components/EDDAddToCartOptions.vue:820
	// Reference: src/components/EDDBuyNowButtonOptions.vue:849
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:654
	// Reference: src/components/EDDDownloadsGridOptions.vue:1065
	// Reference: src/components/GoogleMapsOptions.vue:238
	// Reference: src/components/IconOptions.vue:276
	// Reference: src/components/ImageOptions.vue:720
	// Reference: src/components/PostfeaturedimageOptions.vue:654
	// Reference: src/components/PostsOptions.vue:2301
	// Reference: src/components/PricingTableOptions.vue:1376
	// Reference: src/components/ProductFeaturedImageOptions.vue:654
	// Reference: src/components/ProductRelatedOptions.vue:632
	// Reference: src/components/ProgressBarOptions.vue:338
	// Reference: src/components/RowOptions.vue:669
	// Reference: src/components/SectionOptions.vue:378
	// Reference: src/components/ShadowControl.vue:129
	// Reference: src/components/SocialProfilesOptions.vue:698
	// Reference: src/components/SocialSharingOptions.vue:407
	// Reference: src/components/StripepaymentOptions.vue:1144
	// Reference: src/components/TextOptions.vue:392
	// Reference: src/components/VideoOptions.vue:241
	// Reference: src/components/WCAddToCartOptions.vue:723
	// Reference: src/components/WCCustomProductsGridOptions.vue:1170
	__( 'Shadow', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:639
	// Reference: src/components/AddToCartOptions.vue:1109
	// Reference: src/components/AlertBoxOptions.vue:771
	// Reference: src/components/BulletListOptions.vue:515
	// Reference: src/components/BusinessHoursOptions.vue:759
	// Reference: src/components/ButtonOptions.vue:1250
	// Reference: src/components/ColOptions.vue:668
	// Reference: src/components/CountdownOptions.vue:880
	// Reference: src/components/DividerOptions.vue:380
	// Reference: src/components/EDDAddToCartOptions.vue:828
	// Reference: src/components/EDDBuyNowButtonOptions.vue:857
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:655
	// Reference: src/components/EDDDownloadsGridOptions.vue:1070
	// Reference: src/components/GoogleMapsOptions.vue:239
	// Reference: src/components/HeaderOptions.vue:456
	// Reference: src/components/IconOptions.vue:277
	// Reference: src/components/ImageOptions.vue:743
	// Reference: src/components/NavOptions.vue:602
	// Reference: src/components/PostauthorboxOptions.vue:353
	// Reference: src/components/PostfeaturedimageOptions.vue:655
	// Reference: src/components/PostinfoOptions.vue:609
	// Reference: src/components/PostsOptions.vue:2306
	// Reference: src/components/PriceListOptions.vue:948
	// Reference: src/components/PricingTableOptions.vue:1377
	// Reference: src/components/ProductFeaturedImageOptions.vue:655
	// Reference: src/components/ProductRelatedOptions.vue:637
	// Reference: src/components/ProgressBarOptions.vue:331
	// Reference: src/components/RowOptions.vue:670
	// Reference: src/components/SectionOptions.vue:379
	// Reference: src/components/ShadowControl.vue:130
	// Reference: src/components/ShapeDividerControl.vue:350
	// Reference: src/components/SocialProfilesOptions.vue:699
	// Reference: src/components/SocialSharingOptions.vue:399
	// Reference: src/components/StripepaymentOptions.vue:1154
	// Reference: src/components/TeamMemberOptions.vue:1127
	// Reference: src/components/TextOptions.vue:385
	// Reference: src/components/VideoOptions.vue:242
	// Reference: src/components/WCAddToCartOptions.vue:725
	// Reference: src/components/WCCustomProductsGridOptions.vue:1175
	__( 'None', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:640
	// Reference: src/components/AddToCartOptions.vue:1110
	// Reference: src/components/AlertBoxOptions.vue:772
	// Reference: src/components/BulletListOptions.vue:516
	// Reference: src/components/BusinessHoursOptions.vue:760
	// Reference: src/components/ButtonOptions.vue:1251
	// Reference: src/components/ColOptions.vue:669
	// Reference: src/components/CountdownOptions.vue:881
	// Reference: src/components/DividerOptions.vue:374
	// Reference: src/components/EDDAddToCartOptions.vue:829
	// Reference: src/components/EDDBuyNowButtonOptions.vue:858
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:656
	// Reference: src/components/EDDDownloadsGridOptions.vue:1071
	// Reference: src/components/GoogleMapsOptions.vue:240
	// Reference: src/components/HeaderOptions.vue:457
	// Reference: src/components/IconOptions.vue:278
	// Reference: src/components/ImageOptions.vue:722
	// Reference: src/components/NavOptions.vue:603
	// Reference: src/components/PostfeaturedimageOptions.vue:656
	// Reference: src/components/PostsOptions.vue:2307
	// Reference: src/components/PriceListOptions.vue:949
	// Reference: src/components/PricingTableOptions.vue:1378
	// Reference: src/components/ProductFeaturedImageOptions.vue:656
	// Reference: src/components/ProductRelatedOptions.vue:638
	// Reference: src/components/ProgressBarOptions.vue:332
	// Reference: src/components/RowOptions.vue:671
	// Reference: src/components/SectionOptions.vue:380
	// Reference: src/components/ShadowControl.vue:131
	// Reference: src/components/SocialProfilesOptions.vue:700
	// Reference: src/components/SocialSharingOptions.vue:400
	// Reference: src/components/StripepaymentOptions.vue:1155
	// Reference: src/components/TeamMemberOptions.vue:1128
	// Reference: src/components/TextOptions.vue:386
	// Reference: src/components/VideoOptions.vue:243
	// Reference: src/components/WCAddToCartOptions.vue:726
	// Reference: src/components/WCCustomProductsGridOptions.vue:1176
	__( 'Hairline', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:641
	// Reference: src/components/AddToCartOptions.vue:1111
	// Reference: src/components/AlertBoxOptions.vue:773
	// Reference: src/components/BulletListOptions.vue:517
	// Reference: src/components/BusinessHoursOptions.vue:761
	// Reference: src/components/ButtonOptions.vue:1252
	// Reference: src/components/ColOptions.vue:670
	// Reference: src/components/ContentToggleOptions.vue:624
	// Reference: src/components/CountdownOptions.vue:882
	// Reference: src/components/DividerOptions.vue:375
	// Reference: src/components/EDDAddToCartOptions.vue:830
	// Reference: src/components/EDDBuyNowButtonOptions.vue:859
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:657
	// Reference: src/components/EDDDownloadsGridOptions.vue:1072
	// Reference: src/components/GoogleMapsOptions.vue:241
	// Reference: src/components/HeaderOptions.vue:458
	// Reference: src/components/IconOptions.vue:279
	// Reference: src/components/ImageOptions.vue:723
	// Reference: src/components/LoginOptions.vue:923
	// Reference: src/components/NavOptions.vue:604
	// Reference: src/components/OptinFormOptions.vue:858
	// Reference: src/components/PostfeaturedimageOptions.vue:657
	// Reference: src/components/PostsOptions.vue:2308
	// Reference: src/components/PriceListOptions.vue:950
	// Reference: src/components/PricingTableOptions.vue:1379
	// Reference: src/components/ProductFeaturedImageOptions.vue:657
	// Reference: src/components/ProductRelatedOptions.vue:639
	// Reference: src/components/ProgressBarOptions.vue:333
	// Reference: src/components/RowOptions.vue:672
	// Reference: src/components/SectionOptions.vue:381
	// Reference: src/components/ShadowControl.vue:132
	// Reference: src/components/SocialProfilesOptions.vue:691
	// Reference: src/components/SocialSharingOptions.vue:401
	// Reference: src/components/StripepaymentOptions.vue:1156
	// Reference: src/components/TeamMemberOptions.vue:1129
	// Reference: src/components/TextOptions.vue:387
	// Reference: src/components/VideoOptions.vue:244
	// Reference: src/components/WCAddToCartOptions.vue:727
	// Reference: src/components/WCCustomProductsGridOptions.vue:1177
	__( 'Small', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:642
	// Reference: src/components/AddToCartOptions.vue:1112
	// Reference: src/components/AlertBoxOptions.vue:774
	// Reference: src/components/BulletListOptions.vue:518
	// Reference: src/components/BusinessHoursOptions.vue:762
	// Reference: src/components/ButtonOptions.vue:1253
	// Reference: src/components/ColOptions.vue:671
	// Reference: src/components/ContentToggleOptions.vue:623
	// Reference: src/components/CountdownOptions.vue:883
	// Reference: src/components/DividerOptions.vue:376
	// Reference: src/components/EDDAddToCartOptions.vue:831
	// Reference: src/components/EDDBuyNowButtonOptions.vue:860
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:658
	// Reference: src/components/EDDDownloadsGridOptions.vue:1073
	// Reference: src/components/GoogleMapsOptions.vue:242
	// Reference: src/components/HeaderOptions.vue:459
	// Reference: src/components/IconOptions.vue:280
	// Reference: src/components/ImageOptions.vue:724
	// Reference: src/components/LoginOptions.vue:924
	// Reference: src/components/NavOptions.vue:605
	// Reference: src/components/OptinFormOptions.vue:859
	// Reference: src/components/PostfeaturedimageOptions.vue:658
	// Reference: src/components/PostsOptions.vue:2309
	// Reference: src/components/PriceListOptions.vue:951
	// Reference: src/components/PricingTableOptions.vue:1380
	// Reference: src/components/ProductFeaturedImageOptions.vue:658
	// Reference: src/components/ProductRelatedOptions.vue:640
	// Reference: src/components/ProgressBarOptions.vue:334
	// Reference: src/components/RowOptions.vue:673
	// Reference: src/components/SectionOptions.vue:382
	// Reference: src/components/ShadowControl.vue:133
	// Reference: src/components/SocialProfilesOptions.vue:706
	// Reference: src/components/SocialSharingOptions.vue:402
	// Reference: src/components/StripepaymentOptions.vue:1157
	// Reference: src/components/TeamMemberOptions.vue:1130
	// Reference: src/components/TextOptions.vue:388
	// Reference: src/components/VideoOptions.vue:245
	// Reference: src/components/WCAddToCartOptions.vue:728
	// Reference: src/components/WCCustomProductsGridOptions.vue:1178
	__( 'Medium', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:643
	// Reference: src/components/AddToCartOptions.vue:1113
	// Reference: src/components/AlertBoxOptions.vue:775
	// Reference: src/components/BulletListOptions.vue:519
	// Reference: src/components/BusinessHoursOptions.vue:763
	// Reference: src/components/ButtonOptions.vue:1254
	// Reference: src/components/ColOptions.vue:672
	// Reference: src/components/ContentToggleOptions.vue:622
	// Reference: src/components/CountdownOptions.vue:884
	// Reference: src/components/DividerOptions.vue:377
	// Reference: src/components/EDDAddToCartOptions.vue:832
	// Reference: src/components/EDDBuyNowButtonOptions.vue:861
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:659
	// Reference: src/components/EDDDownloadsGridOptions.vue:1074
	// Reference: src/components/GoogleMapsOptions.vue:243
	// Reference: src/components/HeaderOptions.vue:460
	// Reference: src/components/IconOptions.vue:281
	// Reference: src/components/ImageOptions.vue:725
	// Reference: src/components/LoginOptions.vue:925
	// Reference: src/components/NavOptions.vue:606
	// Reference: src/components/OptinFormOptions.vue:860
	// Reference: src/components/PostfeaturedimageOptions.vue:659
	// Reference: src/components/PostsOptions.vue:2310
	// Reference: src/components/PriceListOptions.vue:952
	// Reference: src/components/PricingTableOptions.vue:1381
	// Reference: src/components/ProductFeaturedImageOptions.vue:659
	// Reference: src/components/ProductRelatedOptions.vue:641
	// Reference: src/components/ProgressBarOptions.vue:335
	// Reference: src/components/RowOptions.vue:674
	// Reference: src/components/SectionOptions.vue:383
	// Reference: src/components/ShadowControl.vue:134
	// Reference: src/components/SocialProfilesOptions.vue:693
	// Reference: src/components/SocialSharingOptions.vue:403
	// Reference: src/components/StripepaymentOptions.vue:1158
	// Reference: src/components/TeamMemberOptions.vue:1131
	// Reference: src/components/TextOptions.vue:389
	// Reference: src/components/VideoOptions.vue:246
	// Reference: src/components/WCAddToCartOptions.vue:729
	// Reference: src/components/WCCustomProductsGridOptions.vue:1179
	__( 'Large', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:644
	// Reference: src/components/AddToCartOptions.vue:1114
	// Reference: src/components/AlertBoxOptions.vue:776
	// Reference: src/components/BulletListOptions.vue:520
	// Reference: src/components/BusinessHoursOptions.vue:764
	// Reference: src/components/ButtonOptions.vue:1255
	// Reference: src/components/ColOptions.vue:673
	// Reference: src/components/CountdownOptions.vue:885
	// Reference: src/components/EDDAddToCartOptions.vue:833
	// Reference: src/components/EDDBuyNowButtonOptions.vue:862
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:660
	// Reference: src/components/EDDDownloadsGridOptions.vue:1075
	// Reference: src/components/GoogleMapsOptions.vue:244
	// Reference: src/components/HeaderOptions.vue:461
	// Reference: src/components/IconOptions.vue:282
	// Reference: src/components/ImageOptions.vue:726
	// Reference: src/components/LoginOptions.vue:926
	// Reference: src/components/NavOptions.vue:607
	// Reference: src/components/OptinFormOptions.vue:861
	// Reference: src/components/PostfeaturedimageOptions.vue:660
	// Reference: src/components/PostsOptions.vue:2311
	// Reference: src/components/PriceListOptions.vue:953
	// Reference: src/components/PricingTableOptions.vue:1382
	// Reference: src/components/ProductFeaturedImageOptions.vue:660
	// Reference: src/components/ProductRelatedOptions.vue:642
	// Reference: src/components/ProgressBarOptions.vue:336
	// Reference: src/components/RowOptions.vue:675
	// Reference: src/components/SectionOptions.vue:384
	// Reference: src/components/ShadowControl.vue:135
	// Reference: src/components/SocialProfilesOptions.vue:701
	// Reference: src/components/SocialSharingOptions.vue:404
	// Reference: src/components/StripepaymentOptions.vue:1159
	// Reference: src/components/TeamMemberOptions.vue:1132
	// Reference: src/components/TextOptions.vue:390
	// Reference: src/components/VideoOptions.vue:247
	// Reference: src/components/WCAddToCartOptions.vue:730
	// Reference: src/components/WCCustomProductsGridOptions.vue:1180
	__( 'X Large', 'coming-soon' ),

	// Reference: src/components/AccordionOptions.vue:645
	// Reference: src/components/AddToCartOptions.vue:1115
	// Reference: src/components/AlertBoxOptions.vue:777
	// Reference: src/components/BulletListOptions.vue:521
	// Reference: src/components/BusinessHoursOptions.vue:765
	// Reference: src/components/ButtonOptions.vue:1256
	// Reference: src/components/ColOptions.vue:674
	// Reference: src/components/CountdownOptions.vue:886
	// Reference: src/components/EDDAddToCartOptions.vue:834
	// Reference: src/components/EDDBuyNowButtonOptions.vue:863
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:661
	// Reference: src/components/EDDDownloadsGridOptions.vue:1076
	// Reference: src/components/GoogleMapsOptions.vue:245
	// Reference: src/components/HeaderOptions.vue:462
	// Reference: src/components/IconOptions.vue:283
	// Reference: src/components/ImageOptions.vue:727
	// Reference: src/components/LoginOptions.vue:927
	// Reference: src/components/NavOptions.vue:608
	// Reference: src/components/OptinFormOptions.vue:862
	// Reference: src/components/PostfeaturedimageOptions.vue:661
	// Reference: src/components/PostsOptions.vue:2312
	// Reference: src/components/PriceListOptions.vue:954
	// Reference: src/components/PricingTableOptions.vue:1383
	// Reference: src/components/ProductFeaturedImageOptions.vue:661
	// Reference: src/components/ProductRelatedOptions.vue:643
	// Reference: src/components/ProgressBarOptions.vue:337
	// Reference: src/components/RowOptions.vue:676
	// Reference: src/components/SectionOptions.vue:385
	// Reference: src/components/ShadowControl.vue:136
	// Reference: src/components/SocialSharingOptions.vue:405
	// Reference: src/components/StripepaymentOptions.vue:1160
	// Reference: src/components/TeamMemberOptions.vue:1133
	// Reference: src/components/TextOptions.vue:391
	// Reference: src/components/VideoOptions.vue:248
	// Reference: src/components/WCAddToCartOptions.vue:731
	// Reference: src/components/WCCustomProductsGridOptions.vue:1181
	__( '2X Large', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1070
	// Reference: src/components/ButtonOptions.vue:1206
	// Reference: src/components/EDDAddToCartOptions.vue:786
	// Reference: src/components/EDDBuyNowButtonOptions.vue:815
	// Reference: src/components/EDDDownloadsGridOptions.vue:1055
	// Reference: src/components/LoginOptions.vue:903
	// Reference: src/components/OptinFormOptions.vue:852
	// Reference: src/components/ProductRelatedOptions.vue:622
	// Reference: src/components/StripepaymentOptions.vue:1110
	// Reference: src/components/WCAddToCartOptions.vue:689
	// Reference: src/components/WCCustomProductsGridOptions.vue:1160
	// Reference: src/views/GlobalCSS.vue:1983
	__( 'Button', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1071
	// Reference: src/components/ButtonOptions.vue:1207
	// Reference: src/components/EDDAddToCartOptions.vue:787
	// Reference: src/components/EDDBuyNowButtonOptions.vue:816
	// Reference: src/components/LoginOptions.vue:888
	// Reference: src/components/StripepaymentOptions.vue:1111
	// Reference: src/components/WCAddToCartOptions.vue:690
	__( 'Button Text', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1074
	// Reference: src/components/BackgroundControl.vue:481
	// Reference: src/components/BeforeAfterToggleOptions.vue:500
	// Reference: src/components/ButtonOptions.vue:1213
	// Reference: src/components/ContentToggleOptions.vue:584
	// Reference: src/components/CountdownOptions.vue:858
	// Reference: src/components/EDDAddToCartOptions.vue:793
	// Reference: src/components/EDDBuyNowButtonOptions.vue:822
	// Reference: src/components/FeatureOptions.vue:453
	// Reference: src/components/IconFeatureOptions.vue:443
	// Reference: src/components/IconOptions.vue:275
	// Reference: src/components/OptinFormOptions.vue:856
	// Reference: src/components/PostinfoOptions.vue:589
	// Reference: src/components/SocialProfilesOptions.vue:690
	// Reference: src/components/SocialSharingOptions.vue:398
	// Reference: src/components/StarRatingOptions.vue:304
	// Reference: src/components/StripepaymentOptions.vue:1117
	// Reference: src/components/TestimonialOptions.vue:586
	// Reference: src/components/WCAddToCartOptions.vue:696
	__( 'Size', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1075
	// Reference: src/components/ButtonOptions.vue:1214
	// Reference: src/components/EDDAddToCartOptions.vue:794
	// Reference: src/components/EDDBuyNowButtonOptions.vue:823
	// Reference: src/components/StripepaymentOptions.vue:1118
	// Reference: src/components/WCAddToCartOptions.vue:697
	__( 'Vertical Padding', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1076
	// Reference: src/components/ButtonOptions.vue:1215
	// Reference: src/components/EDDAddToCartOptions.vue:795
	// Reference: src/components/EDDBuyNowButtonOptions.vue:824
	// Reference: src/components/StripepaymentOptions.vue:1119
	// Reference: src/components/WCAddToCartOptions.vue:698
	__( 'Horizontal Padding', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1077
	// Reference: src/components/BorderRadiusControl.vue:128
	// Reference: src/components/BorderSectionControl.vue:81
	// Reference: src/components/ButtonOptions.vue:1216
	// Reference: src/components/CountdownOptions.vue:878
	// Reference: src/components/EDDAddToCartOptions.vue:796
	// Reference: src/components/EDDBuyNowButtonOptions.vue:825
	// Reference: src/components/EDDCartOptions.vue:386
	// Reference: src/components/EDDCheckoutOptions.vue:656
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:663
	// Reference: src/components/EDDDownloadsGridOptions.vue:1013
	// Reference: src/components/ImageOptions.vue:729
	// Reference: src/components/OptinFormOptions.vue:872
	// Reference: src/components/PostfeaturedimageOptions.vue:663
	// Reference: src/components/PostsOptions.vue:2347
	// Reference: src/components/PricingTableOptions.vue:1298
	// Reference: src/components/ProductDataTabsOptions.vue:332
	// Reference: src/components/ProductFeaturedImageOptions.vue:663
	// Reference: src/components/ProductGalleryImagesOptions.vue:204
	// Reference: src/components/ProductRelatedOptions.vue:608
	// Reference: src/components/ProgressBarOptions.vue:329
	// Reference: src/components/SectionOptions.vue:386
	// Reference: src/components/SocialProfilesOptions.vue:695
	// Reference: src/components/StripepaymentOptions.vue:1120
	// Reference: src/components/WCAddToCartOptions.vue:699
	// Reference: src/components/WCCartOptions.vue:537
	// Reference: src/components/WCCheckoutOptions.vue:805
	// Reference: src/components/WCCustomProductsGridOptions.vue:1118
	__( 'Border Radius', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1078
	// Reference: src/components/AlertBoxOptions.vue:758
	// Reference: src/components/ButtonOptions.vue:1217
	// Reference: src/components/EDDAddToCartOptions.vue:797
	// Reference: src/components/EDDBuyNowButtonOptions.vue:826
	// Reference: src/components/HeaderOptions.vue:447
	// Reference: src/components/StripepaymentOptions.vue:1121
	// Reference: src/components/WCAddToCartOptions.vue:700
	__( 'Icons', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1079
	// Reference: src/components/AlertBoxOptions.vue:779
	// Reference: src/components/ButtonOptions.vue:1218
	// Reference: src/components/EDDAddToCartOptions.vue:798
	// Reference: src/components/EDDBuyNowButtonOptions.vue:827
	// Reference: src/components/HeaderOptions.vue:464
	// Reference: src/components/OptinFormOptions.vue:879
	// Reference: src/components/StripepaymentOptions.vue:1122
	// Reference: src/components/WCAddToCartOptions.vue:701
	__( 'Before Text Icon', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1080
	// Reference: src/components/AlertBoxOptions.vue:780
	// Reference: src/components/ButtonOptions.vue:1219
	// Reference: src/components/EDDAddToCartOptions.vue:799
	// Reference: src/components/EDDBuyNowButtonOptions.vue:828
	// Reference: src/components/HeaderOptions.vue:465
	// Reference: src/components/OptinFormOptions.vue:880
	// Reference: src/components/StripepaymentOptions.vue:1123
	// Reference: src/components/WCAddToCartOptions.vue:702
	__( 'After Text Icon', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1081
	// Reference: src/components/AlertBoxOptions.vue:806
	// Reference: src/components/BusinessHoursOptions.vue:715
	// Reference: src/components/ButtonOptions.vue:1220
	// Reference: src/components/CountdownOptions.vue:848
	// Reference: src/components/CounterOptions.vue:323
	// Reference: src/components/EDDAddToCartOptions.vue:800
	// Reference: src/components/EDDBuyNowButtonOptions.vue:829
	// Reference: src/components/EDDCartOptions.vue:354
	// Reference: src/components/EDDCheckoutOptions.vue:626
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:641
	// Reference: src/components/ImageOptions.vue:707
	// Reference: src/components/LoginOptions.vue:929
	// Reference: src/components/OptinFormOptions.vue:845
	// Reference: src/components/PostfeaturedimageOptions.vue:641
	// Reference: src/components/PriceListOptions.vue:879
	// Reference: src/components/ProductFeaturedImageOptions.vue:641
	// Reference: src/components/ProgressBarOptions.vue:322
	// Reference: src/components/StripepaymentOptions.vue:1124
	// Reference: src/components/TeamMemberOptions.vue:1023
	// Reference: src/components/WCAddToCartOptions.vue:703
	// Reference: src/components/WCCartOptions.vue:496
	// Reference: src/components/WCCheckoutOptions.vue:764
	__( 'Templates', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1082
	// Reference: src/components/ButtonOptions.vue:1221
	// Reference: src/components/CountdownOptions.vue:859
	// Reference: src/components/OptinFormOptions.vue:857
	// Reference: src/components/StripepaymentOptions.vue:1125
	// Reference: src/components/WCAddToCartOptions.vue:704
	__( 'Tiny', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1084
	// Reference: src/components/ButtonOptions.vue:1223
	// Reference: src/components/EDDAddToCartOptions.vue:803
	// Reference: src/components/EDDBuyNowButtonOptions.vue:832
	// Reference: src/components/StripepaymentOptions.vue:1127
	// Reference: src/components/WCAddToCartOptions.vue:706
	__( 'Pill Button', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1085
	// Reference: src/components/ButtonOptions.vue:1224
	// Reference: src/components/EDDAddToCartOptions.vue:804
	// Reference: src/components/EDDBuyNowButtonOptions.vue:833
	// Reference: src/components/StripepaymentOptions.vue:1128
	// Reference: src/components/WCAddToCartOptions.vue:707
	__( 'Flat Button', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1086
	// Reference: src/components/ButtonOptions.vue:1225
	// Reference: src/components/EDDAddToCartOptions.vue:805
	// Reference: src/components/EDDBuyNowButtonOptions.vue:834
	// Reference: src/components/StripepaymentOptions.vue:1129
	// Reference: src/components/WCAddToCartOptions.vue:708
	__( 'Blue Button', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1087
	// Reference: src/components/ButtonOptions.vue:1226
	// Reference: src/components/EDDAddToCartOptions.vue:806
	// Reference: src/components/EDDBuyNowButtonOptions.vue:835
	// Reference: src/components/StripepaymentOptions.vue:1130
	// Reference: src/components/WCAddToCartOptions.vue:709
	__( 'Light Green Button', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1088
	// Reference: src/components/ButtonOptions.vue:1227
	// Reference: src/components/EDDAddToCartOptions.vue:807
	// Reference: src/components/EDDBuyNowButtonOptions.vue:836
	// Reference: src/components/StripepaymentOptions.vue:1131
	// Reference: src/components/WCAddToCartOptions.vue:710
	__( 'Green Button', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1089
	// Reference: src/components/ButtonOptions.vue:1228
	// Reference: src/components/EDDAddToCartOptions.vue:808
	// Reference: src/components/EDDBuyNowButtonOptions.vue:837
	// Reference: src/components/StripepaymentOptions.vue:1132
	// Reference: src/components/WCAddToCartOptions.vue:711
	__( 'Orange Button', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1090
	// Reference: src/components/ButtonOptions.vue:1229
	// Reference: src/components/EDDAddToCartOptions.vue:809
	// Reference: src/components/EDDBuyNowButtonOptions.vue:838
	// Reference: src/components/StripepaymentOptions.vue:1133
	// Reference: src/components/WCAddToCartOptions.vue:712
	__( 'Red Button', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1091
	// Reference: src/components/ButtonOptions.vue:1230
	// Reference: src/components/EDDAddToCartOptions.vue:810
	// Reference: src/components/EDDBuyNowButtonOptions.vue:839
	// Reference: src/components/StripepaymentOptions.vue:1134
	// Reference: src/components/WCAddToCartOptions.vue:713
	__( 'Yellow Button', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1092
	// Reference: src/components/ButtonOptions.vue:1231
	// Reference: src/components/EDDAddToCartOptions.vue:811
	// Reference: src/components/EDDBuyNowButtonOptions.vue:840
	// Reference: src/components/StripepaymentOptions.vue:1135
	// Reference: src/components/WCAddToCartOptions.vue:714
	__( 'White Button', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1093
	// Reference: src/components/ButtonOptions.vue:1232
	// Reference: src/components/EDDAddToCartOptions.vue:812
	// Reference: src/components/EDDBuyNowButtonOptions.vue:841
	// Reference: src/components/StripepaymentOptions.vue:1136
	// Reference: src/components/WCAddToCartOptions.vue:715
	__( 'Grey Button', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1094
	// Reference: src/components/ButtonOptions.vue:1233
	// Reference: src/components/EDDAddToCartOptions.vue:813
	// Reference: src/components/EDDBuyNowButtonOptions.vue:842
	// Reference: src/components/StripepaymentOptions.vue:1137
	// Reference: src/components/WCAddToCartOptions.vue:716
	__( 'Black Button', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1095
	// Reference: src/components/ButtonOptions.vue:1234
	// Reference: src/components/EDDAddToCartOptions.vue:814
	// Reference: src/components/EDDBuyNowButtonOptions.vue:843
	// Reference: src/components/EDDCartOptions.vue:376
	// Reference: src/components/EDDCheckoutOptions.vue:654
	// Reference: src/components/EDDDownloadsGridOptions.vue:1056
	// Reference: src/components/OptinFormOptions.vue:874
	// Reference: src/components/ProductRelatedOptions.vue:623
	// Reference: src/components/StripepaymentOptions.vue:1138
	// Reference: src/components/WCAddToCartOptions.vue:717
	// Reference: src/components/WCCartOptions.vue:524
	// Reference: src/components/WCCheckoutOptions.vue:792
	// Reference: src/components/WCCustomProductsGridOptions.vue:1161
	__( 'Button Style', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1096
	// Reference: src/components/ButtonOptions.vue:1235
	// Reference: src/components/EDDAddToCartOptions.vue:815
	// Reference: src/components/EDDBuyNowButtonOptions.vue:844
	// Reference: src/components/EDDCartOptions.vue:379
	// Reference: src/components/EDDCheckoutOptions.vue:657
	// Reference: src/components/EDDDownloadsGridOptions.vue:1003
	// Reference: src/components/OptinFormOptions.vue:875
	// Reference: src/components/ProductRelatedOptions.vue:609
	// Reference: src/components/StripepaymentOptions.vue:1139
	// Reference: src/components/WCAddToCartOptions.vue:718
	// Reference: src/components/WCCartOptions.vue:527
	// Reference: src/components/WCCheckoutOptions.vue:795
	// Reference: src/components/WCCustomProductsGridOptions.vue:1108
	__( 'Flat', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1097
	// Reference: src/components/ButtonOptions.vue:1236
	// Reference: src/components/EDDAddToCartOptions.vue:816
	// Reference: src/components/EDDBuyNowButtonOptions.vue:845
	// Reference: src/components/EDDCartOptions.vue:380
	// Reference: src/components/EDDCheckoutOptions.vue:658
	// Reference: src/components/EDDDownloadsGridOptions.vue:1004
	// Reference: src/components/OptinFormOptions.vue:877
	// Reference: src/components/ProductRelatedOptions.vue:610
	// Reference: src/components/StripepaymentOptions.vue:1140
	// Reference: src/components/WCAddToCartOptions.vue:719
	// Reference: src/components/WCCartOptions.vue:528
	// Reference: src/components/WCCheckoutOptions.vue:796
	// Reference: src/components/WCCustomProductsGridOptions.vue:1109
	__( '2D', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1098
	// Reference: src/components/ButtonOptions.vue:1237
	// Reference: src/components/EDDAddToCartOptions.vue:817
	// Reference: src/components/EDDBuyNowButtonOptions.vue:846
	// Reference: src/components/EDDCartOptions.vue:381
	// Reference: src/components/EDDCheckoutOptions.vue:659
	// Reference: src/components/EDDDownloadsGridOptions.vue:1005
	// Reference: src/components/OptinFormOptions.vue:878
	// Reference: src/components/ProductRelatedOptions.vue:611
	// Reference: src/components/StripepaymentOptions.vue:1141
	// Reference: src/components/WCAddToCartOptions.vue:720
	// Reference: src/components/WCCartOptions.vue:529
	// Reference: src/components/WCCheckoutOptions.vue:797
	// Reference: src/components/WCCustomProductsGridOptions.vue:1110
	__( 'Vintage', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1099
	// Reference: src/components/ButtonOptions.vue:1238
	// Reference: src/components/EDDAddToCartOptions.vue:818
	// Reference: src/components/EDDBuyNowButtonOptions.vue:847
	// Reference: src/components/EDDCartOptions.vue:382
	// Reference: src/components/EDDCheckoutOptions.vue:660
	// Reference: src/components/EDDDownloadsGridOptions.vue:1006
	// Reference: src/components/OptinFormOptions.vue:876
	// Reference: src/components/ProductRelatedOptions.vue:612
	// Reference: src/components/StripepaymentOptions.vue:1142
	// Reference: src/components/WCAddToCartOptions.vue:721
	// Reference: src/components/WCCartOptions.vue:530
	// Reference: src/components/WCCheckoutOptions.vue:798
	// Reference: src/components/WCCustomProductsGridOptions.vue:1111
	__( 'Ghost', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1103
	// Reference: src/components/ButtonOptions.vue:1242
	// Reference: src/components/LoginOptions.vue:895
	// Reference: src/components/StripepaymentOptions.vue:1146
	// Reference: src/views/GlobalCSS.vue:1985
	__( 'Button Text Color', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1104
	// Reference: src/components/ButtonOptions.vue:1243
	// Reference: src/components/StripepaymentOptions.vue:1147
	// Reference: src/views/GlobalCSS.vue:1990
	__( 'Button Background Style', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1105
	// Reference: src/components/BackgroundControl.vue:435
	// Reference: src/components/BorderSectionControl.vue:83
	// Reference: src/components/BusinessHoursOptions.vue:748
	// Reference: src/components/ButtonOptions.vue:1244
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:665
	// Reference: src/components/EDDDownloadsGridOptions.vue:1067
	// Reference: src/components/ImageOptions.vue:731
	// Reference: src/components/PostfeaturedimageOptions.vue:665
	// Reference: src/components/PostsOptions.vue:2303
	// Reference: src/components/PriceListOptions.vue:918
	// Reference: src/components/PricingTableOptions.vue:1354
	// Reference: src/components/ProductFeaturedImageOptions.vue:665
	// Reference: src/components/ProductRelatedOptions.vue:634
	// Reference: src/components/SectionOptions.vue:388
	// Reference: src/components/StripepaymentOptions.vue:1148
	// Reference: src/components/TeamMemberOptions.vue:1087
	// Reference: src/components/WCCustomProductsGridOptions.vue:1172
	// Reference: src/views/GlobalCSS.vue:1988
	__( 'Solid', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1106
	// Reference: src/components/BackgroundControl.vue:436
	// Reference: src/components/ButtonOptions.vue:1245
	// Reference: src/components/StripepaymentOptions.vue:1149
	// Reference: src/views/GlobalCSS.vue:1991
	__( 'Gradient', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1107
	// Reference: src/components/ButtonOptions.vue:1248
	// Reference: src/components/ProductDataTabsOptions.vue:326
	// Reference: src/components/ProductGalleryImagesOptions.vue:198
	// Reference: src/components/StripepaymentOptions.vue:1152
	// Reference: src/components/TypographyControl.vue:284
	// Reference: src/views/GlobalCSS.vue:1956
	__( 'Normal', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1108
	// Reference: src/components/ButtonOptions.vue:1249
	// Reference: src/components/StripepaymentOptions.vue:1153
	// Reference: src/views/GlobalCSS.vue:1957
	__( 'Hover', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1116
	// Reference: src/components/ButtonOptions.vue:1257
	// Reference: src/components/EDDAddToCartOptions.vue:835
	// Reference: src/components/EDDBuyNowButtonOptions.vue:864
	// Reference: src/components/EDDCartOptions.vue:383
	// Reference: src/components/EDDCheckoutOptions.vue:661
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:671
	// Reference: src/components/EDDDownloadsGridOptions.vue:1007
	// Reference: src/components/IconOptions.vue:287
	// Reference: src/components/ImageOptions.vue:737
	// Reference: src/components/PostauthorboxOptions.vue:352
	// Reference: src/components/PostfeaturedimageOptions.vue:671
	// Reference: src/components/PostinfoOptions.vue:590
	// Reference: src/components/PriceListOptions.vue:905
	// Reference: src/components/ProductFeaturedImageOptions.vue:671
	// Reference: src/components/ProductRelatedOptions.vue:613
	// Reference: src/components/StripepaymentOptions.vue:1161
	// Reference: src/components/TeamMemberOptions.vue:1071
	// Reference: src/components/WCAddToCartOptions.vue:732
	// Reference: src/components/WCCartOptions.vue:531
	// Reference: src/components/WCCheckoutOptions.vue:799
	// Reference: src/components/WCCustomProductsGridOptions.vue:1112
	// Reference: src/views/GlobalCSS.vue:1955
	// Reference: src/views/SettingsGeneral.vue:224
	__( 'Link', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1117
	// Reference: src/components/BackgroundControl.vue:437
	// Reference: src/components/ButtonOptions.vue:1258
	// Reference: src/components/StripepaymentOptions.vue:1162
	// Reference: src/views/GlobalCSS.vue:1992
	__( 'Gradient Type', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1118
	// Reference: src/components/BackgroundControl.vue:438
	// Reference: src/components/ButtonOptions.vue:1259
	// Reference: src/components/StripepaymentOptions.vue:1163
	// Reference: src/views/GlobalCSS.vue:1993
	__( 'Radial', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1119
	// Reference: src/components/BackgroundControl.vue:439
	// Reference: src/components/ButtonOptions.vue:1260
	// Reference: src/components/StripepaymentOptions.vue:1164
	// Reference: src/views/GlobalCSS.vue:1994
	__( 'Linear', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1120
	// Reference: src/components/BackgroundControl.vue:440
	// Reference: src/components/ButtonOptions.vue:1261
	// Reference: src/components/StripepaymentOptions.vue:1165
	// Reference: src/views/GlobalCSS.vue:1995
	__( 'Angle', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1121
	// Reference: src/components/BackgroundControl.vue:470
	// Reference: src/components/ButtonOptions.vue:1262
	// Reference: src/components/DisplaySectionControl.vue:188
	// Reference: src/components/ShadowControl.vue:143
	// Reference: src/components/StripepaymentOptions.vue:1166
	// Reference: src/components/TeamMemberOptions.vue:1041
	// Reference: src/views/GlobalCSS.vue:1996
	__( 'Position', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1122
	// Reference: src/components/BackgroundControl.vue:442
	// Reference: src/components/ButtonOptions.vue:1263
	// Reference: src/components/StripepaymentOptions.vue:1167
	// Reference: src/views/GlobalCSS.vue:1997
	__( 'Top Center', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1123
	// Reference: src/components/BackgroundControl.vue:443
	// Reference: src/components/ButtonOptions.vue:1264
	// Reference: src/components/ParticlesBackgroundControl.vue:315
	// Reference: src/components/PostsOptions.vue:2322
	// Reference: src/components/StripepaymentOptions.vue:1168
	// Reference: src/views/GlobalCSS.vue:1998
	__( 'Top Left', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1124
	// Reference: src/components/BackgroundControl.vue:444
	// Reference: src/components/ButtonOptions.vue:1265
	// Reference: src/components/ParticlesBackgroundControl.vue:316
	// Reference: src/components/PostsOptions.vue:2321
	// Reference: src/components/StripepaymentOptions.vue:1169
	// Reference: src/views/GlobalCSS.vue:1999
	__( 'Top Right', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1125
	// Reference: src/components/BackgroundControl.vue:445
	// Reference: src/components/ButtonOptions.vue:1266
	// Reference: src/components/StripepaymentOptions.vue:1170
	// Reference: src/views/GlobalCSS.vue:2000
	__( 'Center Center', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1126
	// Reference: src/components/BackgroundControl.vue:446
	// Reference: src/components/ButtonOptions.vue:1267
	// Reference: src/components/StripepaymentOptions.vue:1171
	// Reference: src/views/GlobalCSS.vue:2001
	__( 'Center Left', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1127
	// Reference: src/components/BackgroundControl.vue:447
	// Reference: src/components/ButtonOptions.vue:1268
	// Reference: src/components/StripepaymentOptions.vue:1172
	// Reference: src/views/GlobalCSS.vue:2002
	__( 'Center Right', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1128
	// Reference: src/components/BackgroundControl.vue:448
	// Reference: src/components/ButtonOptions.vue:1269
	// Reference: src/components/StripepaymentOptions.vue:1173
	// Reference: src/views/GlobalCSS.vue:2003
	__( 'Bottom Center', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1129
	// Reference: src/components/BackgroundControl.vue:449
	// Reference: src/components/ButtonOptions.vue:1270
	// Reference: src/components/ParticlesBackgroundControl.vue:317
	// Reference: src/components/PostsOptions.vue:2324
	// Reference: src/components/StripepaymentOptions.vue:1174
	// Reference: src/views/GlobalCSS.vue:2004
	__( 'Bottom Left', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1130
	// Reference: src/components/BackgroundControl.vue:450
	// Reference: src/components/ButtonOptions.vue:1271
	// Reference: src/components/ParticlesBackgroundControl.vue:318
	// Reference: src/components/PostsOptions.vue:2323
	// Reference: src/components/StripepaymentOptions.vue:1175
	// Reference: src/views/GlobalCSS.vue:2005
	__( 'Bottom Right', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1131
	// Reference: src/components/BackgroundControl.vue:451
	// Reference: src/components/ButtonOptions.vue:1272
	// Reference: src/components/StripepaymentOptions.vue:1176
	// Reference: src/views/GlobalCSS.vue:2006
	__( 'First Color Location', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1132
	// Reference: src/components/BackgroundControl.vue:452
	// Reference: src/components/ButtonOptions.vue:1273
	// Reference: src/components/StripepaymentOptions.vue:1177
	// Reference: src/views/GlobalCSS.vue:2007
	__( 'Second Color Location', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1133
	// Reference: src/components/BackgroundControl.vue:460
	// Reference: src/components/ButtonOptions.vue:1274
	// Reference: src/components/StripepaymentOptions.vue:1178
	// Reference: src/views/GlobalCSS.vue:2008
	__( 'First Color', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1134
	// Reference: src/components/BackgroundControl.vue:461
	// Reference: src/components/ButtonOptions.vue:1275
	// Reference: src/components/StripepaymentOptions.vue:1179
	// Reference: src/views/GlobalCSS.vue:2009
	__( 'Second Color', 'coming-soon' ),

	// Reference: src/components/AddToCartOptions.vue:1135
	// Reference: src/components/BackgroundControl.vue:485
	// Reference: src/components/ButtonOptions.vue:1276
	// Reference: src/components/ParticlesBackgroundControl.vue:307
	// Reference: src/components/PostinfoOptions.vue:605
	// Reference: src/components/PostsOptions.vue:2213
	// Reference: src/components/PriceListOptions.vue:945
	// Reference: src/components/PricingTableOptions.vue:1318
	// Reference: src/components/ProductMetaOptions.vue:337
	// Reference: src/components/ShadowControl.vue:137
	// Reference: src/components/SocialProfilesOptions.vue:715
	// Reference: src/components/StripepaymentOptions.vue:1180
	// Reference: src/components/TeamMemberOptions.vue:1112
	// Reference: src/components/VideoOptions.vue:237
	__( 'Custom', 'coming-soon' ),

	// Reference: src/components/AdditionalInformationOptions.vue:126
	// Reference: src/components/PricingTableOptions.vue:1281
	__( 'Header', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:756
	__( 'Alert', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:759
	// Reference: src/components/CounterOptions.vue:333
	// Reference: src/components/EDDDownloadsGridOptions.vue:1093
	// Reference: src/components/PostsOptions.vue:2231
	// Reference: src/components/PriceListOptions.vue:910
	// Reference: src/components/ProductRelatedOptions.vue:660
	// Reference: src/components/TeamMemberOptions.vue:1070
	// Reference: src/components/TestimonialOptions.vue:596
	// Reference: src/components/WCCustomProductsGridOptions.vue:1198
	__( 'Title', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:760
	// Reference: src/components/EDDDownloadsGridOptions.vue:1052
	// Reference: src/components/PriceListOptions.vue:909
	// Reference: src/components/PricingTableOptions.vue:1324
	// Reference: src/components/TeamMemberOptions.vue:1114
	// Reference: src/components/WCCustomProductsGridOptions.vue:1157
	__( 'Description', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:761
	__( 'Title Font Size', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:762
	// Reference: src/components/CounterOptions.vue:340
	__( 'Title Align', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:763
	// Reference: src/components/TeamMemberOptions.vue:1105
	__( 'Description Align', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:764
	// Reference: src/components/PostsOptions.vue:2261
	// Reference: src/components/TeamMemberOptions.vue:1115
	__( 'Title Tag', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:765
	__( 'Description Font Size', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:766
	// Reference: src/components/HeaderOptions.vue:451
	__( 'h1', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:767
	// Reference: src/components/HeaderOptions.vue:452
	__( 'h2', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:768
	// Reference: src/components/HeaderOptions.vue:453
	__( 'h3', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:769
	// Reference: src/components/HeaderOptions.vue:454
	__( 'h4', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:781
	// Reference: src/components/BeforeAfterToggleOptions.vue:506
	// Reference: src/components/ContentToggleOptions.vue:593
	// Reference: src/components/DividerOptions.vue:378
	// Reference: src/components/EDDDownloadPriceOptions.vue:105
	// Reference: src/components/FeatureOptions.vue:458
	// Reference: src/components/HeaderOptions.vue:466
	// Reference: src/components/IconFeatureOptions.vue:448
	// Reference: src/components/IconOptions.vue:284
	// Reference: src/components/MenuCartOptions.vue:189
	// Reference: src/components/ParticlesBackgroundControl.vue:325
	// Reference: src/components/PostnavigationOptions.vue:97
	// Reference: src/components/PostsOptions.vue:2348
	// Reference: src/components/PriceListOptions.vue:912
	// Reference: src/components/ProductPriceOptions.vue:184
	// Reference: src/components/ProgressBarOptions.vue:339
	// Reference: src/components/ShadowControl.vue:138
	// Reference: src/components/ShapeDividerControl.vue:369
	// Reference: src/components/SocialProfilesOptions.vue:716
	// Reference: src/components/TeamMemberOptions.vue:1047
	// Reference: src/components/TestimonialOptions.vue:588
	// Reference: src/components/TextOptions.vue:394
	__( 'Color', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:783
	// Reference: src/components/EDDCheckoutOptions.vue:644
	// Reference: src/components/EDDDownloadsGridOptions.vue:1126
	// Reference: src/components/PriceListOptions.vue:908
	// Reference: src/components/PricingTableOptions.vue:1333
	// Reference: src/components/TeamMemberOptions.vue:1076
	__( 'Description Color', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:784
	__( 'Title Background', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:785
	__( 'Dismiss Color', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:786
	// Reference: src/components/DividerOptions.vue:389
	// Reference: src/components/HeaderOptions.vue:467
	// Reference: src/components/PostauthorboxOptions.vue:347
	// Reference: src/components/PostsOptions.vue:2266
	// Reference: src/components/TeamMemberOptions.vue:1120
	__( 'H5', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:787
	// Reference: src/components/DividerOptions.vue:390
	// Reference: src/components/HeaderOptions.vue:468
	// Reference: src/components/PostauthorboxOptions.vue:348
	// Reference: src/components/PostsOptions.vue:2267
	// Reference: src/components/TeamMemberOptions.vue:1121
	__( 'H6', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:789
	__( 'Show Icon', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:790
	// Reference: src/components/BeforeAfterToggleOptions.vue:492
	// Reference: src/components/ContentToggleOptions.vue:568
	// Reference: src/components/EDDDownloadsGridOptions.vue:1028
	// Reference: src/components/FeatureOptions.vue:449
	// Reference: src/components/IconFeatureOptions.vue:439
	// Reference: src/components/PostinfoOptions.vue:595
	// Reference: src/components/ProductMetaOptions.vue:332
	// Reference: src/components/ShapeDividerControl.vue:349
	// Reference: src/components/TestimonialOptions.vue:582
	// Reference: src/components/VideoOptions.vue:235
	// Reference: src/components/WCCustomProductsGridOptions.vue:1133
	__( 'Type', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:791
	__( 'Info', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:792
	__( 'Success', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:793
	__( 'Warning', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:794
	__( 'Danger', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:795
	__( 'Dismiss Button', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:796
	// Reference: src/components/ContactFormOptions.vue:301
	// Reference: src/components/GiveawayOptions.vue:173
	// Reference: src/views/SettingsGeneral.vue:225
	__( 'Show', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:797
	// Reference: src/components/ContactFormOptions.vue:302
	// Reference: src/components/GiveawayOptions.vue:174
	__( 'Hide', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:800
	// Reference: src/components/BusinessHoursOptions.vue:747
	// Reference: src/components/DividerOptions.vue:364
	// Reference: src/components/ParticlesBackgroundControl.vue:300
	// Reference: src/components/PriceListOptions.vue:917
	// Reference: src/components/SocialProfilesOptions.vue:687
	// Reference: src/components/TeamMemberOptions.vue:1086
	// Reference: src/components/TypographyControl.vue:281
	__( 'Style', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:801
	__( 'Style 1', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:802
	__( 'Style 2', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:803
	__( 'Style 3', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:804
	__( 'Style 4', 'coming-soon' ),

	// Reference: src/components/AlertBoxOptions.vue:808
	// Reference: src/components/DynamicTextControl.vue:132
	// Reference: src/components/HeaderOptions.vue:469
	// Reference: src/components/PostcommentsOptions.vue:205
	// Reference: src/components/TextOptions.vue:395
	__( 'Insert Dynamic Text', 'coming-soon' ),

	// Reference: src/components/AlignControl.vue:344
	// Reference: src/components/BeforeAfterToggleOptions.vue:501
	// Reference: src/components/ContentToggleOptions.vue:585
	__( 'Align', 'coming-soon' ),

	// Reference: src/components/AnchorOptions.vue:76
	__( 'Anchor', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:260
	__( 'Animation Effects', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:261
	__( 'Scrolling Effect', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:262
	__( 'Mouse Effect', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:263
	__( 'Vertical Scroll', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:265
	__( 'Speed', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:266
	__( 'Viewport', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:267
	__( 'Viewport Top %', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:270
	__( 'Up', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:271
	__( 'Down', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:272
	__( 'Horizontal Scroll', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:273
	__( 'Direction', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:274
	__( 'To Left', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:275
	__( 'To Right', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:276
	__( 'Transparency', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:278
	__( 'Fade Out', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:279
	// Reference: src/components/BeforeAfterToggleOptions.vue:503
	// Reference: src/components/ContentToggleOptions.vue:587
	// Reference: src/components/FeatureOptions.vue:455
	// Reference: src/components/HeaderOptions.vue:450
	// Reference: src/components/IconFeatureOptions.vue:445
	__( 'Level', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:280
	// Reference: src/components/ShadowControl.vue:141
	__( 'Blur', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:281
	__( 'Rotate', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:282
	// Reference: src/components/StarRatingOptions.vue:301
	__( 'Scale', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:283
	__( 'Scale Up', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:284
	__( 'Scale Down', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:285
	__( 'Mouse Track', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:286
	__( 'Opposite', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:287
	__( 'Direct', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:288
	__( '3D Tilt', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:289
	__( 'Entrance Animation', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:290
	__( 'Select Animation', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:291
	__( 'Fading', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:292
	__( 'Fade In', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:293
	__( 'Fade In Down', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:294
	__( 'Fade In Left', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:295
	__( 'Fade In Right', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:296
	__( 'Fade In Up', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:297
	__( 'Zooming', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:298
	__( 'Zoom In', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:299
	__( 'Zoom In Down', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:300
	__( 'Zoom In Left', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:301
	__( 'Zoom In Right', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:302
	__( 'Zoom In Up', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:303
	__( 'Rotating', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:304
	__( 'Rotate In', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:305
	__( 'Rotate In Down Left', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:306
	__( 'Rotate In Down Right', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:307
	__( 'Rotate In Up Left', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:308
	__( 'Rotate In Up Right', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:310
	__( 'Attention Seekers', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:311
	__( 'Bounce', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:312
	__( 'Flash', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:313
	__( 'Pulse', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:314
	__( 'Rubber Band', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:315
	__( 'Shake X', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:316
	__( 'Shake Y', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:317
	__( 'Head Shake', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:318
	__( 'Swing', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:319
	__( 'Tada', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:320
	__( 'Wobble', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:321
	__( 'Jello', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:322
	__( 'Heart Beat', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:324
	__( 'Back In Down', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:325
	__( 'Back In Left', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:326
	__( 'Back In Right', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:327
	__( 'Back In Up', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:330
	__( 'Bounce In Down', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:331
	__( 'Bounce In Left', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:332
	__( 'Bounce In Right', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:333
	__( 'Bounce In Up', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:335
	__( 'Fade In Down Big', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:336
	__( 'Fade In Left Big', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:337
	__( 'Fade In Right Big', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:338
	__( 'Fade In Up Big', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:339
	__( 'Fade In Top Left', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:340
	__( 'Fade In Top Right', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:341
	__( 'Fade In Bottom Left', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:342
	__( 'Fade In Bootom Right', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:345
	// Reference: src/components/ShapeDividerControl.vue:372
	__( 'Flip', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:346
	__( 'Flip In X', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:347
	__( 'Flip In Y', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:348
	__( 'Light Speed In Left', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:349
	__( 'Light Speed In Right', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:351
	__( 'Roll In', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:354
	__( 'Back In', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:355
	__( 'Bounce In', 'coming-soon' ),

	// Reference: src/components/AnimationEffectControl.vue:356
	__( 'Note: In the preview the animation is applied when you select it. On the live page the animation will be applied when the element is scrolled into view.', 'coming-soon' ),

	// Reference: src/components/AttributeSectionControl.vue:81
	__( 'Attributes', 'coming-soon' ),

	// Reference: src/components/AttributeSectionControl.vue:82
	__( 'Custom Class', 'coming-soon' ),

	// Reference: src/components/AttributeSectionControl.vue:83
	__( 'Css ID', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:434
	__( 'Background Style', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:453
	__( 'Background Position', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:454
	__( 'Full Screen Cover - Fixed', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:455
	__( '100% Width Top', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:457
	__( 'Repeat Horizontal Top', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:458
	__( 'Repeat Horizontal Bottom', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:459
	__( 'Repeat Vertical Center', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:463
	__( '100% Width Bottom', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:465
	__( 'Custom Position', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:466
	__( 'Background Image', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:467
	__( 'Full Screen Contain - Fixed', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:468
	__( 'Full Screen Cover', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:469
	__( 'Full Screen Contain', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:471
	__( 'X Position', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:472
	__( 'Y Position', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:473
	__( 'Attachment', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:474
	// Reference: src/components/ColOptions.vue:698
	// Reference: src/components/CounterOptions.vue:334
	// Reference: src/components/EDDCartOptions.vue:394
	// Reference: src/components/EDDCheckoutOptions.vue:673
	// Reference: src/components/FontControl.vue:25
	// Reference: src/components/ImageOptions.vue:745
	// Reference: src/components/PostinfoOptions.vue:604
	// Reference: src/components/PostsOptions.vue:2212
	// Reference: src/components/PriceListOptions.vue:942
	// Reference: src/components/ProductMetaOptions.vue:336
	// Reference: src/components/RowOptions.vue:697
	// Reference: src/components/SocialProfilesOptions.vue:688
	// Reference: src/components/TeamMemberOptions.vue:1109
	// Reference: src/components/WCCartOptions.vue:544
	// Reference: src/components/WCCheckoutOptions.vue:813
	__( 'Default', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:475
	// Reference: src/components/DisplaySectionControl.vue:202
	__( 'Scroll', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:476
	// Reference: src/components/DisplaySectionControl.vue:191
	__( 'Fixed', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:477
	__( 'Repeat', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:478
	__( 'No-repeat', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:479
	__( 'Repeat-x', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:480
	__( 'Repeat-y', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:482
	// Reference: src/components/DisplaySectionControl.vue:203
	__( 'Auto', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:483
	// Reference: src/components/ImageOptions.vue:747
	__( 'Cover', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:484
	// Reference: src/components/ImageOptions.vue:748
	__( 'Contain', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:486
	// Reference: src/components/DividerOptions.vue:369
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:644
	// Reference: src/components/ImageOptions.vue:710
	// Reference: src/components/OptinFormOptions.vue:854
	// Reference: src/components/PostfeaturedimageOptions.vue:644
	// Reference: src/components/PriceListOptions.vue:946
	// Reference: src/components/ProductFeaturedImageOptions.vue:644
	// Reference: src/components/RowOptions.vue:667
	// Reference: src/components/ShapeDividerControl.vue:370
	// Reference: src/components/TeamMemberOptions.vue:1055
	// Reference: src/components/VideoOptions.vue:240
	__( 'Width', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:487
	// Reference: src/components/ColOptions.vue:700
	// Reference: src/components/RowOptions.vue:703
	// Reference: src/components/SectionOptions.vue:399
	// Reference: src/views/GlobalCSS.vue:1897
	// Reference: src/views/SetupDesign-Lite.vue:734
	__( 'Dim Background', 'coming-soon' ),

	// Reference: src/components/BackgroundControl.vue:488
	// Reference: src/components/BeforeAfterToggleOptions.vue:515
	// Reference: src/components/ColOptions.vue:701
	// Reference: src/components/ContentToggleOptions.vue:605
	// Reference: src/components/RowOptions.vue:704
	// Reference: src/components/SectionOptions.vue:400
	__( 'Overlay Color', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:493
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:643
	// Reference: src/components/EDDDownloadsGridOptions.vue:1064
	// Reference: src/components/FeatureOptions.vue:450
	// Reference: src/components/IconFeatureOptions.vue:440
	// Reference: src/components/ImageOptions.vue:709
	// Reference: src/components/PostfeaturedimageOptions.vue:643
	// Reference: src/components/PostinfoOptions.vue:612
	// Reference: src/components/PostsOptions.vue:2300
	// Reference: src/components/PriceListOptions.vue:904
	// Reference: src/components/ProductFeaturedImageOptions.vue:643
	// Reference: src/components/ProductMetaOptions.vue:333
	// Reference: src/components/ProductRelatedOptions.vue:631
	// Reference: src/components/SocialSharingOptions.vue:397
	// Reference: src/components/TeamMemberOptions.vue:1029
	// Reference: src/components/TestimonialOptions.vue:593
	// Reference: src/components/WCCustomProductsGridOptions.vue:1169
	__( 'Image', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:494
	__( 'Before Image', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:495
	__( 'After Image', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:496
	// Reference: src/components/ContentToggleOptions.vue:576
	__( 'Before Label', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:497
	// Reference: src/components/ContentToggleOptions.vue:577
	__( 'After Label', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:499
	// Reference: src/components/ContentToggleOptions.vue:583
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:652
	// Reference: src/components/FeatureOptions.vue:452
	// Reference: src/components/IconFeatureOptions.vue:442
	// Reference: src/components/ImageOptions.vue:718
	// Reference: src/components/PostfeaturedimageOptions.vue:652
	// Reference: src/components/ProductFeaturedImageOptions.vue:652
	// Reference: src/components/TeamMemberOptions.vue:1037
	__( 'Image Size', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:502
	// Reference: src/components/ContentToggleOptions.vue:586
	// Reference: src/components/FeatureOptions.vue:454
	// Reference: src/components/IconFeatureOptions.vue:444
	__( 'Header Text', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:507
	// Reference: src/components/CountdownOptions.vue:889
	// Reference: src/components/EDDCartOptions.vue:373
	// Reference: src/components/EDDCheckoutOptions.vue:651
	// Reference: src/components/EDDDownloadsGridOptions.vue:997
	// Reference: src/components/WCCartOptions.vue:521
	// Reference: src/components/WCCheckoutOptions.vue:789
	// Reference: src/components/WCCustomProductsGridOptions.vue:1102
	// Reference: src/views/GlobalCSS.vue:1963
	__( 'Label Color', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:510
	// Reference: src/components/ContentToggleOptions.vue:600
	__( 'Orientation', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:511
	// Reference: src/components/ContentToggleOptions.vue:601
	__( 'Slider Orientation', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:514
	// Reference: src/components/ContentToggleOptions.vue:604
	__( 'Move on Hover', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:516
	// Reference: src/components/ContentToggleOptions.vue:606
	__( 'Comparison Handle', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:517
	// Reference: src/components/ContentToggleOptions.vue:607
	__( 'Handle Initial Offset', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:518
	// Reference: src/components/ContentToggleOptions.vue:608
	__( 'Handle Color', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:521
	// Reference: src/components/ContentToggleOptions.vue:611
	__( 'Handle Thickness', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:522
	// Reference: src/components/ContentToggleOptions.vue:612
	__( 'Circle Width', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:523
	// Reference: src/components/ContentToggleOptions.vue:613
	__( 'Circle Radius', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:524
	// Reference: src/components/ContentToggleOptions.vue:614
	__( 'Triangle Size', 'coming-soon' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue:525
	__( 'Before /After Label Styles', 'coming-soon' ),

	// Reference: src/components/BorderSectionControl.vue:80
	// Reference: src/components/PostsOptions.vue:2282
	// Reference: src/components/SectionOptions.vue:397
	__( 'Border', 'coming-soon' ),

	// Reference: src/components/BorderSectionControl.vue:82
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:664
	// Reference: src/components/EDDDownloadsGridOptions.vue:1066
	// Reference: src/components/ImageOptions.vue:730
	// Reference: src/components/PostfeaturedimageOptions.vue:664
	// Reference: src/components/PostsOptions.vue:2302
	// Reference: src/components/PricingTableOptions.vue:1353
	// Reference: src/components/ProductFeaturedImageOptions.vue:664
	// Reference: src/components/ProductRelatedOptions.vue:633
	// Reference: src/components/SectionOptions.vue:387
	// Reference: src/components/WCCustomProductsGridOptions.vue:1171
	__( 'Border Style', 'coming-soon' ),

	// Reference: src/components/BorderSectionControl.vue:84
	// Reference: src/components/BusinessHoursOptions.vue:749
	// Reference: src/components/DividerOptions.vue:366
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:666
	// Reference: src/components/EDDDownloadsGridOptions.vue:1068
	// Reference: src/components/ImageOptions.vue:732
	// Reference: src/components/PostfeaturedimageOptions.vue:666
	// Reference: src/components/PostsOptions.vue:2304
	// Reference: src/components/PriceListOptions.vue:919
	// Reference: src/components/PricingTableOptions.vue:1355
	// Reference: src/components/ProductFeaturedImageOptions.vue:666
	// Reference: src/components/ProductRelatedOptions.vue:635
	// Reference: src/components/SectionOptions.vue:389
	// Reference: src/components/TeamMemberOptions.vue:1088
	// Reference: src/components/WCCustomProductsGridOptions.vue:1173
	// Reference: src/views/GlobalCSS.vue:1970
	__( 'Dotted', 'coming-soon' ),

	// Reference: src/components/BorderSectionControl.vue:85
	// Reference: src/components/BusinessHoursOptions.vue:750
	// Reference: src/components/DividerOptions.vue:367
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:667
	// Reference: src/components/EDDDownloadsGridOptions.vue:1069
	// Reference: src/components/ImageOptions.vue:733
	// Reference: src/components/PostfeaturedimageOptions.vue:667
	// Reference: src/components/PostsOptions.vue:2305
	// Reference: src/components/PriceListOptions.vue:920
	// Reference: src/components/PricingTableOptions.vue:1356
	// Reference: src/components/ProductFeaturedImageOptions.vue:667
	// Reference: src/components/ProductRelatedOptions.vue:636
	// Reference: src/components/SectionOptions.vue:390
	// Reference: src/components/TeamMemberOptions.vue:1089
	// Reference: src/components/WCCustomProductsGridOptions.vue:1174
	// Reference: src/views/GlobalCSS.vue:1971
	__( 'Dashed', 'coming-soon' ),

	// Reference: src/components/BorderSectionControl.vue:86
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:670
	// Reference: src/components/ImageOptions.vue:736
	// Reference: src/components/PostfeaturedimageOptions.vue:670
	// Reference: src/components/PostsOptions.vue:2298
	// Reference: src/components/PricingTableOptions.vue:1357
	// Reference: src/components/ProductDataTabsOptions.vue:330
	// Reference: src/components/ProductFeaturedImageOptions.vue:670
	// Reference: src/components/ProductGalleryImagesOptions.vue:202
	// Reference: src/components/SectionOptions.vue:392
	__( 'Border Color', 'coming-soon' ),

	// Reference: src/components/BorderWidthControl.vue:120
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:668
	// Reference: src/components/ImageOptions.vue:734
	// Reference: src/components/PostfeaturedimageOptions.vue:668
	// Reference: src/components/PostsOptions.vue:2299
	// Reference: src/components/PricingTableOptions.vue:1358
	// Reference: src/components/ProductDataTabsOptions.vue:339
	// Reference: src/components/ProductFeaturedImageOptions.vue:668
	// Reference: src/components/ProductGalleryImagesOptions.vue:211
	__( 'Border Width', 'coming-soon' ),

	// Reference: src/components/BulletListOptions.vue:500
	__( 'List', 'coming-soon' ),

	// Reference: src/components/BulletListOptions.vue:513
	// Reference: src/components/BusinessHoursOptions.vue:738
	// Reference: src/components/DividerOptions.vue:393
	// Reference: src/components/PostinfoOptions.vue:618
	// Reference: src/components/PriceListOptions.vue:907
	// Reference: src/components/PricingTableOptions.vue:1337
	// Reference: src/components/ProductGalleryImagesOptions.vue:218
	// Reference: src/components/SocialProfilesOptions.vue:702
	// Reference: src/components/TeamMemberOptions.vue:1080
	__( 'Icon Color', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:716
	// Reference: src/components/TeamMemberOptions.vue:1024
	__( 'Striped Effect Template', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:717
	// Reference: src/components/TeamMemberOptions.vue:1025
	__( 'Divider Template', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:718
	// Reference: src/components/TeamMemberOptions.vue:1026
	__( 'Background Template', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:720
	__( 'Business Days and Timing', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:722
	// Reference: src/components/PriceListOptions.vue:886
	__( 'Date Font Size', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:723
	// Reference: src/components/PriceListOptions.vue:887
	__( 'Time Font Size', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:725
	// Reference: src/components/TeamMemberOptions.vue:1060
	__( 'Date Align', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:726
	// Reference: src/components/TeamMemberOptions.vue:1061
	__( 'Time Align', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:734
	__( 'Enter Day', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:735
	__( 'Enter Time', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:736
	// Reference: src/components/TeamMemberOptions.vue:1072
	__( 'Style Day/Time', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:740
	// Reference: src/components/PostinfoOptions.vue:583
	__( 'Time', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:742
	// Reference: src/components/TeamMemberOptions.vue:1081
	__( 'Day Color', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:743
	// Reference: src/components/TeamMemberOptions.vue:1082
	__( 'Time Color', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:746
	// Reference: src/components/DividerOptions.vue:362
	// Reference: src/components/NavOptions.vue:589
	// Reference: src/components/PostinfoOptions.vue:616
	// Reference: src/components/PriceListOptions.vue:916
	// Reference: src/components/ProductMetaOptions.vue:342
	// Reference: src/components/TeamMemberOptions.vue:1085
	__( 'Divider', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:752
	// Reference: src/components/PriceListOptions.vue:922
	// Reference: src/components/TeamMemberOptions.vue:1091
	__( 'Weight', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:753
	// Reference: src/components/PriceListOptions.vue:923
	// Reference: src/components/TeamMemberOptions.vue:1092
	__( 'Day and Time', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:754
	// Reference: src/components/PriceListOptions.vue:924
	// Reference: src/components/TeamMemberOptions.vue:1093
	__( 'Striped Effect', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:755
	// Reference: src/components/PriceListOptions.vue:925
	// Reference: src/components/TeamMemberOptions.vue:1094
	__( 'Striped Odd Rows Color', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:756
	// Reference: src/components/PriceListOptions.vue:926
	// Reference: src/components/TeamMemberOptions.vue:1095
	__( 'Striped Even Rows Color', 'coming-soon' ),

	// Reference: src/components/BusinessHoursOptions.vue:757
	// Reference: src/components/ColOptions.vue:676
	// Reference: src/components/PostauthorboxOptions.vue:359
	// Reference: src/components/PostcommentsOptions.vue:204
	// Reference: src/components/PostinfoOptions.vue:619
	// Reference: src/components/PriceListOptions.vue:932
	// Reference: src/components/ProductMetaOptions.vue:345
	// Reference: src/components/RowOptions.vue:665
	// Reference: src/components/SectionOptions.vue:395
	// Reference: src/components/TeamMemberOptions.vue:1096
	// Reference: src/views/GlobalCSS.vue:1922
	// Reference: src/views/SetupDesign-Lite.vue:756
	__( 'Background', 'coming-soon' ),

	// Reference: src/components/ButtonOptions.vue:1208
	// Reference: src/components/EDDAddToCartOptions.vue:789
	// Reference: src/components/EDDBuyNowButtonOptions.vue:818
	// Reference: src/components/NavOptions.vue:584
	// Reference: src/components/PricingTableOptions.vue:1329
	// Reference: src/components/StripepaymentOptions.vue:1112
	// Reference: src/components/WCAddToCartOptions.vue:691
	__( 'Add "No Follow"', 'coming-soon' ),

	// Reference: src/components/ButtonOptions.vue:1210
	// Reference: src/components/OptinFormOptions.vue:863
	// Reference: src/components/StripepaymentOptions.vue:1114
	// Reference: src/components/WCAddToCartOptions.vue:693
	__( 'Button Sub Text', 'coming-soon' ),

	// Reference: src/components/ButtonOptions.vue:1212
	// Reference: src/components/EDDAddToCartOptions.vue:792
	// Reference: src/components/EDDBuyNowButtonOptions.vue:821
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:672
	// Reference: src/components/IconOptions.vue:285
	// Reference: src/components/ImageOptions.vue:738
	// Reference: src/components/NavOptions.vue:583
	// Reference: src/components/PostfeaturedimageOptions.vue:672
	// Reference: src/components/PricingTableOptions.vue:1328
	// Reference: src/components/ProductFeaturedImageOptions.vue:672
	// Reference: src/components/StripepaymentOptions.vue:1116
	// Reference: src/components/WCAddToCartOptions.vue:695
	__( 'Open In New Window', 'coming-soon' ),

	// Reference: src/components/ButtonOptions.vue:1246
	// Reference: src/components/StripepaymentOptions.vue:1150
	__( 'Button Border Width', 'coming-soon' ),

	// Reference: src/components/ButtonOptions.vue:1247
	// Reference: src/components/StripepaymentOptions.vue:1151
	// Reference: src/views/GlobalCSS.vue:1987
	__( 'Button Border Color', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:666
	__( 'Column Width', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:677
	// Reference: src/components/EDDCartOptions.vue:356
	// Reference: src/components/EDDCheckoutOptions.vue:628
	// Reference: src/components/EDDDownloadsGridOptions.vue:974
	// Reference: src/components/PostinfoOptions.vue:611
	// Reference: src/components/PostsOptions.vue:2336
	// Reference: src/components/PriceListOptions.vue:927
	// Reference: src/components/ProductMetaOptions.vue:329
	// Reference: src/components/WCCartOptions.vue:498
	// Reference: src/components/WCCheckoutOptions.vue:766
	// Reference: src/components/WCCustomProductsGridOptions.vue:1079
	// Reference: src/views/GlobalCSS.vue:1958
	__( 'Layout', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:678
	// Reference: src/components/ContactFormOptions.vue:295
	// Reference: src/components/GiveawayOptions.vue:167
	// Reference: src/components/NavOptions.vue:576
	// Reference: src/components/SectionOptions.vue:396
	__( 'Advanced Styles', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:679
	// Reference: src/components/RowOptions.vue:678
	__( 'Content Alignment', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:680
	// Reference: src/components/NavOptions.vue:591
	// Reference: src/components/RowOptions.vue:679
	__( 'Simple', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:684
	// Reference: src/components/RowOptions.vue:683
	__( 'Display', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:685
	// Reference: src/components/RowOptions.vue:684
	__( 'Flex Direction', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:686
	// Reference: src/components/RowOptions.vue:685
	__( 'Justify Content', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:687
	// Reference: src/components/RowOptions.vue:686
	__( 'Align Items', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:688
	// Reference: src/components/RowOptions.vue:687
	// Reference: src/views/Layoutnav.vue:1487
	__( 'Column', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:689
	// Reference: src/components/RowOptions.vue:688
	// Reference: src/views/Layoutnav.vue:1486
	__( 'Row', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:690
	// Reference: src/components/RowOptions.vue:689
	__( 'Flex Start', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:691
	// Reference: src/components/RowOptions.vue:690
	__( 'Center', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:692
	// Reference: src/components/RowOptions.vue:691
	__( 'Flex End', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:694
	// Reference: src/components/RowOptions.vue:693
	__( 'Space Around', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:695
	// Reference: src/components/RowOptions.vue:694
	__( 'Space Evenly', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:696
	// Reference: src/components/RowOptions.vue:695
	__( 'Baseline', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:697
	// Reference: src/components/RowOptions.vue:696
	__( 'Stretch', 'coming-soon' ),

	// Reference: src/components/ColOptions.vue:699
	// Reference: src/components/RowOptions.vue:702
	// Reference: src/components/SectionOptions.vue:398
	// Reference: src/components/ShapeDividerControl.vue:346
	__( 'Shape Divider', 'coming-soon' ),

	// Reference: src/components/ColorPicker.vue:262
	__( 'Global Colors', 'coming-soon' ),

	// Reference: src/components/ColorPicker.vue:263
	__( 'Common Colors', 'coming-soon' ),

	// Reference: src/components/ColorPicker.vue:264
	__( 'Recently Used', 'coming-soon' ),

	// Reference: src/components/ColorPicker.vue:265
	// Reference: src/views/InlineHelpView.vue:266
	__( 'Clear', 'coming-soon' ),

	// Reference: src/components/ColorPicker.vue:267
	__( 'Global Theme Colors', 'coming-soon' ),

	// Reference: src/components/ContactForm.vue:169
	__( 'Install Contact Form plugin:', 'coming-soon' ),

	// Reference: src/components/ContactForm.vue:172
	__( 'Contact Form', 'coming-soon' ),

	// Reference: src/components/ContactForm.vue:173
	// Reference: src/components/Giveaway.vue:174
	__( '(This shortcode will be rendered on the live preview.)', 'coming-soon' ),

	// Reference: src/components/ContactForm.vue:177
	// Reference: src/components/ContactFormOptions.vue:296
	__( 'Select a Form', 'coming-soon' ),

	// Reference: src/components/ContactForm.vue:178
	__( 'You can use WPForms to build contact forms, surveys, payment forms, and more with just a few clicks.', 'coming-soon' ),

	// Reference: src/components/ContactFormOptions.vue:298
	__( 'Select', 'coming-soon' ),

	// Reference: src/components/ContactFormOptions.vue:299
	__( 'Need to make changes? Edit the selected form.', 'coming-soon' ),

	// Reference: src/components/ContactFormOptions.vue:300
	__( '+ New Form', 'coming-soon' ),

	// Reference: src/components/ContactFormOptions.vue:303
	// Reference: src/components/GiveawayOptions.vue:175
	__( 'Form Name', 'coming-soon' ),

	// Reference: src/components/ContactFormOptions.vue:304
	// Reference: src/components/GiveawayOptions.vue:176
	__( 'Form Description', 'coming-soon' ),

	// Reference: src/components/ContactFormOptions.vue:305
	// Reference: src/components/GiveawayOptions.vue:177
	// Reference: src/components/LoginOptions.vue:906
	// Reference: src/components/OptinFormOptions.vue:850
	__( 'Form', 'coming-soon' ),

	// Reference: src/components/ContactFormOptions.vue:306
	// Reference: src/components/GiveawayOptions.vue:178
	__( 'Display Options', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:569
	__( 'Heading 1', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:570
	__( 'Heading 2', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:571
	__( 'Content Area 1', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:572
	__( 'Content Area 2', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:573
	__( 'Toggle', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:574
	__( 'Content 1', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:575
	__( 'Content 2', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:580
	__( 'Templates Parts', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:581
	__( 'Section Content', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:590
	__( 'First Background Color', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:591
	__( 'Second Background Color', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:592
	__( 'Switcher Color', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:594
	__( 'Heading 1 Color', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:595
	__( 'Heading 2 Color', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:596
	__( 'Content 1 Color', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:597
	__( 'Content 2 Color', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:615
	__( 'Heading / Content', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:616
	__( 'Switcher', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:617
	__( 'Switch Style', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:618
	__( 'Round', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:619
	__( 'Square', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:620
	__( 'Label Box', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:621
	__( 'Switch Size', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:625
	__( 'Mini', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:626
	__( 'No template parts available in SeedProd', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:630
	__( 'Select Part', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:631
	__( 'Loading Template Parts...', 'coming-soon' ),

	// Reference: src/components/ContentToggleOptions.vue:632
	__( 'Edit This Template Part', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:851
	__( 'Countdown Type', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:852
	__( 'Visitor Timer (Evergreen)', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:853
	__( 'DateTime Countdown', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:854
	__( 'Set Timer For', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:855
	__( 'End Date', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:856
	__( 'End Time', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:857
	__( 'Timezone', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:863
	__( 'Action To Take On Expires', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:864
	// Reference: src/components/OptinFormOptions.vue:866
	__( 'Show Message', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:865
	// Reference: src/components/OptinFormOptions.vue:867
	__( 'Redirect', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:866
	// Reference: src/components/OptinFormOptions.vue:868
	__( 'Message', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:867
	// Reference: src/components/LoginOptions.vue:883
	// Reference: src/components/OptinFormOptions.vue:869
	__( 'Redirect URL', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:868
	__( 'Customize Labels', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:869
	__( 'Day Label', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:870
	__( 'Hour Label', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:871
	__( 'Minute Label', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:872
	__( 'Second Label', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:874
	__( 'Hours', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:875
	__( 'Minutes', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:876
	__( 'Seconds', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:888
	__( 'Hightlight Color', 'coming-soon' ),

	// Reference: src/components/CountdownOptions.vue:890
	__( 'Restart', 'coming-soon' ),

	// Reference: src/components/CounterOptions.vue:326
	__( 'Starting Number', 'coming-soon' ),

	// Reference: src/components/CounterOptions.vue:327
	__( 'Ending Number', 'coming-soon' ),

	// Reference: src/components/CounterOptions.vue:328
	__( 'Number Prefix', 'coming-soon' ),

	// Reference: src/components/CounterOptions.vue:329
	__( 'Number Suffix', 'coming-soon' ),

	// Reference: src/components/CounterOptions.vue:330
	__( 'Animation Duration', 'coming-soon' ),

	// Reference: src/components/CounterOptions.vue:331
	__( 'Thousands Separator', 'coming-soon' ),

	// Reference: src/components/CounterOptions.vue:332
	// Reference: src/components/PostsOptions.vue:2277
	// Reference: src/components/TeamMemberOptions.vue:1040
	__( 'Separator', 'coming-soon' ),

	// Reference: src/components/CounterOptions.vue:335
	__( 'Dot', 'coming-soon' ),

	// Reference: src/components/CounterOptions.vue:336
	// Reference: src/components/ParticlesBackgroundControl.vue:302
	__( 'Space', 'coming-soon' ),

	// Reference: src/components/CounterOptions.vue:337
	__( 'Title Text Color', 'coming-soon' ),

	// Reference: src/components/CounterOptions.vue:338
	__( 'Number Text Color', 'coming-soon' ),

	// Reference: src/components/CounterOptions.vue:339
	__( 'Number Align', 'coming-soon' ),

	// Reference: src/components/CustomHTML.vue:45
	__( 'Enter Your HTML', 'coming-soon' ),

	// Reference: src/components/CustomHTMLOptions.vue:202
	// Reference: src/views/GlobalCSS.vue:1919
	// Reference: src/views/SetupDesign-Lite.vue:753
	__( 'Expand Editor', 'coming-soon' ),

	// Reference: src/components/CustomHTMLOptions.vue:203
	__( 'Custom Code', 'coming-soon' ),

	// Reference: src/components/CustomHTMLOptions.vue:204
	__( 'Edit Custom HMTL', 'coming-soon' ),

	// Reference: src/components/DeviceVisibilityControl.vue:58
	__( 'Device Visibility', 'coming-soon' ),

	// Reference: src/components/DeviceVisibilityControl.vue:59
	__( 'Hide on Desktop', 'coming-soon' ),

	// Reference: src/components/DeviceVisibilityControl.vue:60
	__( 'Hide on Mobile', 'coming-soon' ),

	// Reference: src/components/DisplaySectionControl.vue:187
	__( 'Z-Index', 'coming-soon' ),

	// Reference: src/components/DisplaySectionControl.vue:189
	__( 'Static', 'coming-soon' ),

	// Reference: src/components/DisplaySectionControl.vue:190
	__( 'Relative', 'coming-soon' ),

	// Reference: src/components/DisplaySectionControl.vue:192
	__( 'Absolute', 'coming-soon' ),

	// Reference: src/components/DisplaySectionControl.vue:193
	__( 'Sticky', 'coming-soon' ),

	// Reference: src/components/DisplaySectionControl.vue:198
	__( 'Offset', 'coming-soon' ),

	// Reference: src/components/DisplaySectionControl.vue:199
	__( 'Overflow', 'coming-soon' ),

	// Reference: src/components/DisplaySectionControl.vue:200
	// Reference: src/components/EDDDownloadsGridOptions.vue:1116
	// Reference: src/components/WCCustomProductsGridOptions.vue:1221
	__( 'Visible', 'coming-soon' ),

	// Reference: src/components/DisplaySectionControl.vue:201
	// Reference: src/components/EDDDownloadsGridOptions.vue:1119
	// Reference: src/components/WCCustomProductsGridOptions.vue:1224
	__( 'Hidden', 'coming-soon' ),

	// Reference: src/components/DividerOptions.vue:365
	__( 'Solid Line', 'coming-soon' ),

	// Reference: src/components/DividerOptions.vue:368
	__( 'Double', 'coming-soon' ),

	// Reference: src/components/DividerOptions.vue:370
	// Reference: src/components/HeightControl.vue:84
	// Reference: src/components/ShapeDividerControl.vue:371
	// Reference: src/components/SpacerOptions.vue:68
	// Reference: src/components/TeamMemberOptions.vue:1031
	__( 'Height', 'coming-soon' ),

	// Reference: src/components/DividerOptions.vue:371
	// Reference: src/components/SocialProfilesOptions.vue:694
	__( 'Icon Size', 'coming-soon' ),

	// Reference: src/components/DividerOptions.vue:379
	__( 'Add Element', 'coming-soon' ),

	// Reference: src/components/DividerOptions.vue:384
	// Reference: src/components/PostauthorboxOptions.vue:342
	__( 'HTML Tag', 'coming-soon' ),

	// Reference: src/components/DividerOptions.vue:385
	// Reference: src/components/PostauthorboxOptions.vue:343
	// Reference: src/components/PostsOptions.vue:2262
	// Reference: src/components/TeamMemberOptions.vue:1116
	__( 'H1', 'coming-soon' ),

	// Reference: src/components/DividerOptions.vue:386
	// Reference: src/components/PostauthorboxOptions.vue:344
	// Reference: src/components/PostsOptions.vue:2263
	// Reference: src/components/TeamMemberOptions.vue:1117
	__( 'H2', 'coming-soon' ),

	// Reference: src/components/DividerOptions.vue:387
	// Reference: src/components/PostauthorboxOptions.vue:345
	// Reference: src/components/PostsOptions.vue:2264
	// Reference: src/components/TeamMemberOptions.vue:1118
	__( 'H3', 'coming-soon' ),

	// Reference: src/components/DividerOptions.vue:388
	// Reference: src/components/PostauthorboxOptions.vue:346
	// Reference: src/components/PostsOptions.vue:2265
	// Reference: src/components/TeamMemberOptions.vue:1119
	__( 'H4', 'coming-soon' ),

	// Reference: src/components/DividerOptions.vue:391
	// Reference: src/components/PostauthorboxOptions.vue:350
	// Reference: src/components/PostsOptions.vue:2269
	// Reference: src/components/TeamMemberOptions.vue:1123
	__( 'span', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:134
	__( 'Please enter date/time format', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:135
	__( 'Please select date/time format', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:136
	__( 'Insert', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:137
	// Reference: src/components/Row.vue:1101
	// Reference: src/components/Section.vue:686
	// Reference: src/views/Layoutnav.vue:1489
	// Reference: src/views/Setup.vue:1034
	__( 'Cancel', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:138
	__( 'Dynamic Text Replacement', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:139
	__( 'DateTime', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:140
	__( 'Query Parameter', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:141
	__( 'Today', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:142
	__( 'Tomorrow', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:143
	__( 'Today Date', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:144
	__( 'Tomorrow Date', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:145
	__( 'Month', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:146
	__( 'Next Month', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:147
	__( 'Year', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:148
	__( 'Select Date Time Format', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:149
	__( 'Query Parameters', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:150
	__( 'Dynamic Text allows to create evergreen text. You can create date based dynamic text or pass in by query parameter. <a href="https://www.seedprod.com/docs/dynamic-text" target="_blank" class="sp-text-primary hover:sp-underline">Learn More</a>', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:151
	__( 'Parameter Name', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:152
	__( 'Default Value', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:153
	__( 'Please enter parameter name', 'coming-soon' ),

	// Reference: src/components/DynamicTextControl.vue:154
	__( 'Don\'t see the date format you need? Click the Learn More link above to learn how to create any date.', 'coming-soon' ),

	// Reference: src/components/EDDAddToCartOptions.vue:788
	// Reference: src/components/EDDBuyNowButtonOptions.vue:817
	// Reference: src/components/EDDCheckoutOptions.vue:630
	// Reference: src/components/EDDDownloadsGridOptions.vue:976
	// Reference: src/components/LoginOptions.vue:879
	// Reference: src/components/OptinFormOptions.vue:851
	// Reference: src/components/WCCartOptions.vue:500
	// Reference: src/components/WCCheckoutOptions.vue:768
	// Reference: src/components/WCCustomProductsGridOptions.vue:1081
	__( 'Fields', 'coming-soon' ),

	// Reference: src/components/EDDAddToCartOptions.vue:801
	// Reference: src/components/EDDBuyNowButtonOptions.vue:830
	// Reference: src/components/EDDCheckoutOptions.vue:647
	// Reference: src/components/EDDDownloadsGridOptions.vue:993
	// Reference: src/components/LoginOptions.vue:893
	// Reference: src/components/OptinFormOptions.vue:882
	// Reference: src/components/WCCartOptions.vue:517
	// Reference: src/components/WCCheckoutOptions.vue:785
	// Reference: src/components/WCCustomProductsGridOptions.vue:1098
	// Reference: src/views/GlobalCSS.vue:1966
	__( 'Field Background Color', 'coming-soon' ),

	// Reference: src/components/EDDAddToCartOptions.vue:822
	// Reference: src/components/EDDBuyNowButtonOptions.vue:851
	// Reference: src/components/EDDCheckoutOptions.vue:648
	// Reference: src/components/EDDDownloadsGridOptions.vue:994
	// Reference: src/components/LoginOptions.vue:892
	// Reference: src/components/OptinFormOptions.vue:883
	// Reference: src/components/WCCartOptions.vue:518
	// Reference: src/components/WCCheckoutOptions.vue:786
	// Reference: src/components/WCCustomProductsGridOptions.vue:1099
	// Reference: src/views/GlobalCSS.vue:1965
	__( 'Field Text Color', 'coming-soon' ),

	// Reference: src/components/EDDAddToCartOptions.vue:823
	// Reference: src/components/EDDBuyNowButtonOptions.vue:852
	// Reference: src/components/EDDCheckoutOptions.vue:649
	// Reference: src/components/EDDDownloadsGridOptions.vue:995
	// Reference: src/components/LoginOptions.vue:894
	// Reference: src/components/OptinFormOptions.vue:884
	// Reference: src/components/WCCartOptions.vue:519
	// Reference: src/components/WCCheckoutOptions.vue:787
	// Reference: src/components/WCCustomProductsGridOptions.vue:1100
	// Reference: src/views/GlobalCSS.vue:1967
	__( 'Field Border Color', 'coming-soon' ),

	// Reference: src/components/EDDAddToCartOptions.vue:824
	// Reference: src/components/EDDBuyNowButtonOptions.vue:853
	// Reference: src/components/EDDCheckoutOptions.vue:650
	// Reference: src/components/EDDDownloadsGridOptions.vue:996
	// Reference: src/components/LoginOptions.vue:900
	// Reference: src/components/WCCartOptions.vue:520
	// Reference: src/components/WCCheckoutOptions.vue:788
	// Reference: src/components/WCCustomProductsGridOptions.vue:1101
	// Reference: src/views/GlobalCSS.vue:1972
	__( 'Field Border Width', 'coming-soon' ),

	// Reference: src/components/EDDAddToCartOptions.vue:825
	// Reference: src/components/EDDBuyNowButtonOptions.vue:854
	// Reference: src/components/EDDCartOptions.vue:375
	// Reference: src/components/EDDCheckoutOptions.vue:653
	// Reference: src/components/EDDDownloadsGridOptions.vue:999
	// Reference: src/components/LoginOptions.vue:898
	// Reference: src/components/WCCartOptions.vue:523
	// Reference: src/components/WCCheckoutOptions.vue:791
	// Reference: src/components/WCCustomProductsGridOptions.vue:1104
	__( 'Row Spacing', 'coming-soon' ),

	// Reference: src/components/EDDAddToCartOptions.vue:826
	// Reference: src/components/EDDBuyNowButtonOptions.vue:855
	// Reference: src/components/LoginOptions.vue:922
	__( 'Field Width', 'coming-soon' ),

	// Reference: src/components/EDDAddToCartOptions.vue:827
	// Reference: src/components/EDDBuyNowButtonOptions.vue:856
	__( 'These settings are used to style item quantity fields. To enable them, enable "Misc" &rarr; "General" &rarr; "Cart Item Quantities" in the Downloads Plugin settings. Also uncheck the "Disable quantity input for this product" checkbox in the item download page if it has been checked.', 'coming-soon' ),

	// Reference: src/components/EDDAddToCartOptions.vue:836
	// Reference: src/components/EDDBuyNowButtonOptions.vue:866
	// Reference: src/components/WCAddToCartOptions.vue:734
	__( 'Direct To Checkout', 'coming-soon' ),

	// Reference: src/components/EDDAddToCartOptions.vue:838
	// Reference: src/components/EDDBuyNowButtonOptions.vue:868
	__( '- Select ID -', 'coming-soon' ),

	// Reference: src/components/EDDAddToCartOptions.vue:839
	// Reference: src/components/EDDBuyNowButtonOptions.vue:869
	// Reference: src/components/EDDDownloadsGridOptions.vue:1105
	__( 'Show Price', 'coming-soon' ),

	// Reference: src/components/EDDBuyNowButtonOptions.vue:865
	// Reference: src/components/WCAddToCartOptions.vue:733
	__( 'Product ID', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:357
	// Reference: src/components/EDDCheckoutOptions.vue:629
	// Reference: src/components/EDDDownloadsGridOptions.vue:975
	// Reference: src/components/WCCartOptions.vue:499
	// Reference: src/components/WCCheckoutOptions.vue:767
	// Reference: src/components/WCCustomProductsGridOptions.vue:1080
	// Reference: src/views/GlobalCSS.vue:1912
	// Reference: src/views/SetupDesign-Lite.vue:746
	__( 'Headers', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:358
	// Reference: src/components/EDDCheckoutOptions.vue:631
	// Reference: src/components/EDDDownloadsGridOptions.vue:977
	// Reference: src/components/PricingTableOptions.vue:1283
	// Reference: src/components/WCCartOptions.vue:501
	// Reference: src/components/WCCheckoutOptions.vue:769
	// Reference: src/components/WCCustomProductsGridOptions.vue:1082
	// Reference: src/views/GlobalCSS.vue:1960
	// Reference: src/views/SetupDesign-Lite.vue:748
	__( 'Buttons', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:359
	// Reference: src/components/EDDCheckoutOptions.vue:633
	// Reference: src/components/EDDDownloadsGridOptions.vue:979
	// Reference: src/components/WCCartOptions.vue:503
	// Reference: src/components/WCCheckoutOptions.vue:771
	// Reference: src/components/WCCustomProductsGridOptions.vue:1084
	__( 'Cart', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:360
	// Reference: src/components/EDDCheckoutOptions.vue:634
	// Reference: src/components/EDDDownloadsGridOptions.vue:980
	// Reference: src/components/WCCartOptions.vue:504
	// Reference: src/components/WCCheckoutOptions.vue:772
	// Reference: src/components/WCCustomProductsGridOptions.vue:1085
	__( 'Payment Section', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:362
	// Reference: src/components/EDDCheckoutOptions.vue:636
	// Reference: src/components/EDDDownloadsGridOptions.vue:982
	// Reference: src/components/LoginOptions.vue:930
	// Reference: src/components/OptinFormOptions.vue:885
	// Reference: src/components/WCCartOptions.vue:506
	// Reference: src/components/WCCheckoutOptions.vue:774
	// Reference: src/components/WCCustomProductsGridOptions.vue:1087
	__( 'Light Input Field', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:363
	// Reference: src/components/EDDCheckoutOptions.vue:637
	// Reference: src/components/EDDDownloadsGridOptions.vue:983
	// Reference: src/components/LoginOptions.vue:931
	// Reference: src/components/OptinFormOptions.vue:886
	// Reference: src/components/WCCartOptions.vue:507
	// Reference: src/components/WCCheckoutOptions.vue:775
	// Reference: src/components/WCCustomProductsGridOptions.vue:1088
	__( 'No Border Input Field', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:364
	// Reference: src/components/EDDCheckoutOptions.vue:638
	// Reference: src/components/EDDDownloadsGridOptions.vue:984
	// Reference: src/components/LoginOptions.vue:932
	// Reference: src/components/OptinFormOptions.vue:887
	// Reference: src/components/WCCartOptions.vue:508
	// Reference: src/components/WCCheckoutOptions.vue:776
	// Reference: src/components/WCCustomProductsGridOptions.vue:1089
	__( 'Wide Border Input Field', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:365
	// Reference: src/components/EDDCheckoutOptions.vue:639
	// Reference: src/components/EDDDownloadsGridOptions.vue:985
	// Reference: src/components/LoginOptions.vue:933
	// Reference: src/components/OptinFormOptions.vue:888
	// Reference: src/components/WCCartOptions.vue:509
	// Reference: src/components/WCCheckoutOptions.vue:777
	// Reference: src/components/WCCustomProductsGridOptions.vue:1090
	__( 'Inner Shadow Input Field', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:366
	// Reference: src/components/EDDCheckoutOptions.vue:640
	// Reference: src/components/EDDDownloadsGridOptions.vue:986
	// Reference: src/components/LoginOptions.vue:934
	// Reference: src/components/OptinFormOptions.vue:889
	// Reference: src/components/WCCartOptions.vue:510
	// Reference: src/components/WCCheckoutOptions.vue:778
	// Reference: src/components/WCCustomProductsGridOptions.vue:1091
	__( 'Grey Input Field', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:367
	// Reference: src/components/EDDCheckoutOptions.vue:641
	// Reference: src/components/EDDDownloadsGridOptions.vue:987
	// Reference: src/components/LoginOptions.vue:935
	// Reference: src/components/OptinFormOptions.vue:890
	// Reference: src/components/WCCartOptions.vue:511
	// Reference: src/components/WCCheckoutOptions.vue:779
	// Reference: src/components/WCCustomProductsGridOptions.vue:1092
	__( 'Dark Input Field', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:368
	// Reference: src/components/EDDCheckoutOptions.vue:642
	// Reference: src/components/EDDDownloadsGridOptions.vue:988
	// Reference: src/components/LoginOptions.vue:936
	// Reference: src/components/OptinFormOptions.vue:891
	// Reference: src/components/WCCartOptions.vue:512
	// Reference: src/components/WCCheckoutOptions.vue:780
	// Reference: src/components/WCCustomProductsGridOptions.vue:1093
	__( 'Bottom Border Field', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:369
	// Reference: src/components/EDDCheckoutOptions.vue:643
	// Reference: src/components/EDDDownloadsGridOptions.vue:989
	// Reference: src/components/LoginOptions.vue:937
	// Reference: src/components/OptinFormOptions.vue:892
	// Reference: src/components/WCCartOptions.vue:513
	// Reference: src/components/WCCheckoutOptions.vue:781
	// Reference: src/components/WCCustomProductsGridOptions.vue:1094
	__( 'Transparent Input Field', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:370
	// Reference: src/components/EDDDownloadsGridOptions.vue:990
	// Reference: src/components/WCCartOptions.vue:514
	// Reference: src/components/WCCheckoutOptions.vue:782
	// Reference: src/components/WCCustomProductsGridOptions.vue:1095
	__( 'One Column', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:371
	// Reference: src/components/EDDDownloadsGridOptions.vue:991
	// Reference: src/components/WCCartOptions.vue:515
	// Reference: src/components/WCCheckoutOptions.vue:783
	// Reference: src/components/WCCustomProductsGridOptions.vue:1096
	__( 'Two Column', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:374
	// Reference: src/components/EDDCheckoutOptions.vue:652
	// Reference: src/components/EDDDownloadsGridOptions.vue:998
	// Reference: src/components/LoginOptions.vue:911
	// Reference: src/components/WCCartOptions.vue:522
	// Reference: src/components/WCCheckoutOptions.vue:790
	// Reference: src/components/WCCustomProductsGridOptions.vue:1103
	__( 'Label Font', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:377
	// Reference: src/components/EDDCheckoutOptions.vue:655
	// Reference: src/components/EDDDownloadsGridOptions.vue:1057
	// Reference: src/components/ProductRelatedOptions.vue:624
	// Reference: src/components/WCCartOptions.vue:525
	// Reference: src/components/WCCheckoutOptions.vue:793
	// Reference: src/components/WCCustomProductsGridOptions.vue:1162
	// Reference: src/views/GlobalCSS.vue:1984
	__( 'Button Color', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:384
	// Reference: src/components/EDDCheckoutOptions.vue:665
	// Reference: src/components/EDDDownloadsGridOptions.vue:1011
	// Reference: src/components/WCCartOptions.vue:535
	// Reference: src/components/WCCheckoutOptions.vue:803
	// Reference: src/components/WCCustomProductsGridOptions.vue:1116
	__( 'Cart Border Color', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:385
	// Reference: src/components/EDDCheckoutOptions.vue:666
	// Reference: src/components/EDDDownloadsGridOptions.vue:1012
	// Reference: src/components/WCCartOptions.vue:536
	// Reference: src/components/WCCheckoutOptions.vue:804
	// Reference: src/components/WCCustomProductsGridOptions.vue:1117
	__( 'Cart Border Width', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:388
	__( 'Product Text Color', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:389
	// Reference: src/components/EDDDownloadsGridOptions.vue:1016
	// Reference: src/components/OptinFormOptions.vue:871
	// Reference: src/components/TypographyControl.vue:277
	// Reference: src/components/WCCartOptions.vue:540
	// Reference: src/components/WCCheckoutOptions.vue:808
	// Reference: src/components/WCCustomProductsGridOptions.vue:1121
	__( 'Font Family', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:390
	__( 'Price Text Color', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:391
	// Reference: src/components/EDDDownloadsGridOptions.vue:1018
	// Reference: src/components/WCCartOptions.vue:542
	// Reference: src/components/WCCheckoutOptions.vue:810
	// Reference: src/components/WCCustomProductsGridOptions.vue:1123
	__( 'Header Font Family', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:392
	__( 'Total Text Color', 'coming-soon' ),

	// Reference: src/components/EDDCartOptions.vue:393
	__( 'Links Color', 'coming-soon' ),

	// Reference: src/components/EDDCheckoutOptions.vue:632
	// Reference: src/components/EDDDownloadsGridOptions.vue:978
	// Reference: src/components/WCCartOptions.vue:502
	// Reference: src/components/WCCheckoutOptions.vue:770
	// Reference: src/components/WCCustomProductsGridOptions.vue:1083
	__( 'Alerts', 'coming-soon' ),

	// Reference: src/components/EDDCheckoutOptions.vue:645
	__( 'Total Color', 'coming-soon' ),

	// Reference: src/components/EDDCheckoutOptions.vue:662
	// Reference: src/components/EDDDownloadsGridOptions.vue:1008
	// Reference: src/components/WCCartOptions.vue:532
	// Reference: src/components/WCCheckoutOptions.vue:800
	// Reference: src/components/WCCustomProductsGridOptions.vue:1113
	__( 'Info Highlight Color', 'coming-soon' ),

	// Reference: src/components/EDDCheckoutOptions.vue:663
	// Reference: src/components/EDDDownloadsGridOptions.vue:1009
	// Reference: src/components/WCCartOptions.vue:533
	// Reference: src/components/WCCheckoutOptions.vue:801
	// Reference: src/components/WCCustomProductsGridOptions.vue:1114
	__( 'Error Highlight Color', 'coming-soon' ),

	// Reference: src/components/EDDCheckoutOptions.vue:664
	// Reference: src/components/EDDDownloadsGridOptions.vue:1010
	// Reference: src/components/WCCartOptions.vue:534
	// Reference: src/components/WCCheckoutOptions.vue:802
	// Reference: src/components/WCCustomProductsGridOptions.vue:1115
	__( 'Success Highlight Color', 'coming-soon' ),

	// Reference: src/components/EDDCheckoutOptions.vue:668
	// Reference: src/components/EDDDownloadsGridOptions.vue:1128
	// Reference: src/components/PostsOptions.vue:2285
	// Reference: src/components/PriceListOptions.vue:896
	__( 'Title Color', 'coming-soon' ),

	// Reference: src/components/EDDCheckoutOptions.vue:669
	__( 'Cart Item Color', 'coming-soon' ),

	// Reference: src/components/EDDCheckoutOptions.vue:670
	__( 'Cart Links Color', 'coming-soon' ),

	// Reference: src/components/EDDCheckoutOptions.vue:671
	__( 'Payments Border Color', 'coming-soon' ),

	// Reference: src/components/EDDCheckoutOptions.vue:672
	__( 'Payments Border Radius', 'coming-soon' ),

	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:646
	// Reference: src/components/ImageOptions.vue:712
	// Reference: src/components/PostfeaturedimageOptions.vue:646
	// Reference: src/components/ProductFeaturedImageOptions.vue:646
	__( 'Image Border', 'coming-soon' ),

	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:651
	// Reference: src/components/ImageOptions.vue:717
	// Reference: src/components/PostfeaturedimageOptions.vue:651
	// Reference: src/components/ProductFeaturedImageOptions.vue:651
	// Reference: src/components/TeamMemberOptions.vue:1125
	__( 'Alt Text', 'coming-soon' ),

	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:662
	// Reference: src/components/EDDDownloadsGridOptions.vue:1077
	// Reference: src/components/ImageOptions.vue:728
	// Reference: src/components/ParticlesBackgroundControl.vue:324
	// Reference: src/components/PostfeaturedimageOptions.vue:662
	// Reference: src/components/PostsOptions.vue:2313
	// Reference: src/components/ProductFeaturedImageOptions.vue:662
	// Reference: src/components/ProductRelatedOptions.vue:644
	// Reference: src/components/ShadowControl.vue:146
	// Reference: src/components/WCCustomProductsGridOptions.vue:1182
	__( 'Bottom Drop Shadow', 'coming-soon' ),

	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:669
	// Reference: src/components/EDDDownloadsGridOptions.vue:1084
	// Reference: src/components/ImageOptions.vue:735
	// Reference: src/components/PostfeaturedimageOptions.vue:669
	// Reference: src/components/PostsOptions.vue:2320
	// Reference: src/components/PricingTableOptions.vue:1359
	// Reference: src/components/ProductFeaturedImageOptions.vue:669
	// Reference: src/components/ProductRelatedOptions.vue:651
	// Reference: src/components/WCCustomProductsGridOptions.vue:1189
	__( 'Image Whitespace Padding', 'coming-soon' ),

	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue:673
	// Reference: src/components/IconOptions.vue:286
	// Reference: src/components/ImageOptions.vue:739
	// Reference: src/components/PostfeaturedimageOptions.vue:673
	// Reference: src/components/ProductFeaturedImageOptions.vue:673
	__( 'No Follow', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1017
	// Reference: src/components/WCCartOptions.vue:541
	// Reference: src/components/WCCheckoutOptions.vue:809
	// Reference: src/components/WCCustomProductsGridOptions.vue:1122
	__( 'Header Background Color', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1021
	// Reference: src/components/WCCustomProductsGridOptions.vue:1126
	__( 'Query', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1023
	// Reference: src/components/PostsOptions.vue:2256
	// Reference: src/components/ProductRelatedOptions.vue:615
	// Reference: src/components/WCCustomProductsGridOptions.vue:1128
	__( 'Columns', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1024
	// Reference: src/components/WCCustomProductsGridOptions.vue:1129
	__( 'All Products', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1029
	// Reference: src/components/WCCustomProductsGridOptions.vue:1134
	__( 'Featured Products', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1030
	// Reference: src/components/WCCustomProductsGridOptions.vue:1135
	__( 'Sale Products', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1031
	// Reference: src/components/WCCustomProductsGridOptions.vue:1136
	__( 'Best Selling Products', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1032
	// Reference: src/components/WCCustomProductsGridOptions.vue:1137
	__( 'Recent Products', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1033
	// Reference: src/components/WCCustomProductsGridOptions.vue:1138
	__( 'Top Rated Products', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1034
	// Reference: src/components/WCCustomProductsGridOptions.vue:1139
	__( 'Include', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1035
	// Reference: src/components/WCCustomProductsGridOptions.vue:1140
	__( 'Exclude', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1036
	// Reference: src/components/WCCustomProductsGridOptions.vue:1141
	__( 'Include By', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1037
	// Reference: src/components/WCCustomProductsGridOptions.vue:1142
	__( 'Exclude By', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1038
	// Reference: src/components/WCCustomProductsGridOptions.vue:1143
	__( 'Term', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1039
	// Reference: src/components/PostsOptions.vue:2227
	// Reference: src/components/ProductRelatedOptions.vue:616
	// Reference: src/components/WCCustomProductsGridOptions.vue:1144
	__( 'Order By', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1040
	// Reference: src/components/PostsOptions.vue:2234
	// Reference: src/components/ProductRelatedOptions.vue:617
	// Reference: src/components/WCCustomProductsGridOptions.vue:1145
	__( 'Order', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1044
	// Reference: src/components/ProductRelatedOptions.vue:657
	// Reference: src/components/WCCustomProductsGridOptions.vue:1195
	__( 'Popularity', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1045
	// Reference: src/components/ProductRelatedOptions.vue:659
	// Reference: src/components/StarRatingOptions.vue:302
	// Reference: src/components/WCCustomProductsGridOptions.vue:1197
	__( 'Rating', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1046
	__( 'If orderby is set to random, pagination will be disabled to prevent subsequent pages from showing already-displayed products.', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1047
	// Reference: src/components/PostsOptions.vue:2233
	// Reference: src/components/ProductRelatedOptions.vue:656
	// Reference: src/components/WCCustomProductsGridOptions.vue:1194
	__( 'Menu Order', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1048
	// Reference: src/components/PostsOptions.vue:2252
	// Reference: src/components/ProductRelatedOptions.vue:618
	// Reference: src/components/WCCustomProductsGridOptions.vue:1153
	__( 'ASC', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1049
	// Reference: src/components/PostsOptions.vue:2253
	// Reference: src/components/ProductRelatedOptions.vue:619
	// Reference: src/components/WCCustomProductsGridOptions.vue:1154
	__( 'DESC', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1051
	// Reference: src/components/PostinfoOptions.vue:615
	// Reference: src/components/ProductMetaOptions.vue:341
	// Reference: src/components/ProductRelatedOptions.vue:620
	// Reference: src/components/TypographyControl.vue:282
	// Reference: src/components/WCCustomProductsGridOptions.vue:1156
	__( 'Alignment', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1053
	// Reference: src/components/PriceListOptions.vue:937
	// Reference: src/components/PricingTableOptions.vue:1291
	// Reference: src/components/WCCustomProductsGridOptions.vue:1158
	__( 'Price', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1054
	// Reference: src/components/PriceListOptions.vue:938
	// Reference: src/components/PricingTableOptions.vue:1349
	// Reference: src/components/ProductRelatedOptions.vue:621
	// Reference: src/components/WCCustomProductsGridOptions.vue:1159
	__( 'Price Color', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1058
	// Reference: src/components/LoginOptions.vue:902
	// Reference: src/components/ProductRelatedOptions.vue:625
	// Reference: src/components/WCCustomProductsGridOptions.vue:1163
	__( 'Button Size', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1078
	// Reference: src/components/PostsOptions.vue:2314
	// Reference: src/components/ProductRelatedOptions.vue:645
	// Reference: src/components/WCCustomProductsGridOptions.vue:1183
	__( 'Image Border Color', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1079
	// Reference: src/components/PostsOptions.vue:2315
	// Reference: src/components/ProductRelatedOptions.vue:646
	// Reference: src/components/WCCustomProductsGridOptions.vue:1184
	__( 'Image Border Width', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1085
	__( 'Number', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1086
	// Reference: src/components/PostsOptions.vue:2228
	// Reference: src/components/ProductRelatedOptions.vue:653
	// Reference: src/components/WCCustomProductsGridOptions.vue:1191
	__( '- Select Options -', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1087
	__( 'Post Date(Default)', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1088
	// Reference: src/components/ProductRelatedOptions.vue:655
	// Reference: src/components/WCCustomProductsGridOptions.vue:1193
	__( 'ID', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1089
	// Reference: src/components/PostsOptions.vue:2257
	// Reference: src/components/WCCustomProductsGridOptions.vue:1130
	__( 'Pagination', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1090
	__( 'Current Page Color', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1091
	// Reference: src/components/ProductRelatedOptions.vue:658
	// Reference: src/components/WCCustomProductsGridOptions.vue:1196
	__( 'Random', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1092
	// Reference: src/components/LoginOptions.vue:889
	// Reference: src/components/ProductMetaOptions.vue:344
	__( 'Link Color', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1094
	__( 'Relation', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1095
	__( '- Select Relation -', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1096
	// Reference: src/components/WCCustomProductsGridOptions.vue:1201
	__( 'Select By Category', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1097
	// Reference: src/components/PostsOptions.vue:2220
	// Reference: src/components/WCCustomProductsGridOptions.vue:1202
	__( '- Select Categories -', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1098
	// Reference: src/components/WCCustomProductsGridOptions.vue:1203
	__( 'Select By Tags', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1099
	// Reference: src/components/WCCustomProductsGridOptions.vue:1204
	__( '- Select Tags -', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1100
	// Reference: src/components/WCCustomProductsGridOptions.vue:1205
	__( 'Select By Group', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1101
	// Reference: src/components/WCCustomProductsGridOptions.vue:1206
	__( '- Select Group -', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1102
	__( 'OR', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1103
	__( 'AND', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1104
	__( 'Specify whether the downloads displayed have to be in ALL the categories/tags provided, or just in at least one.', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1106
	// Reference: src/components/PostsOptions.vue:2278
	__( 'Show Excerpt', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1107
	__( 'Show Full Content', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1108
	// Reference: src/components/WCCustomProductsGridOptions.vue:1213
	__( 'Include Selected Terms', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1109
	// Reference: src/components/WCCustomProductsGridOptions.vue:1214
	__( 'Exclude Selected Terms', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1110
	// Reference: src/components/WCCustomProductsGridOptions.vue:1215
	__( 'Include Selected Tags', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1111
	// Reference: src/components/WCCustomProductsGridOptions.vue:1216
	__( 'Exclude Selected Tags', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1112
	// Reference: src/components/PostsOptions.vue:2219
	// Reference: src/components/WCCustomProductsGridOptions.vue:1217
	__( 'Include Selected Categories', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1113
	// Reference: src/components/WCCustomProductsGridOptions.vue:1218
	__( 'Exclude Selected Categories', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1114
	__( 'Show Buy Button', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1115
	__( 'Show Thumbnails', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1117
	// Reference: src/components/WCCustomProductsGridOptions.vue:1222
	__( 'Catalog', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1118
	// Reference: src/components/ImageControl.vue:262
	// Reference: src/components/WCCustomProductsGridOptions.vue:1223
	__( 'Search', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1120
	// Reference: src/components/PostsOptions.vue:2339
	// Reference: src/components/WCCustomProductsGridOptions.vue:1225
	__( 'Featured', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1121
	// Reference: src/components/WCCustomProductsGridOptions.vue:1226
	__( 'Custom Query', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1122
	// Reference: src/components/WCCustomProductsGridOptions.vue:1227
	__( 'Select By ID', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1123
	// Reference: src/components/WCCustomProductsGridOptions.vue:1228
	__( '- Select ID(s) -', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1124
	// Reference: src/components/WCCustomProductsGridOptions.vue:1229
	__( 'Show Items Count', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1125
	// Reference: src/components/WCCustomProductsGridOptions.vue:1230
	__( 'Show Order By', 'coming-soon' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue:1127
	// Reference: src/components/WCCustomProductsGridOptions.vue:1232
	__( 'Archive Products', 'coming-soon' ),

	// Reference: src/components/FeatureOptions.vue:462
	__( 'Al Text', 'coming-soon' ),

	// Reference: src/components/FontAwesomePicker.vue:39
	__( 'Click to select an icon', 'coming-soon' ),

	// Reference: src/components/FontAwesomePicker.vue:40
	__( 'Search icons', 'coming-soon' ),

	// Reference: src/components/FontVariantControl.vue:37
	__( 'Select a Font Weight', 'coming-soon' ),

	// Reference: src/components/FontVariantControl.vue:38
	__( 'Normal 400', 'coming-soon' ),

	// Reference: src/components/FontVariantControl.vue:39
	__( 'Bold 700', 'coming-soon' ),

	// Reference: src/components/Giveaway.vue:170
	__( 'Install Giveaway plugin:', 'coming-soon' ),

	// Reference: src/components/Giveaway.vue:173
	__( 'Giveaway', 'coming-soon' ),

	// Reference: src/components/Giveaway.vue:178
	__( 'Select a Giveway', 'coming-soon' ),

	// Reference: src/components/Giveaway.vue:179
	__( 'You can use RafflePress to build viral giveaways in minutes and explode your email list.', 'coming-soon' ),

	// Reference: src/components/GiveawayOptions.vue:170
	__( 'Select a Giveaway', 'coming-soon' ),

	// Reference: src/components/GiveawayOptions.vue:171
	__( 'Need to make changes? Edit the selected giveaway.', 'coming-soon' ),

	// Reference: src/components/GiveawayOptions.vue:172
	__( '+ New Giveaway', 'coming-soon' ),

	// Reference: src/components/GoogleMapsOptions.vue:230
	__( 'Google Maps', 'coming-soon' ),

	// Reference: src/components/GoogleMapsOptions.vue:231
	__( 'Location', 'coming-soon' ),

	// Reference: src/components/GoogleMapsOptions.vue:232
	__( 'Zoom', 'coming-soon' ),

	// Reference: src/components/GoogleMapsOptions.vue:233
	__( 'Height (px)', 'coming-soon' ),

	// Reference: src/components/GoogleMapsOptions.vue:237
	__( 'Width (%)', 'coming-soon' ),

	// Reference: src/components/HeaderOptions.vue:445
	__( 'Headline', 'coming-soon' ),

	// Reference: src/components/IconPicker.vue:242
	__( 'All Icons', 'coming-soon' ),

	// Reference: src/components/IconPicker.vue:243
	__( 'Font Awesome', 'coming-soon' ),

	// Reference: src/components/IconPicker.vue:244
	__( 'Search icons...', 'coming-soon' ),

	// Reference: src/components/IconPicker.vue:245
	// Reference: src/components/PostinfoOptions.vue:610
	__( 'Choose Icon', 'coming-soon' ),

	// Reference: src/components/IconPicker.vue:246
	__( 'Icon Library', 'coming-soon' ),

	// Reference: src/components/ImageControl.vue:253
	__( 'Choose New Image', 'coming-soon' ),

	// Reference: src/components/ImageControl.vue:258
	__( 'Use Your', 'coming-soon' ),

	// Reference: src/components/ImageControl.vue:259
	__( 'Own Image', 'coming-soon' ),

	// Reference: src/components/ImageControl.vue:260
	// Reference: src/components/Row.vue:1097
	// Reference: src/components/Section.vue:683
	// Reference: src/views/BuilderView.vue:1052
	__( 'or', 'coming-soon' ),

	// Reference: src/components/ImageControl.vue:261
	__( 'Stock Images Library', 'coming-soon' ),

	// Reference: src/components/ImageControl.vue:263
	__( 'Use a', 'coming-soon' ),

	// Reference: src/components/ImageControl.vue:264
	__( 'Stock Image', 'coming-soon' ),

	// Reference: src/components/ImageControl.vue:265
	__( 'Search images...', 'coming-soon' ),

	// Reference: src/components/ImageOptions.vue:740
	__( 'Link Type', 'coming-soon' ),

	// Reference: src/components/ImageOptions.vue:741
	__( 'Custom Link', 'coming-soon' ),

	// Reference: src/components/ImageOptions.vue:742
	__( 'Media - Lightbox', 'coming-soon' ),

	// Reference: src/components/ImageOptions.vue:744
	__( 'Object Fit', 'coming-soon' ),

	// Reference: src/components/ImageOptions.vue:746
	__( 'Fill', 'coming-soon' ),

	// Reference: src/components/ImageOptions.vue:749
	__( 'Border Radius Unit', 'coming-soon' ),

	// Reference: src/components/ListTable.vue:470
	__( 'Bulk Actions', 'coming-soon' ),

	// Reference: src/components/ListTable.vue:471
	// Reference: src/components/WpWidgetBlockOptions.vue:187
	__( 'Apply', 'coming-soon' ),

	// Reference: src/components/ListTable.vue:472
	__( 'items', 'coming-soon' ),

	// Reference: src/components/ListTable.vue:473
	__( 'No items found.', 'coming-soon' ),

	// Reference: src/components/ListTable.vue:475
	__( 'Select bulk action', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:49
	// Reference: src/components/LiteCTASubscribers.vue:204
	// Reference: src/components/LiteCTATemplates.vue:45
	// Reference: src/components/SettingsLiteCTA.vue:153
	// Reference: src/components/UpgradeCTABuilder.vue:45
	__( 'Dismiss this message', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:50
	// Reference: src/components/LiteCTASubscribers.vue:205
	// Reference: src/components/LiteCTATemplates.vue:46
	// Reference: src/components/SettingsLiteCTA.vue:154
	// Reference: src/components/UpgradeCTABuilder.vue:46
	__( 'Get SeedProd Lite and Unlock all the Powerful Features', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:54
	// Reference: src/components/UpgradeCTABuilder.vue:50
	__( 'Thanks for being a loyal SeedProd Lite user. Upgrade to
SeedProd Lite to unlock all the awesome features and
experience why SeedProd is the best WordPress landing
page plugin.', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:61
	// Reference: src/components/LiteCTASubscribers.vue:216
	// Reference: src/components/LiteCTATemplates.vue:57
	// Reference: src/components/SettingsLiteCTA.vue:165
	// Reference: src/components/UpgradeCTABuilder.vue:57
	__( 'Pro Features:', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:62
	// Reference: src/components/LiteCTATemplates.vue:58
	// Reference: src/components/UpgradeCTABuilder.vue:58
	__( 'Drag & Drop Page Builder', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:63
	// Reference: src/components/SettingsLiteCTA.vue:167
	// Reference: src/components/UpgradeCTABuilder.vue:59
	__( '80+ PRO Page Blocks', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:64
	// Reference: src/components/UpgradeCTABuilder.vue:60
	__( 'PRO Email Marketing Integrations', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:68
	// Reference: src/components/LiteCTASubscribers.vue:223
	// Reference: src/components/SettingsLiteCTA.vue:172
	// Reference: src/components/UpgradeCTABuilder.vue:64
	__( 'Custom 404 Pages', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:69
	// Reference: src/components/LiteCTASubscribers.vue:224
	// Reference: src/components/UpgradeCTABuilder.vue:65
	__( 'Page Access Controls', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:70
	// Reference: src/components/SettingsLiteCTA.vue:174
	// Reference: src/components/UpgradeCTABuilder.vue:66
	__( '200+ PRO Page Templates', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:71
	// Reference: src/components/SettingsLiteCTA.vue:175
	// Reference: src/components/UpgradeCTABuilder.vue:67
	__( 'PRO Smart Sections', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:75
	// Reference: src/components/LiteCTASubscribers.vue:230
	// Reference: src/components/UpgradeCTABuilder.vue:71
	__( 'Email Subscriber Management', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:76
	// Reference: src/components/LiteCTASubscribers.vue:231
	// Reference: src/components/SettingsLiteCTA.vue:180
	// Reference: src/components/UpgradeCTABuilder.vue:72
	// Reference: src/views/TemplateChooser-Lite.vue:1224
	__( 'Saved Templates', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:77
	// Reference: src/components/LiteCTASubscribers.vue:232
	// Reference: src/components/LiteCTATemplates.vue:73
	// Reference: src/components/SettingsLiteCTA.vue:181
	// Reference: src/components/UpgradeCTABuilder.vue:73
	__( 'Plus much more...', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:79
	// Reference: src/components/LiteCTASubscribers.vue:233
	// Reference: src/components/LiteCTATemplates.vue:74
	// Reference: src/components/SettingsLiteCTA.vue:182
	// Reference: src/components/UpgradeCTABuilder.vue:75
	__( 'Bonus:', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:80
	// Reference: src/components/LiteCTASubscribers.vue:234
	// Reference: src/components/LiteCTATemplates.vue:75
	// Reference: src/components/SettingsLiteCTA.vue:183
	// Reference: src/components/UpgradeCTABuilder.vue:76
	__( 'SeedProd Lite users get', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:81
	// Reference: src/components/LiteCTASubscribers.vue:235
	// Reference: src/components/LiteCTATemplates.vue:76
	// Reference: src/components/SettingsLiteCTA.vue:184
	// Reference: src/components/UpgradeCTABuilder.vue:77
	__( 'a discount off the regular price', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:85
	// Reference: src/components/LiteCTASubscribers.vue:239
	// Reference: src/components/LiteCTATemplates.vue:80
	// Reference: src/components/SettingsLiteCTA.vue:188
	// Reference: src/components/UpgradeCTABuilder.vue:81
	__( 'automatically applied at checkout.', 'coming-soon' ),

	// Reference: src/components/LiteCTABuilder.vue:89
	// Reference: src/components/LiteCTASubscribers.vue:243
	// Reference: src/components/LiteCTATemplates.vue:84
	// Reference: src/components/SettingsLiteCTA.vue:192
	// Reference: src/components/UpgradeCTABuilder.vue:85
	__( 'Get SeedProd Lite Today and Unlock all the Powerful Features »', 'coming-soon' ),

	// Reference: src/components/LiteCTASubscribers.vue:217
	__( 'Filter by Page', 'coming-soon' ),

	// Reference: src/components/LiteCTASubscribers.vue:218
	__( 'Export to a CSV File', 'coming-soon' ),

	// Reference: src/components/LiteCTASubscribers.vue:219
	__( 'Premium Email Marketing Integrations', 'coming-soon' ),

	// Reference: src/components/LiteCTASubscribers.vue:225
	__( 'Subscribers Over Time', 'coming-soon' ),

	// Reference: src/components/LiteCTASubscribers.vue:226
	__( 'See Name and Emails', 'coming-soon' ),

	// Reference: src/components/LiteCTATemplates.vue:59
	__( 'More Premium Blocks', 'coming-soon' ),

	// Reference: src/components/LiteCTATemplates.vue:60
	__( 'Capture Emails and Leads', 'coming-soon' ),

	// Reference: src/components/LiteCTATemplates.vue:64
	__( 'Marketing & CRM Integrations', 'coming-soon' ),

	// Reference: src/components/LiteCTATemplates.vue:65
	__( 'Maintenance Access Controls', 'coming-soon' ),

	// Reference: src/components/LiteCTATemplates.vue:66
	__( 'Growing Library of Templates', 'coming-soon' ),

	// Reference: src/components/LiteCTATemplates.vue:67
	__( 'Smart Sections', 'coming-soon' ),

	// Reference: src/components/LiteCTATemplates.vue:71
	__( 'More Design Controls', 'coming-soon' ),

	// Reference: src/components/LiteCTATemplates.vue:72
	__( 'Coming Soon Access Controls', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:884
	__( 'Label for User field', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:885
	__( 'Placeholder for User field', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:886
	__( 'Label for Password field', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:887
	__( 'Placeholder for Password field', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:890
	__( 'Link Hover Color', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:891
	__( 'Label Text Color', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:896
	__( 'Button Background Color', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:897
	__( 'Field Size', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:899
	__( 'Label Spacing', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:901
	__( 'Field Border Radius', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:904
	// Reference: src/components/OptinFormOptions.vue:849
	__( 'Success Action', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:905
	__( 'Additional Options', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:908
	__( 'Remember User Label', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:909
	__( 'Lost Password Link Text', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:910
	// Reference: src/views/GlobalCSS.vue:1935
	// Reference: src/views/SetupDesign-Lite.vue:755
	__( 'Colors', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:912
	__( 'Label Font Weight', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:913
	__( 'Field Font', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:914
	__( 'Field Font Weight', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:915
	// Reference: src/views/GlobalCSS.vue:1986
	__( 'Button Font', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:916
	__( 'Button Font Weight', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:917
	__( 'Logged In Text', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:918
	__( 'This text displays in place of a form if the user is already logged in. {user} will be replaced by the user\'s display name.', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:919
	__( '(e.g. \'Remember Me\')', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:920
	__( '(e.g. \'Lost your password?\')', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:921
	__( 'Button Border Radius', 'coming-soon' ),

	// Reference: src/components/LoginOptions.vue:928
	__( 'Label Text Size', 'coming-soon' ),

	// Reference: src/components/MarginControl.vue:332
	__( 'Margin', 'coming-soon' ),

	// Reference: src/components/MenuCartOptions.vue:186
	__( 'Hide on Empty', 'coming-soon' ),

	// Reference: src/components/MenuCartOptions.vue:188
	__( 'Show Subtotal', 'coming-soon' ),

	// Reference: src/components/MenuCartOptions.vue:190
	__( 'Badge Color', 'coming-soon' ),

	// Reference: src/components/MenuCartOptions.vue:191
	__( 'Badge Text Color', 'coming-soon' ),

	// Reference: src/components/Modal.vue:33
	__( 'default header', 'coming-soon' ),

	// Reference: src/components/Modal.vue:34
	__( 'default body', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:582
	__( 'URL Link', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:585
	__( 'Mobile Menu', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:586
	__( 'On', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:587
	__( 'Off', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:588
	__( 'Hover Color', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:590
	__( 'Menu Type', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:592
	__( 'WordPress Menu', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:593
	__( 'Sub Menu Background Color', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:594
	__( 'Sub Menu Border Radius', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:595
	__( 'Sub Menu Line Height', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:596
	__( 'Sub Menu Border Width', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:597
	__( 'Sub Menu Border Color', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:598
	__( 'Sub Menu Text Color', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:599
	__( 'Sub Menu Hover Color', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:600
	__( 'Sub Menu', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:609
	__( 'Menus', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:610
	// Reference: src/components/PostauthorboxOptions.vue:361
	__( 'Go to the', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:611
	__( 'Menus Screen', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:612
	__( 'to manage your menus', 'coming-soon' ),

	// Reference: src/components/NavOptions.vue:613
	__( 'There are no menus in your site.', 'coming-soon' ),

	// Reference: src/components/OptinFormOptions.vue:848
	__( 'Submit Button', 'coming-soon' ),

	// Reference: src/components/OptinFormOptions.vue:853
	// Reference: src/components/SocialSharingOptions.vue:395
	// Reference: src/components/StarRatingOptions.vue:303
	// Reference: src/views/GlobalCSS.vue:1962
	__( 'Label', 'coming-soon' ),

	// Reference: src/components/OptinFormOptions.vue:855
	__( 'Required', 'coming-soon' ),

	// Reference: src/components/OptinFormOptions.vue:864
	__( 'Input Sizes', 'coming-soon' ),

	// Reference: src/components/OptinFormOptions.vue:865
	__( 'Action To Take', 'coming-soon' ),

	// Reference: src/components/OptinFormOptions.vue:873
	__( 'Remove Inline Padding', 'coming-soon' ),

	// Reference: src/components/OptinFormOptions.vue:893
	__( 'Button text', 'coming-soon' ),

	// Reference: src/components/OptinFormOptions.vue:895
	__( 'All emails captured can be seen on the <a href="admin.php?page=seedprod_lite#/subscribers/0" class="sp-text-primary">Subscribers Page</a>. Click the <strong>Connect</strong> tab on the top menu to send your emails to the email service provider of your choice.', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:298
	__( 'Enable Particle Background', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:299
	__( 'Particle Background', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:301
	__( 'Polygon', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:303
	__( 'Snow', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:304
	__( 'Snowflakes', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:305
	__( 'Christmas', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:306
	__( 'Halloween', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:309
	__( 'Opacity', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:310
	__( 'Flow Direction', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:319
	__( 'Advanced Settings', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:320
	__( 'Number of Particles', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:321
	__( 'Particle Size', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:322
	__( 'Move Speed', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:323
	__( 'Enable Hover Effect', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:326
	__( 'Add custom JSON for the Particle Background. Please follow below steps:', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:327
	__( '- Please visit this link ', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:328
	__( 'here', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:329
	__( ' and choose required attributes for particle', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:330
	__( '- Once a custom style is created, download JSON from "Download current config (json)" link', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:331
	__( '- Copy JSON code and paste below.', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:332
	__( 'Particle hover effect will not work in the following scenarios:', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:333
	__( '- In the builder area.', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:334
	__( '- Content added in the section occupies the entire space and leaves it inaccessible.', 'coming-soon' ),

	// Reference: src/components/ParticlesBackgroundControl.vue:335
	__( 'Note: Increasing the number of particles can slow down your page.', 'coming-soon' ),

	// Reference: src/components/PostauthorboxOptions.vue:339
	__( 'Profile Picture', 'coming-soon' ),

	// Reference: src/components/PostauthorboxOptions.vue:340
	__( 'Display Name', 'coming-soon' ),

	// Reference: src/components/PostauthorboxOptions.vue:341
	__( 'Biography', 'coming-soon' ),

	// Reference: src/components/PostauthorboxOptions.vue:349
	// Reference: src/components/PostsOptions.vue:2268
	// Reference: src/components/TeamMemberOptions.vue:1122
	__( 'div', 'coming-soon' ),

	// Reference: src/components/PostauthorboxOptions.vue:351
	// Reference: src/components/PostsOptions.vue:2270
	// Reference: src/components/TeamMemberOptions.vue:1124
	__( 'p', 'coming-soon' ),

	// Reference: src/components/PostauthorboxOptions.vue:354
	__( 'Website', 'coming-soon' ),

	// Reference: src/components/PostauthorboxOptions.vue:355
	__( 'Archive Posts', 'coming-soon' ),

	// Reference: src/components/PostauthorboxOptions.vue:357
	// Reference: src/components/TeamMemberOptions.vue:1066
	// Reference: src/components/TestimonialOptions.vue:589
	__( 'Name Color', 'coming-soon' ),

	// Reference: src/components/PostauthorboxOptions.vue:358
	__( 'Biography Color', 'coming-soon' ),

	// Reference: src/components/PostauthorboxOptions.vue:362
	__( 'Profile Screen', 'coming-soon' ),

	// Reference: src/components/PostauthorboxOptions.vue:363
	__( 'to manage your profile.', 'coming-soon' ),

	// Reference: src/components/PostcommentsOptions.vue:203
	__( 'Content Policy', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:581
	__( 'Author', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:584
	__( 'Comments', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:587
	// Reference: src/components/PostsOptions.vue:2335
	__( 'Avatar', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:588
	__( 'Link to Author', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:592
	// Reference: src/components/ProductMetaOptions.vue:338
	__( 'Layout Settings', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:597
	// Reference: src/components/ProductMetaOptions.vue:334
	__( 'Add Item', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:598
	// Reference: src/components/ProductMetaOptions.vue:335
	__( 'Caption', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:599
	__( 'Date Format', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:600
	__( 'May 14, 2021 (F j, Y)', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:601
	__( '2021-05-14 (Y-m-d)', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:602
	__( '05/14/2021 (m/d/Y)', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:603
	__( '14/05/2021 (d/m/Y)', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:606
	__( 'Custom Date Format', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:607
	__( 'Use the letters: l D d j S F m M n Y y', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:620
	__( 'Modified Date', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:621
	__( 'Modified Time', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:622
	// Reference: src/components/PostsOptions.vue:2334
	__( 'Tags', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:623
	// Reference: src/components/PostsOptions.vue:2333
	__( 'Category', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:624
	__( 'Terms', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:625
	__( 'Time Format', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:626
	__( '9:15 am (g:i a)', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:627
	__( '9:15 AM (g:i A)', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:628
	__( '09:15 (H:i)', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:629
	__( 'Custom Time Format', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:630
	__( 'Use the letters: g G H i a A', 'coming-soon' ),

	// Reference: src/components/PostinfoOptions.vue:631
	__( 'Show Icons', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2210
	__( 'Posts Query', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2211
	__( 'Query Type', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2214
	__( 'Manual', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2215
	__( 'Query By Post Type', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2216
	__( 'Include Selected Post Type(s)', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2217
	__( '- Select Post Type(s) -', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2218
	__( 'Query By Category', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2221
	__( 'Query By Tag(s)', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2222
	__( 'Include Selected Tag(s)', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2223
	__( '- Select Tag(s) -', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2224
	__( 'Query By Author(s)', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2225
	__( 'Include Selected Author(s)', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2226
	__( '- Select Author(s) -', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2230
	__( 'Date Last Modified', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2232
	__( 'Comment Count', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2235
	// Reference: src/components/TestimonialOptions.vue:604
	__( 'Autoplay Speed', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2236
	__( 'Slides to Show', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2247
	// Reference: src/components/TestimonialOptions.vue:616
	__( 'seconds', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2250
	// Reference: src/components/TestimonialOptions.vue:602
	__( 'AutoPlay', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2251
	// Reference: src/components/TestimonialOptions.vue:603
	__( 'Pause On Hover', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2254
	__( 'Query Params', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2258
	__( 'Number Per Pages', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2259
	__( 'Show Feature Image', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2260
	__( 'Show Title', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2271
	__( 'Show Meta', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2272
	__( 'Show Date Modified', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2273
	__( 'Show Author', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2274
	__( 'Show Date', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2275
	__( 'Show Time', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2276
	__( 'Show Comment Count', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2279
	__( 'Excerpt Length', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2280
	__( 'Show Read More', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2286
	__( 'Meta Text', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2287
	__( 'Meta Text Color', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2288
	__( 'Excerpt', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2289
	__( 'Excerpt Color', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2290
	__( 'Read More Text', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2291
	__( 'Read More Text Color', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2292
	__( 'Pagination Color', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2293
	__( 'Space Bottom', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2325
	__( 'Post Padding', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2326
	__( 'Image Margin', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2327
	__( 'Skin', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2328
	__( 'Classic', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2329
	__( 'Card', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2330
	__( 'Full Content', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2331
	__( 'Badge', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2332
	__( 'Badge Taxonomy', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2337
	__( 'Grid', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2338
	__( 'Carousel', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2340
	__( 'Masonry', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2341
	__( 'Creative', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2342
	__( 'Minimal', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2343
	__( 'Business News', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2344
	// Reference: src/components/PriceListOptions.vue:889
	// Reference: src/components/TeamMemberOptions.vue:1097
	__( 'Image Position', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2350
	__( 'Bottom Spacing', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2351
	__( 'Taxonomy', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2352
	__( 'Navigation Color', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2353
	__( 'Navigation Position', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2356
	__( 'Navigation', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2357
	__( 'Arrows and Dots', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2358
	__( 'Arrows', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2359
	__( 'Dots', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2360
	__( 'Image Height', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2362
	__( 'Post Background Color', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2363
	__( 'Divider Border Color', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2368
	__( 'Content Area', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2369
	__( 'Content Area Border', 'coming-soon' ),

	// Reference: src/components/PostsOptions.vue:2373
	__( 'Post', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:880
	__( 'Left Layout Template', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:881
	__( 'Right Layout Template', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:882
	__( 'No Image Template', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:884
	__( 'Price List Items', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:890
	__( 'Overall Alignment', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:891
	__( 'Vertical Alignment', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:899
	__( 'Enter Title', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:900
	__( 'Enter Description', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:902
	__( 'Actual Price', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:903
	__( 'Offering Discount?', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:913
	__( 'Title Price Seperator', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:928
	__( 'Link Complete Box', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:929
	__( 'Price Position', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:930
	__( 'Below Heading and Description', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:931
	__( 'Right of Heading', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:939
	__( 'Discount Color', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:940
	// Reference: src/components/TeamMemberOptions.vue:1107
	__( 'Image Area', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:941
	// Reference: src/components/TeamMemberOptions.vue:1108
	__( 'Shape', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:943
	// Reference: src/components/TeamMemberOptions.vue:1110
	__( 'Rounded', 'coming-soon' ),

	// Reference: src/components/PriceListOptions.vue:944
	// Reference: src/components/TeamMemberOptions.vue:1111
	__( 'Circle', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1276
	__( 'Features List', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1278
	__( 'Plan Name', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1280
	__( 'Currency Symbol', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1284
	__( 'Plan Name Typography', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1285
	__( 'Plan Name Color', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1286
	__( 'Top Button Size', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1287
	__( 'Top Button', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1290
	__( 'Bottom Button', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1292
	__( 'Top Size', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1293
	__( 'Top Button Before Text Icon', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1294
	__( 'Top Button After Text Icon', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1295
	__( 'Regular Price Color', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1299
	__( 'Top Button Border Radius', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1300
	__( 'Bottom Button Border Radius', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1301
	__( '$ Dollar', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1302
	__( '€ Euro', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1303
	__( '฿ Baht', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1304
	__( '₣ Franc', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1305
	__( 'ƒ Guilder', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1306
	__( 'kr Krona', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1307
	__( '₤ Lira', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1308
	__( '₧ Peseta', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1309
	__( '₱ Peso', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1310
	__( '£ Pound Sterling', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1311
	__( 'R$ Real', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1312
	__( '₽ Ruble', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1313
	__( '₨ Rupee', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1314
	__( '₹ Rupee (Indian)', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1315
	__( '₪ Shekel', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1316
	__( '¥ Yen/Yuan', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1317
	__( '₩ Won', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1319
	__( 'Custom Symbol', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1320
	__( 'Period', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1321
	__( 'Show Regular Price', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1322
	__( 'Regular Price', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1323
	__( 'Regular Price Label', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1325
	__( 'Show Top Button', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1326
	__( 'Top Button Text', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1327
	__( 'Top Button Link', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1330
	__( 'Show Bottom Button', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1331
	__( 'Bottom Button Text', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1332
	__( 'Bottom Button Link', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1335
	__( 'Top Button Color', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1336
	__( 'Features List Color', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1339
	__( 'Bottom Button Color', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1340
	__( 'Bottom Button Size', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1341
	__( 'Bottom Button Before Text Icon', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1345
	__( 'Bottom Button After Text Icon', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1350
	__( 'Price Superscript', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1351
	__( 'Price Superscript Top', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1352
	__( 'Block', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1360
	__( 'Currency Symbol Position', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1361
	__( 'Before', 'coming-soon' ),

	// Reference: src/components/PricingTableOptions.vue:1362
	__( 'After', 'coming-soon' ),

	// Reference: src/components/ProductDataTabsOptions.vue:331
	// Reference: src/components/ProductGalleryImagesOptions.vue:203
	__( 'Tab', 'coming-soon' ),

	// Reference: src/components/ProductDataTabsOptions.vue:333
	// Reference: src/components/ProductGalleryImagesOptions.vue:205
	__( 'Panel', 'coming-soon' ),

	// Reference: src/components/ProductDataTabsOptions.vue:334
	// Reference: src/components/ProductGalleryImagesOptions.vue:206
	__( 'Heading', 'coming-soon' ),

	// Reference: src/components/ProductDataTabsOptions.vue:335
	// Reference: src/components/ProductGalleryImagesOptions.vue:207
	__( 'Tabs', 'coming-soon' ),

	// Reference: src/components/ProductDataTabsOptions.vue:336
	// Reference: src/components/ProductGalleryImagesOptions.vue:208
	// Reference: src/components/WpWidgetBlockOptions.vue:185
	__( 'Heading Color', 'coming-soon' ),

	// Reference: src/components/ProductDataTabsOptions.vue:340
	// Reference: src/components/ProductGalleryImagesOptions.vue:212
	__( 'Panel Padding', 'coming-soon' ),

	// Reference: src/components/ProductGalleryImagesOptions.vue:214
	__( 'Zoom Button', 'coming-soon' ),

	// Reference: src/components/ProductGalleryImagesOptions.vue:215
	__( 'Position Right', 'coming-soon' ),

	// Reference: src/components/ProductGalleryImagesOptions.vue:216
	__( 'Position Top', 'coming-soon' ),

	// Reference: src/components/ProductMetaOptions.vue:324
	__( 'View', 'coming-soon' ),

	// Reference: src/components/ProductMetaOptions.vue:325
	__( 'Table', 'coming-soon' ),

	// Reference: src/components/ProductMetaOptions.vue:326
	// Reference: src/components/ProductPriceOptions.vue:186
	// Reference: src/components/SocialProfilesOptions.vue:689
	__( 'Stacked', 'coming-soon' ),

	// Reference: src/components/ProductMetaOptions.vue:327
	__( 'Inline', 'coming-soon' ),

	// Reference: src/components/ProductPriceOptions.vue:185
	__( 'Sale Price', 'coming-soon' ),

	// Reference: src/components/ProductRelatedOptions.vue:652
	__( 'Posts Per Page', 'coming-soon' ),

	// Reference: src/components/ProductRelatedOptions.vue:661
	// Reference: src/components/WCCustomProductsGridOptions.vue:1231
	__( 'Sale Badge Color', 'coming-soon' ),

	// Reference: src/components/ProgressBarOptions.vue:324
	__( 'Progress Bar', 'coming-soon' ),

	// Reference: src/components/ProgressBarOptions.vue:325
	__( 'Bar Text', 'coming-soon' ),

	// Reference: src/components/ProgressBarOptions.vue:326
	__( 'Percent', 'coming-soon' ),

	// Reference: src/components/ProgressBarOptions.vue:328
	__( 'My Text', 'coming-soon' ),

	// Reference: src/components/Row.vue:1098
	// Reference: src/components/Section.vue:684
	// Reference: src/views/BuilderView.vue:1053
	__( 'Drag a new block here', 'coming-soon' ),

	// Reference: src/components/Row.vue:1099
	// Reference: src/components/Section.vue:688
	// Reference: src/views/BuilderView.vue:1054
	// Reference: src/views/Layoutnav.vue:1491
	__( 'Choose your layout:', 'coming-soon' ),

	// Reference: src/components/Row.vue:1100
	__( 'Enter a new block template name:', 'coming-soon' ),

	// Reference: src/components/Row.vue:1102
	// Reference: src/components/Section.vue:687
	// Reference: src/views/Layoutnav.vue:1490
	// Reference: src/views/Setup.vue:1042
	__( 'Save Template', 'coming-soon' ),

	// Reference: src/components/RowOptions.vue:668
	__( 'Column Gutter', 'coming-soon' ),

	// Reference: src/components/RowOptions.vue:698
	__( 'Row Width', 'coming-soon' ),

	// Reference: src/components/RowOptions.vue:699
	// Reference: src/components/SectionOptions.vue:375
	__( 'Full Screen', 'coming-soon' ),

	// Reference: src/components/RowOptions.vue:700
	// Reference: src/components/SectionOptions.vue:376
	__( 'Fixed Width', 'coming-soon' ),

	// Reference: src/components/RowOptions.vue:701
	// Reference: src/components/SectionOptions.vue:377
	__( 'Content Width', 'coming-soon' ),

	// Reference: src/components/Section.vue:685
	// Reference: src/views/Layoutnav.vue:1488
	__( 'Enter a new section template name:', 'coming-soon' ),

	// Reference: src/components/SectionOptions.vue:374
	__( 'Section Width', 'coming-soon' ),

	// Reference: src/components/SettingsLiteCTA.vue:166
	__( 'Powerful Page Editor', 'coming-soon' ),

	// Reference: src/components/SettingsLiteCTA.vue:168
	__( 'Email Marketing Integrations', 'coming-soon' ),

	// Reference: src/components/SettingsLiteCTA.vue:173
	__( 'Access Controls', 'coming-soon' ),

	// Reference: src/components/SettingsLiteCTA.vue:179
	__( 'Subscriber Management', 'coming-soon' ),

	// Reference: src/components/ShadowControl.vue:142
	__( 'Spread', 'coming-soon' ),

	// Reference: src/components/ShadowControl.vue:144
	__( 'Outline', 'coming-soon' ),

	// Reference: src/components/ShadowControl.vue:145
	__( 'Inset', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:351
	__( 'Mountains', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:352
	__( 'Drops', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:353
	__( 'Clouds', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:354
	__( 'Zigzag', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:355
	__( 'Pyramids', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:356
	__( 'Triangle', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:357
	__( 'Triangle Asymmetrical', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:358
	__( 'Tilt', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:359
	__( 'Tilt Opacity', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:360
	__( 'Fan Opacity', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:361
	__( 'Curve', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:362
	__( 'Curve Asymmetrical', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:363
	__( 'Waves', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:364
	__( 'Waves Brush', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:365
	__( 'Waves Pattern', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:366
	__( 'Arrow', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:367
	__( 'Split', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:368
	__( 'Book', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:373
	__( 'Invert', 'coming-soon' ),

	// Reference: src/components/ShapeDividerControl.vue:374
	__( 'Bring to Front', 'coming-soon' ),

	// Reference: src/components/ShortcodeOptions.vue:142
	__( 'Shortcode', 'coming-soon' ),

	// Reference: src/components/ShortcodeOptions.vue:146
	__( 'Show Shortcode Preview', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:673
	// Reference: src/components/SocialSharingOptions.vue:390
	__( 'Select a Type', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:674
	// Reference: src/components/SocialSharingOptions.vue:391
	__( 'Facebook', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:675
	// Reference: src/components/SocialSharingOptions.vue:392
	__( 'Twitter', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:676
	// Reference: src/components/SocialSharingOptions.vue:393
	__( 'LinkedIn', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:677
	// Reference: src/components/SocialSharingOptions.vue:394
	__( 'Pinterest', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:678
	// Reference: src/components/VideoOptions.vue:236
	__( 'YouTube', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:679
	__( 'Instagram', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:680
	__( 'Snapchat', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:681
	__( 'WordPress', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:682
	__( 'Github', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:683
	__( 'SoundCloud', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:684
	__( 'RSS', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:686
	__( 'URL (Include https:// for web links)', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:696
	// Reference: src/components/TeamMemberOptions.vue:1058
	__( 'Icon Padding', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:705
	__( 'Phone', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:707
	__( 'Discord', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:708
	__( 'Telegram', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:709
	__( 'Facebook Messenger', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:710
	__( 'Slack', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:711
	__( 'Vimeo', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:712
	__( 'Weibo', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:713
	__( 'Whatsapp', 'coming-soon' ),

	// Reference: src/components/SocialProfilesOptions.vue:714
	__( 'TikTok', 'coming-soon' ),

	// Reference: src/components/SocialSharingOptions.vue:387
	__( 'Social Sharing', 'coming-soon' ),

	// Reference: src/components/SocialSharingOptions.vue:388
	__( 'Add New Share', 'coming-soon' ),

	// Reference: src/components/SocialSharingOptions.vue:396
	__( 'Tweet Text', 'coming-soon' ),

	// Reference: src/components/SpacerOptions.vue:67
	__( 'Spacer', 'coming-soon' ),

	// Reference: src/components/StarRatingOptions.vue:299
	__( 'Star Rating', 'coming-soon' ),

	// Reference: src/components/StarRatingOptions.vue:306
	__( 'Star Color', 'coming-soon' ),

	// Reference: src/components/StarRatingOptions.vue:308
	__( 'Empty Star Color', 'coming-soon' ),

	// Reference: src/components/StripepaymentOptions.vue:1181
	__( 'Payment Setup', 'coming-soon' ),

	// Reference: src/components/StripepaymentOptions.vue:1182
	__( 'Amount', 'coming-soon' ),

	// Reference: src/components/StripepaymentOptions.vue:1183
	__( 'Payment Description', 'coming-soon' ),

	// Reference: src/components/StripepaymentOptions.vue:1184
	__( 'Payment Currency', 'coming-soon' ),

	// Reference: src/components/StripepaymentOptions.vue:1185
	__( 'Success URL', 'coming-soon' ),

	// Reference: src/components/TeamMemberOptions.vue:1033
	__( 'Show Designation', 'coming-soon' ),

	// Reference: src/components/TeamMemberOptions.vue:1035
	__( 'Show Description', 'coming-soon' ),

	// Reference: src/components/TeamMemberOptions.vue:1038
	__( 'PX', 'coming-soon' ),

	// Reference: src/components/TeamMemberOptions.vue:1039
	__( '%', 'coming-soon' ),

	// Reference: src/components/TeamMemberOptions.vue:1042
	__( 'Below Name', 'coming-soon' ),

	// Reference: src/components/TeamMemberOptions.vue:1043
	__( 'Below Designation', 'coming-soon' ),

	// Reference: src/components/TeamMemberOptions.vue:1044
	__( 'Below Description', 'coming-soon' ),

	// Reference: src/components/TeamMemberOptions.vue:1046
	__( 'Thickness', 'coming-soon' ),

	// Reference: src/components/TeamMemberOptions.vue:1048
	__( 'Social Icons', 'coming-soon' ),

	// Reference: src/components/TeamMemberOptions.vue:1075
	__( 'Designation Color', 'coming-soon' ),

	// Reference: src/components/TeamMemberOptions.vue:1077
	__( 'Designation', 'coming-soon' ),

	// Reference: src/components/TeamMemberOptions.vue:1102
	__( 'Social Icon Align', 'coming-soon' ),

	// Reference: src/components/TeamMemberOptions.vue:1103
	__( 'Seperator Align', 'coming-soon' ),

	// Reference: src/components/TeamMemberOptions.vue:1104
	__( 'Designation Align', 'coming-soon' ),

	// Reference: src/components/TeamMemberOptions.vue:1106
	__( 'Name Align', 'coming-soon' ),

	// Reference: src/components/TemplatetagOptions.vue:120
	__( 'Templatetag', 'coming-soon' ),

	// Reference: src/components/TemplatetagOptions.vue:124
	__( 'Show Templatetag Preview', 'coming-soon' ),

	// Reference: src/components/TemplatetagOptions.vue:125
	__( 'Select Type', 'coming-soon' ),

	// Reference: src/components/TestimonialOptions.vue:594
	__( 'Add Testimonial', 'coming-soon' ),

	// Reference: src/components/TestimonialOptions.vue:597
	__( 'Navigation Color Mode', 'coming-soon' ),

	// Reference: src/components/TestimonialOptions.vue:598
	__( 'Dark', 'coming-soon' ),

	// Reference: src/components/TestimonialOptions.vue:599
	__( 'Light', 'coming-soon' ),

	// Reference: src/components/TestimonialOptions.vue:605
	__( 'Testimonial to Show', 'coming-soon' ),

	// Reference: src/components/TestimonialOptions.vue:617
	__( 'Enable Comment Bubble', 'coming-soon' ),

	// Reference: src/components/TestimonialOptions.vue:618
	__( 'Bubble Color', 'coming-soon' ),

	// Reference: src/components/TextOptions.vue:396
	__( 'Visual Editor', 'coming-soon' ),

	// Reference: src/components/TextOptions.vue:397
	__( 'Edit HTML', 'coming-soon' ),

	// Reference: src/components/TypographyControl.vue:274
	__( 'Typography', 'coming-soon' ),

	// Reference: src/components/TypographyControl.vue:279
	__( 'Line Height', 'coming-soon' ),

	// Reference: src/components/TypographyControl.vue:280
	__( 'Letter Spacing', 'coming-soon' ),

	// Reference: src/components/TypographyControl.vue:283
	__( 'Letter Case', 'coming-soon' ),

	// Reference: src/components/VideoOptions.vue:233
	__( 'Video', 'coming-soon' ),

	// Reference: src/components/VideoOptions.vue:238
	// Reference: src/views/GlobalCSS.vue:1899
	// Reference: src/views/SetupDesign-Lite.vue:736
	__( 'YouTube URL', 'coming-soon' ),

	// Reference: src/components/VideoOptions.vue:239
	__( 'Custom Video Code', 'coming-soon' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue:1190
	__( 'Limit', 'coming-soon' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue:1199
	__( 'Select By SKU', 'coming-soon' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue:1200
	__( '- Select SKU(s) -', 'coming-soon' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue:1207
	__( 'On Sale', 'coming-soon' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue:1208
	__( 'Best Selling', 'coming-soon' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue:1209
	__( 'Top Rated', 'coming-soon' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue:1210
	__( 'Query By Attribute', 'coming-soon' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue:1211
	__( '- Select Attribute -', 'coming-soon' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue:1212
	__( '- Select Attribute Terms -', 'coming-soon' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue:1219
	__( 'Select By Visibility', 'coming-soon' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue:1220
	__( '- Select Product Visibility -', 'coming-soon' ),

	// Reference: src/components/WpWidgetBlock-Lite.vue:52
	__( '(Click \'Apply\' on the Widget Settings to see changes)', 'coming-soon' ),

	// Reference: src/components/WpWidgetBlockOptions.vue:190
	__( 'Widget Settings', 'coming-soon' ),

	// Reference: src/components/WpWidgetBlockOptions.vue:192
	__( 'Heading Bottom Margin', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1037
	__( 'Column Uploaded successfully.', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1066
	__( 'There is no content available to paste. Please try copy row first!', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1114
	__( 'Image uploading will take some time.', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1178
	__( 'Row Uploaded successfully.', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1236
	__( 'Block Copied.', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1266
	__( 'Column Copied.', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1298
	__( 'Row Copied.', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1335
	__( 'Section Copied.', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1635
	// Reference: src/views/SectionTemplateOptions-Lite.vue:475
	// Reference: src/views/TemplateChooser-Lite.vue:1416
	__( 'Are you sure you want to delete?', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1644
	// Reference: src/views/SectionTemplateOptions-Lite.vue:484
	// Reference: src/views/TemplateChooser-Lite.vue:1425
	__( 'Yes, delete it!', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1766
	__( 'Visit Docs&nbsp;<i class="fas fa-external-link-alt"></i>', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1792
	__( ' is a PRO Feature', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1796
	__( ' feature is not available on your plan. Please upgrade to the PRO plan to unlock all these awesome features.', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1810
	__( 'UPGRADE TO PRO', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1814
	__( '<strong>Bonus:</strong>&nbsp;SeedProd Lite users get a discount off the regular price, automatically applied at checkout.', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1827
	__( 'Thanks for your interest in SeedProd Lite!<br>If you have any questions or issues just <a href=\'https://www.seedprod.com/?contact=1\' target=\'_blank\'>let us know</a>.<br><br>After purchasing SeedProd Lite, you\'ll need to download and install the Pro version of the plugin, and then remove the free plugin. <br><br>(Don\'t worry, all your settings will be preserved.)', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1843
	__( 'Upgrade to PRO', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1844
	__( 'Increase traffic, engagement, and get more email subscribers. Click below to learn more about all our awesome features.', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1850
	__( 'Upgrade to Unlock ', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1852
	__( 'We\'re sorry, the ', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1854
	__( ' feature is not available on your plan. Please upgrade your plan to unlock this feature and more!', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:1870
	__( 'Upgrade with just a click of a button!', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:629
	__( 'There is no content available to paste. Please try copy section first!', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:754
	__( 'Section Uploaded successfully.', 'coming-soon' ),

	// Reference: src/mixins/helpers.js:903
	__( 'Block Uploaded successfully.', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1893
	// Reference: src/views/SetupBlockOptions-Lite.vue:1411
	// Reference: src/views/SetupDesign-Lite.vue:730
	__( 'Editing:', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1894
	__( 'Global CSS Settings', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1895
	// Reference: src/views/SetupDesign-Lite.vue:732
	__( 'Header Font', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1896
	// Reference: src/views/SetupDesign-Lite.vue:733
	__( 'Body Text Font', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1898
	__( 'Use Video Background', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1900
	// Reference: src/views/SetupDesign-Lite.vue:737
	__( 'The video background will not be displayed on mobile devices or in the editor preview.', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1904
	// Reference: src/views/SetupDesign-Lite.vue:738
	__( 'Play on auto-loop', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1905
	// Reference: src/views/SetupDesign-Lite.vue:739
	__( 'Enter your custom css below', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1906
	// Reference: src/views/SetupDesign-Lite.vue:740
	__( 'Edit Custom CSS', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1909
	// Reference: src/views/SetupDesign-Lite.vue:743
	__( 'Font Themes Library', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1910
	// Reference: src/views/SetupDesign-Lite.vue:744
	__( 'Search colors...', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1911
	// Reference: src/views/SetupDesign-Lite.vue:745
	__( 'Search fonts...', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1915
	// Reference: src/views/SetupDesign-Lite.vue:749
	__( 'Links', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1917
	// Reference: src/views/SetupDesign-Lite.vue:751
	__( 'Font Themes', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1918
	// Reference: src/views/SetupDesign-Lite.vue:752
	__( 'Color Palettes', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1920
	// Reference: src/views/SetupDesign-Lite.vue:754
	__( 'Fonts', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1923
	// Reference: src/views/SetupDesign-Lite.vue:757
	__( 'Custom CSS', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1924
	// Reference: src/views/SetupDesign-Lite.vue:758
	__( 'All Palettes', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1925
	// Reference: src/views/SetupDesign-Lite.vue:759
	__( 'All Themes', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1926
	// Reference: src/views/SetupDesign-Lite.vue:760
	__( 'Serif', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1927
	// Reference: src/views/SetupDesign-Lite.vue:761
	__( 'Sans Serif', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1928
	// Reference: src/views/SetupDesign-Lite.vue:762
	__( 'Background Slideshow', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1929
	// Reference: src/views/SetupDesign-Lite.vue:763
	__( 'Slideshow Images', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1930
	// Reference: src/views/SetupDesign-Lite.vue:764
	__( 'Add New Slide', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1931
	// Reference: src/views/SetupDesign-Lite.vue:765
	__( 'The background slideshow will not be shown in the editor preview. The slides will only be displayed in the live preview.', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1936
	__( 'Add Custom Color', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1937
	__( 'Body Text Color', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1938
	__( 'Show H1 - H6 Settings', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1940
	__( 'H1 ', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1941
	__( 'H1 Color', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1942
	__( 'H2 ', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1943
	__( 'H2 Color', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1944
	__( 'H3 ', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1945
	__( 'H3 Color', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1946
	__( 'H4 ', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1947
	__( 'H4 Color', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1948
	__( 'H5 ', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1949
	__( 'H5 Color', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1950
	__( 'H6 ', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1951
	__( 'H6 Color', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1952
	__( 'Body Text', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1953
	__( 'Desktop BG', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1954
	__( 'Mobile BG', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1959
	__( 'Row Default Max Width', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1961
	__( 'Forms', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1964
	__( 'Field', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1968
	__( 'Field Border Style', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1973
	__( 'Field Padding', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1974
	__( 'Header Default Bottom Margin', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1978
	__( 'Paragraph Default Bottom Margin', 'coming-soon' ),

	// Reference: src/views/GlobalCSS.vue:1982
	__( 'Label Default Bottom Margin', 'coming-soon' ),

	// Reference: src/views/InlineHelpView.vue:265
	__( 'Ask a question or search the docs...', 'coming-soon' ),

	// Reference: src/views/InlineHelpView.vue:267
	__( 'No docs found', 'coming-soon' ),

	// Reference: src/views/InlineHelpView.vue:268
	__( 'View Documentation', 'coming-soon' ),

	// Reference: src/views/InlineHelpView.vue:269
	__( 'Browse documentation, reference material, and tutorials for SeedProd.', 'coming-soon' ),

	// Reference: src/views/InlineHelpView.vue:270
	__( 'View All Documentation', 'coming-soon' ),

	// Reference: src/views/InlineHelpView.vue:271
	__( 'Get Support', 'coming-soon' ),

	// Reference: src/views/InlineHelpView.vue:272
	__( 'Submit a ticket and our world class support team will be in touch soon.', 'coming-soon' ),

	// Reference: src/views/InlineHelpView.vue:273
	__( 'Submit a Support Ticket', 'coming-soon' ),

	// Reference: src/views/InlineHelpView.vue:274
	__( 'Upgrade to SeedProd Lite to access our world class customer support', 'coming-soon' ),

	// Reference: src/views/InlineHelpView.vue:275
	__( 'Upgrade to SeedProd Lite', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1483
	__( 'Expand All', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1484
	__( 'Collapse All', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1485
	__( 'Section', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1492
	__( 'Add Section', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1493
	__( 'Duplicate Section', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1494
	__( 'Save Section', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1496
	__( 'Delete Section', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1497
	__( 'Copy Section', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1498
	__( 'Paste Section', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1499
	__( 'Add Row', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1500
	__( 'Duplicate Row', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1501
	__( 'Delete Row', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1502
	__( 'Copy Row', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1503
	__( 'Paste Row', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1504
	__( 'Add Column', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1505
	__( 'Duplicate Column', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1506
	__( 'Delete Column', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1507
	__( 'Copy Column', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1508
	__( 'Paste Column', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1509
	__( 'Duplicate Block', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1510
	__( 'Delete Block', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1511
	__( 'Copy Block', 'coming-soon' ),

	// Reference: src/views/Layoutnav.vue:1512
	__( 'Paste Block', 'coming-soon' ),

	// Reference: src/views/Revisions.vue:62
	__( 'Loading Revisons', 'coming-soon' ),

	// Reference: src/views/Revisions.vue:63
	__( 'Click to preview version:', 'coming-soon' ),

	// Reference: src/views/Revisions.vue:64
	__( 'Current Version', 'coming-soon' ),

	// Reference: src/views/Revisions.vue:65
	__( 'by', 'coming-soon' ),

	// Reference: src/views/Revisions.vue:66
	__( 'There are no revisons to show.', 'coming-soon' ),

	// Reference: src/views/Revisions.vue:67
	__( 'ago', 'coming-soon' ),

	// Reference: src/views/SectionTemplateOptions-Lite.vue:432
	__( 'Choose This Section', 'coming-soon' ),

	// Reference: src/views/SectionTemplateOptions-Lite.vue:535
	// Reference: src/views/TemplateChooser-Lite.vue:1474
	__( 'Deleted!', 'coming-soon' ),

	// Reference: src/views/SectionTemplates-Lite.vue:100
	__( 'All Sections', 'coming-soon' ),

	// Reference: src/views/SectionTemplates-Lite.vue:101
	__( 'Favorites', 'coming-soon' ),

	// Reference: src/views/SectionTemplates-Lite.vue:102
	__( 'Categories:', 'coming-soon' ),

	// Reference: src/views/SectionTemplates-Lite.vue:98
	// Reference: src/views/SetupBlockOptions-Lite.vue:1406
	__( 'Blocks', 'coming-soon' ),

	// Reference: src/views/SectionTemplates-Lite.vue:99
	// Reference: src/views/SetupBlockOptions-Lite.vue:1407
	__( 'Sections', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:320
	// Reference: src/views/SetupSettings.vue:248
	__( 'Access Control', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:321
	__( 'Exclude Default:', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:324
	__( 'By default we exclude urls with the terms: login, admin, dashboard and account to prevent lockouts.', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:325
	__( 'Bypass Cookie:', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:326
	__( 'Use cookies instead of creating a WordPress user for the bypass. Note: this may not work on sites that are cached. Learn More', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:327
	__( 'Bypass URL:', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:328
	__( 'Bypass URL Expires:', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:329
	__( 'Access by IP:', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:330
	__( 'Access by Role:', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:331
	__( 'By default anyone logged in will see the regular website and not the coming soon page. To override this select Roles that will be given access to see the regular website.', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:332
	__( 'Include/Exclude URLs:', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:333
	__( 'Show on the Entire Website', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:334
	__( 'Show on the Entire Website except for the Blog', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:335
	__( 'Show on the Home Page Only', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:336
	__( 'Include URLs', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:337
	__( 'Exclude URLs', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:338
	__( 'By default the Coming Soon/Maintenance page is shown on every page. Use the \'Show on the Home Page Only\' option to only show on the home page. Alternatively Include or Exclude URLs.', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:339
	__( 'Enter a phrase above and give your visitors a secret url that will allow them to bypass the Coming Soon page.', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:340
	__( 'After the bypass url expires the user will need to revisit the bypass url to regain access.', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:341
	__( 'One IP Address per line', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:342
	__( 'All visitors from certain IP\'s to bypass the Coming Soon page.', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:343
	__( 'Put each IP on it\'s own line. Your current IP is:', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:344
	__( 'Add Role', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:345
	__( 'Include certain urls to display the Coming Soon or Maintenance Page.', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:346
	__( 'One per line. You may also enter a page or post id.', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:347
	__( 'Exclude certain urls to display the Coming Soon or Maintenance Page.', 'coming-soon' ),

	// Reference: src/views/SettingsAccess-Lite.vue:348
	__( 'Example: /about-us/', 'coming-soon' ),

	// Reference: src/views/SettingsAnalytics.vue:114
	// Reference: src/views/SetupSettings.vue:250
	__( 'Analytics', 'coming-soon' ),

	// Reference: src/views/SettingsAnalytics.vue:115
	__( 'Your Analytics settings are being managed by:', 'coming-soon' ),

	// Reference: src/views/SettingsAnalytics.vue:119
	__( 'Edit Analytics Settings', 'coming-soon' ),

	// Reference: src/views/SettingsAnalytics.vue:120
	// Reference: src/views/SettingsSEO.vue:229
	__( 'Your SEO settings are being managed by:', 'coming-soon' ),

	// Reference: src/views/SettingsAnalytics.vue:124
	__( 'Install Google Analytics plugin:', 'coming-soon' ),

	// Reference: src/views/SettingsAnalytics.vue:128
	__( 'Install MonsterInsights', 'coming-soon' ),

	// Reference: src/views/SettingsAnalytics.vue:129
	__( 'Activate MonsterInsights', 'coming-soon' ),

	// Reference: src/views/SettingsAnalytics.vue:130
	__( 'Install Analytics plugin:', 'coming-soon' ),

	// Reference: src/views/SettingsDomain.vue:120
	// Reference: src/views/SetupSettings.vue:252
	__( 'Custom Domain', 'coming-soon' ),

	// Reference: src/views/SettingsDomain.vue:121
	__( 'Custom Domain:', 'coming-soon' ),

	// Reference: src/views/SettingsDomain.vue:122
	__( 'OFF', 'coming-soon' ),

	// Reference: src/views/SettingsDomain.vue:123
	__( 'ON', 'coming-soon' ),

	// Reference: src/views/SettingsDomain.vue:124
	__( 'Domain Name:', 'coming-soon' ),

	// Reference: src/views/SettingsDomain.vue:125
	__( 'Please enter your domain.', 'coming-soon' ),

	// Reference: src/views/SettingsDomain.vue:126
	__( 'Click here to learn more', 'coming-soon' ),

	// Reference: src/views/SettingsDomain.vue:127
	__( 'how to map your custom domain.', 'coming-soon' ),

	// Reference: src/views/SettingsDomain.vue:128
	__( 'Force HTTPS', 'coming-soon' ),

	// Reference: src/views/SettingsDomain.vue:129
	__( 'Only enable this if you have an SSL certificate installed and you wish to redirect users to https://', 'coming-soon' ),

	// Reference: src/views/SettingsDomain.vue:130
	__( 'Please enter a valid URL that will be pointed to this landing page, such as', 'coming-soon' ),

	// Reference: src/views/SettingsDomain.vue:131
	__( 'It should look something like, \'mynewdomain.com\' or \'mynewdomain.com/coming-soon\'', 'coming-soon' ),

	// Reference: src/views/SettingsDomain.vue:132
	__( 'You can leave out the \'http://\'. If you are using \'https://\', turn on Force HTTPS below.', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:218
	__( 'Page Title:', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:219
	// Reference: src/views/TemplateChooser-Lite.vue:1238
	__( 'Page URL:', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:220
	__( 'Page Status:', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:221
	__( 'Draft', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:222
	// Reference: src/views/Setup.vue:1037
	__( 'Publish', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:223
	__( '"Powered by SeedProd"', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:226
	__( 'Choose New Template:', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:227
	__( 'Redirect Mode', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:228
	__( 'Redirect URL: A temporary redirect (302 status) will be created to the url entered.', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:229
	__( 'Enable', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:230
	__( 'Redirect URL: A permanent redirect (301 status) will be created to the url entered.', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:232
	__( 'SeedProd Link', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:233
	__( 'Enter Your Affiliate URL and Make Money with SeedProd', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:234
	__( 'Join our affiliate program', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:235
	__( 'and get a 20% commission on all sales generated from your powered by link.', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:236
	__( 'Isolation Mode', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:237
	__( 'Redirect the Default Login Page', 'coming-soon' ),

	// Reference: src/views/SettingsGeneral.vue:238
	__( 'Facebook App ID:', 'coming-soon' ),

	// Reference: src/views/SettingsSEO.vue:228
	// Reference: src/views/SetupSettings.vue:249
	__( 'SEO', 'coming-soon' ),

	// Reference: src/views/SettingsSEO.vue:233
	__( 'Yoast SEO', 'coming-soon' ),

	// Reference: src/views/SettingsSEO.vue:234
	__( 'Edit this page\'s SEO Settings', 'coming-soon' ),

	// Reference: src/views/SettingsSEO.vue:239
	__( 'Install All In One SEO', 'coming-soon' ),

	// Reference: src/views/SettingsSEO.vue:240
	__( 'Activate All in One SEO', 'coming-soon' ),

	// Reference: src/views/SettingsSEO.vue:241
	__( 'Install SEO plugin:', 'coming-soon' ),

	// Reference: src/views/SettingsScripts.vue:56
	// Reference: src/views/SetupSettings.vue:251
	__( 'Scripts', 'coming-soon' ),

	// Reference: src/views/SettingsScripts.vue:57
	__( 'Header Scripts:', 'coming-soon' ),

	// Reference: src/views/SettingsScripts.vue:58
	__( 'This code will be rendered before the closing &lt;/head&gt; tag.', 'coming-soon' ),

	// Reference: src/views/SettingsScripts.vue:62
	__( 'Footer Scripts:', 'coming-soon' ),

	// Reference: src/views/SettingsScripts.vue:63
	__( 'The code will be rendered before the closing &lt;/body&gt; tag.', 'coming-soon' ),

	// Reference: src/views/SettingsScripts.vue:67
	__( 'Body Scripts:', 'coming-soon' ),

	// Reference: src/views/SettingsScripts.vue:68
	__( 'The code will be rendered after the &lt;body&gt; tag.', 'coming-soon' ),

	// Reference: src/views/SettingsScripts.vue:72
	__( 'You do not have the proper WordPress permissions to add scripts.', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1026
	__( 'Design', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1027
	__( 'Connect', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1028
	__( 'Page Settings', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1029
	__( 'You have unsaved changes. Are you sure you want to lose these changes?', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1030
	__( 'Exit Without Saving', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1031
	__( 'template has been saved!', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1032
	__( 'You can find it in your template library when you create a new landing page.', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1033
	__( 'Enter a new template name:', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1035
	__( 'Your page has been published!', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1038
	__( 'Unpublish', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1039
	__( 'Schedule', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1040
	__( 'Save as Template', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1041
	__( 'Return to Page Editor', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1043
	__( 'See Live Page', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1044
	__( 'Save and Exit', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1045
	__( 'Help', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1046
	__( 'Save', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1049
	__( 'You are about to leave this page and go to the Global CSS page. Continue?', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1050
	__( 'This page is not active. Would you like to activate it now?', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1051
	__( 'Yes, Activate', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1052
	__( 'No, Close', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1053
	__( 'Coming Soon Mode is not active. Would you like to activate it now and show this page to visitors?', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1054
	__( 'Maintenance Mode is not active. Would you like to activate it now and show this page to visitors?', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1055
	__( 'Note: This page will only be shown to users who are logged out. If you logged out and and do not see the correct page you may need to clear your site cache.', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1056
	__( 'This page is not published. Would you like to publish it now?', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1057
	__( 'Yes, Publish', 'coming-soon' ),

	// Reference: src/views/Setup.vue:1591
	__( 'Something has prevented the page from being saved.', 'coming-soon' ),

	// Reference: src/views/SetupBlockOptions-Lite.vue:1408
	__( 'Standard', 'coming-soon' ),

	// Reference: src/views/SetupBlockOptions-Lite.vue:1410
	__( 'Saved Blocks', 'coming-soon' ),

	// Reference: src/views/SetupBlockOptions-Lite.vue:1412
	__( 'Search blocks...', 'coming-soon' ),

	// Reference: src/views/SetupBlockOptions-Lite.vue:1414
	__( 'Widgets', 'coming-soon' ),

	// Reference: src/views/SetupBlockOptions-Lite.vue:1415
	__( 'Easy Digital Downloads', 'coming-soon' ),

	// Reference: src/views/SetupDesign-Lite.vue:735
	__( 'Video Background', 'coming-soon' ),

	// Reference: src/views/TemplateChooser-Lite.vue:1219
	__( '&larr; Go Back', 'coming-soon' ),

	// Reference: src/views/TemplateChooser-Lite.vue:1220
	__( '&larr; Go to Dashboard', 'coming-soon' ),

	// Reference: src/views/TemplateChooser-Lite.vue:1221
	__( 'Choose a New Page Template', 'coming-soon' ),

	// Reference: src/views/TemplateChooser-Lite.vue:1225
	__( 'No Favorited Templates Found', 'coming-soon' ),

	// Reference: src/views/TemplateChooser-Lite.vue:1226
	__( 'No Saved Templates Found', 'coming-soon' ),

	// Reference: src/views/TemplateChooser-Lite.vue:1231
	__( 'Choose This Template', 'coming-soon' ),

	// Reference: src/views/TemplateChooser-Lite.vue:1232
	__( 'Enter your new page details', 'coming-soon' ),

	// Reference: src/views/TemplateChooser-Lite.vue:1233
	__( 'You can always change it later in Page Settings.', 'coming-soon' ),

	// Reference: src/views/TemplateChooser-Lite.vue:1237
	__( 'Page Name:', 'coming-soon' ),

	// Reference: src/views/TemplateChooser-Lite.vue:1239
	__( 'Save and Start Editing the Page', 'coming-soon' ),

	// Reference: src/views/TemplateChooser-Lite.vue:1248
	__( 'My Landing Page name goes here', 'coming-soon' ),

	// Reference: src/views/TemplateChooser-Lite.vue:1252
	__( 'You can favorite any template by clicking the heart icon under the page template.', 'coming-soon' ),

	// Reference: src/views/TemplateChooser-Lite.vue:1256
	__( 'You can save pages as templates in the builder. Any saved pages will be shown here.', 'coming-soon' )
);
/* THIS IS THE END OF THE GENERATED FILE */
