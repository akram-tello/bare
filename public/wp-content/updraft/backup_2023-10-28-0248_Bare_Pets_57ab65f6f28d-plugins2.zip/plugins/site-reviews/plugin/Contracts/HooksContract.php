<?php

namespace GeminiLabs\SiteReviews\Contracts;

interface HooksContract
{
    public function run(): void;
}
