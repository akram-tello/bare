<?php

namespace GeminiLabs\SiteReviews\Exceptions;

class LicenseException extends \Exception
{
}
