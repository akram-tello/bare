<?php
namespace CTXFeed\V5\Structure;
interface StructureXLSXInterface {
	public function __construct( $config );
	public function getXLSXStructure();
}

