<?php
namespace CTXFeed\V5\Structure;
class TiktokStructure {

}