<?php

namespace CTXFeed\V5\Override;


/**
 * Class Common
 *
 * @package    CTXFeed\V5\Override
 * @subpackage CTXFeed\V5\Override
 */
class Common {
	public function __construct(  ) {
	
	}
}