<?php

namespace CTXFeed\V5\Override;


/**
 * Class TrovaprezziTemplate
 *
 * @package    CTXFeed\V5\Override
 * @subpackage CTXFeed\V5\Override
 */
class TrovaprezziTemplate {
	
}