<?php

namespace CTXFeed\V5\Feed;


/**
 * Class Product
 *
 * @package    CTXFeed
 * @subpackage CTXFeed\V5\Feed
 * @author     Ohidul Islam <wahid0003@gmail.com>
 * @link       https://webappick.com
 * @license    https://opensource.org/licenses/gpl-license.php GNU Public License
 * @category   MyCategory
 */
class Product {

	public static function addProduct() {

	}

	public static function addProducts() {

	}

	public static function updateProduct() {

	}

	public static function updateProducts() {

	}

	public static function deleteProduct(  ) {

	}

	public static function deleteProducts(  ) {

	}


}
