<?php
namespace CTXFeed\V5\Common;
class Status {

}