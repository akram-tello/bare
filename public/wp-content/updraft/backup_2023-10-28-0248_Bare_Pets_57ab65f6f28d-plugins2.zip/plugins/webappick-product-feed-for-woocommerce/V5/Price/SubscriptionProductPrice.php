<?php
namespace CTXFeed\V5\Price;
class Subscription {

}