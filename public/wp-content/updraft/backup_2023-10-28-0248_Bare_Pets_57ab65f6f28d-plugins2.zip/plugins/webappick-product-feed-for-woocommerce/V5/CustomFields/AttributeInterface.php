<?php

namespace WebAppick\Attributes;

interface AttributeInterface{

    public function get_value($post);

}