<?php
namespace CTXFeed\V5\Template;
interface TemplateInterface {
	public function get_feed(  );
	public function get_header(  );
	public function get_footer(  );
}

