<?php
namespace CTXFeed\V5\Merchant;
class Templates {

}