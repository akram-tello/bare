<?php
namespace CTXFeed\V5\Merchant;
use CTXFeed\V5\Common\DropDown;

class Merchants
{

    public static function get_template_config()
    {

    }

    public static function get_template_info()
    {

    }


    private static function get_merchants()
    {

    }
}