<?php
namespace Automattic\WooCommerce\Blocks\Templates;

/**
 * CheckoutHeader Template class.
 *
 * @internal
 */
class CheckoutHeaderTemplate {

	const SLUG = 'checkout-header';

}
