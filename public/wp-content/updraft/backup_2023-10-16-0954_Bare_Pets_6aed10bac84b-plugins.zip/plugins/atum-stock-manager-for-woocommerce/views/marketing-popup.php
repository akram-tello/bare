<?php
/**
 * View for the marketing popup view
 *
 * @since        1.4.0
 */

defined( 'ABSPATH' ) || die;
?>
<div class="atum-marketing-popup"></div>
