/**
 * External dependencies
 */
import Label from '@woocommerce/base-components/label';

export default Label;
