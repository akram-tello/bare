<?php

return [
    ':star-empty' => glsr()->url('assets/images/stars/default/star-empty.svg'),
    ':star-error' => glsr()->url('assets/images/stars/default/star-error.svg'),
    ':star-full' => glsr()->url('assets/images/stars/default/star-full.svg'),
    ':star-half' => glsr()->url('assets/images/stars/default/star-half.svg'),
];
