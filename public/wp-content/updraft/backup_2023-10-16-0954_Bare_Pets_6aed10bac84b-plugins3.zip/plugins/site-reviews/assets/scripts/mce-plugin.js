!function(n){"use strict";window.tinymce.PluginManager.add("glsr_shortcode",(function(n){n.addCommand("GLSR_Shortcode",(function(){GLSR.shortcode.create(n.id)}))}))}();
