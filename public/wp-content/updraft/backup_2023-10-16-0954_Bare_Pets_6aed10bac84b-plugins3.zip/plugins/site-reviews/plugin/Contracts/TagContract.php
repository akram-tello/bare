<?php

namespace GeminiLabs\SiteReviews\Contracts;

interface TagContract
{
}
